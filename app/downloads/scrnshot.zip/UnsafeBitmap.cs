﻿/** 
 * Copyright (c) 2012 Andrew McWatters 
 * 
 * This software is provided 'as-is', without any express or implied 
 * warranty.  In no event will the authors be held liable for any damages 
 * arising from the use of this software. 
 * 
 * Permission is granted to anyone to use this software for any purpose, 
 * including commercial applications, and to alter it and redistribute it 
 * freely, subject to the following restrictions: 
 * 
 * 1. The origin of this software must not be misrepresented; you must not 
 *    claim that you wrote the original software. If you use this software 
 *    in a product, an acknowledgment in the product documentation would be 
 *    appreciated but is not required. 
 * 2. Altered source versions must be plainly marked as such, and must not be 
 *    misrepresented as being the original software. 
 * 3. This notice may not be removed or altered from any source distribution. 
 **/

using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace scrnshot
{
    [StructLayout(LayoutKind.Sequential)]
    public struct Pixel
    {
        internal byte R;
        internal byte G;
        internal byte B;
        internal byte A;
    }

    public unsafe class UnsafeBitmap
    {
        Bitmap bitmap;
        BitmapData bitmapData;
        byte* pBase = null;
        int width;

        public UnsafeBitmap(Bitmap bitmap)
        {
            this.bitmap = bitmap;
        }

        public void Dispose()
        {
            bitmap.Dispose();
        }

        public Pixel* GetPixel(int x, int y)
        {
            return (Pixel*)(pBase + y * width + x * sizeof(Pixel));
        }

        public void LockPixels()
        {
            Rectangle bounds = new Rectangle(Point.Empty, bitmap.Size);
            width = bounds.Width * sizeof(Pixel);
            if (width % 4 != 0)
            {
                width = 4 * (width / 4 + 1);
            }

            bitmapData = bitmap.LockBits(bounds, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            pBase = (byte*)bitmapData.Scan0.ToPointer();
        }

        public void UnlockPixels()
        {
            bitmap.UnlockBits(bitmapData);
            bitmapData = null;
            pBase = null;
        }
    }
}
