scrnshot
==========

_This project is no longer maintained._

A simple screenshot tool

Press Ctrn+PrtScn. That's it.
