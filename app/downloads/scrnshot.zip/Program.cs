﻿/** 
 * Copyright (c) 2012 Andrew McWatters 
 * 
 * This software is provided 'as-is', without any express or implied 
 * warranty.  In no event will the authors be held liable for any damages 
 * arising from the use of this software. 
 * 
 * Permission is granted to anyone to use this software for any purpose, 
 * including commercial applications, and to alter it and redistribute it 
 * freely, subject to the following restrictions: 
 * 
 * 1. The origin of this software must not be misrepresented; you must not 
 *    claim that you wrote the original software. If you use this software 
 *    in a product, an acknowledgment in the product documentation would be 
 *    appreciated but is not required. 
 * 2. Altered source versions must be plainly marked as such, and must not be 
 *    misrepresented as being the original software. 
 * 3. This notice may not be removed or altered from any source distribution. 
 **/

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace scrnshot
{
    public class Program : Form
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new Program());
        }

        private const int SHADOW_OFFSET = 64;

        private const int WM_HOTKEY = 0x0312;
        private const int MOD_CONTROL = 0x2;
        private const int MOD_NOREPEAT = 0x4000;
        private const int SRCCOPY = 0x00CC0020;
        private const int SW_SHOWNOACTIVATE = 4;
        private const int SWP_NOACTIVATE = 0x0010;
        private const int SW_HIDE = 0;

        [DllImport("user32.dll")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        [DllImport("user32.dll")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindowDC(IntPtr hWnd);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);

        [DllImport("gdi32.dll")]
        private static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

        [DllImport("gdi32.dll")]
        private static extern IntPtr BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);

        [DllImport("gdi32.dll")]
        private static extern bool DeleteDC(IntPtr hdc);

        [DllImport("user32.dll")]
        private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        [DllImport("user32.dll")]
        private static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY)
                TakeScreenshot();
            base.WndProc(ref m);
        }

        protected override void OnLoad(EventArgs e)
        {
            this.Visible = false;
            this.ShowInTaskbar = false;

            RegisterHotKey(this.Handle, 0, MOD_CONTROL | MOD_NOREPEAT, (int)Keys.PrintScreen);

            base.OnLoad(e);
        }

        protected override void OnClosed(EventArgs e)
        {
            UnregisterHotKey(this.Handle, 1);

            base.OnClosed(e);
        }

        public Bitmap GetScreenshot()
        {
            IntPtr desktopWnd = GetDesktopWindow();
            IntPtr wnd = GetForegroundWindow();

            RECT desktopRect;
            GetWindowRect(desktopWnd, out desktopRect);
            int desktopWidth = desktopRect.right - desktopRect.left;
            int desktopHeight = desktopRect.bottom - desktopRect.top;

            RECT rect;
            GetWindowRect(wnd, out rect);

            int offset = SystemInformation.IsDropShadowEnabled ? SHADOW_OFFSET : 0;
            int width = (rect.right - rect.left) + offset;
            if (width > desktopWidth)
                width = desktopWidth;
            int height = (rect.bottom - rect.top) + offset;
            if (height > desktopHeight)
                height = desktopHeight;

            int srcX = rect.left - offset / 2;
            if (srcX < desktopRect.left)
                srcX = 0;
            int srcY = rect.top - offset / 2;
            if (srcY < desktopRect.top)
                srcY = 0;

            if (srcX + width > desktopRect.right)
                width = desktopRect.right - srcX;
            if (srcY + height > desktopRect.bottom)
                height = desktopRect.bottom - srcY;

            Bitmap[] screenshotMasks = new Bitmap[2];

            IntPtr startWnd = FindWindow("Button", "Start");
            IntPtr taskbarWnd = FindWindow("Shell_TrayWnd", null);
            bool taskbarHidden = false;
            if (wnd != startWnd && wnd != taskbarWnd)
            {
                ShowWindow(startWnd, SW_HIDE);
                ShowWindow(taskbarWnd, SW_HIDE);
                taskbarHidden = true;
            }

            for (int i = 0; i < 2; i++)
            {
                Form mask = CreateBlankForm(srcX, srcY, width, height, i == 0 ? Color.Black : Color.White);
                ShowWindow(mask.Handle, SW_SHOWNOACTIVATE);
                SetWindowPos(mask.Handle, wnd, srcX, srcY, width, height, SWP_NOACTIVATE);
                Thread.Sleep(100);

                IntPtr hWndDC = GetWindowDC(desktopWnd);
                IntPtr hCompatDC = CreateCompatibleDC(hWndDC);
                IntPtr hBitmap = CreateCompatibleBitmap(hWndDC, width, height);
                IntPtr hOld = SelectObject(hCompatDC, hBitmap);

                BitBlt(hCompatDC, 0, 0, width, height, hWndDC, srcX, srcY, SRCCOPY);
                SelectObject(hCompatDC, hBitmap);
                DeleteDC(hCompatDC);
                ReleaseDC(wnd, hWndDC);
                screenshotMasks[i] = Image.FromHbitmap(hBitmap);
                DeleteObject(hBitmap);

                mask.Close();
            }

            if (taskbarHidden)
            {
                ShowWindow(startWnd, SW_SHOWNOACTIVATE);
                ShowWindow(taskbarWnd, SW_SHOWNOACTIVATE);
            }

            Bitmap screenshot = CreateTransparentScreenshot(screenshotMasks[0], screenshotMasks[1]);
            return TrimScreenshot(screenshot);
        }

        public void SaveScreenshot(Bitmap bmp)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.FileName = "Untitled";
            dialog.Filter = "PNG (*.png)|*.png";
            dialog.Title = "Save As";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                if (dialog.FileName != "")
                {
                    FileStream fs = (FileStream)dialog.OpenFile();
                    bmp.Save(fs, ImageFormat.Png);
                    fs.Close();
                    bmp.Dispose();
                }
            }
        }

        public void TakeScreenshot()
        {
            Bitmap screenshot = GetScreenshot();
            SaveScreenshot(screenshot);
        }

        public Form CreateBlankForm(int x, int y, int width, int height, Color color)
        {
            Form form = new Form();
            form.BackColor = color;
            form.SetDesktopBounds(x, y, width, height);
            form.FormBorderStyle = FormBorderStyle.None;
            form.ShowInTaskbar = false;
            form.Show();
            form.SetDesktopLocation(x, y);
            return form;
        }

        public unsafe Bitmap CreateTransparentScreenshot(Bitmap blackBmp, Bitmap whiteBmp)
        {
            Bitmap screenshot = new Bitmap(blackBmp.Width, blackBmp.Height, PixelFormat.Format32bppArgb);
            UnsafeBitmap blackMask = new UnsafeBitmap(blackBmp);
            UnsafeBitmap whiteMask = new UnsafeBitmap(whiteBmp);
            UnsafeBitmap alphaComposite = new UnsafeBitmap(screenshot);
            blackMask.LockPixels();
            whiteMask.LockPixels();
            alphaComposite.LockPixels();

            for (int x = 0, y = 0; x < screenshot.Width && y < screenshot.Height;)
            {
                Pixel* pBlackPixel = blackMask.GetPixel(x, y);
                Pixel* pWhitePixel = whiteMask.GetPixel(x, y);
                Pixel* pAlphaPixel = alphaComposite.GetPixel(x, y);

                pAlphaPixel->A = Convert.ToByte(255 - ((Abs(pWhitePixel->R - pBlackPixel->R) +
                                                        Abs(pWhitePixel->G - pBlackPixel->G) +
                                                        Abs(pWhitePixel->B - pBlackPixel->B)) / 3));
                pAlphaPixel->R = ToByte(pAlphaPixel->A != 0 ? pBlackPixel->R * 255 / pAlphaPixel->A : 0);
                pAlphaPixel->G = ToByte(pAlphaPixel->A != 0 ? pBlackPixel->G * 255 / pAlphaPixel->A : 0);
                pAlphaPixel->B = ToByte(pAlphaPixel->A != 0 ? pBlackPixel->B * 255 / pAlphaPixel->A : 0);

                if (x == screenshot.Width - 1)
                {
                    y++;
                    x = 0;
                    continue;
                }
                x++;
            }

            blackMask.UnlockPixels();
            whiteMask.UnlockPixels();
            alphaComposite.UnlockPixels();
            blackMask.Dispose();
            whiteMask.Dispose();
            blackBmp.Dispose();
            whiteBmp.Dispose();
            return screenshot;
        }

        public byte ToByte(int n)
        {
            return (byte)(n > 255 ? 255 : n);
        }

        public int Abs(int n)
        {
            return n < 0 ? -n : n;
        }

        public unsafe Bitmap TrimScreenshot(Bitmap bmp)
        {
            UnsafeBitmap bitmapData = new UnsafeBitmap(bmp);
            bitmapData.LockPixels();
            int width = bmp.Width;
            int height = bmp.Height;

            int left = -1;
            int top = -1;
            int right = -1;
            int bottom = -1;

            Pixel* pixel;

            for (int x = 0, y = 0; ; )
            {
                pixel = bitmapData.GetPixel(x, y);
                if (left == -1)
                {
                    if (pixel->A != 0) { left = x; x = 0; y = 0; continue; }
                    if (y == height - 1) { x++; y = 0; } else y++;
                    continue;
                }
                if (top == -1)
                {
                    if (pixel->A != 0) { top = y; x = width - 1; y = 0; continue; }
                    if (x == width - 1) { y++; x = 0; } else x++;
                    continue;
                }
                if (right == -1)
                {
                    if (pixel->A != 0) { right = x + 1; x = 0; y = height - 1; continue; }
                    if (y == height - 1) { x--; y = 0; } else y++;
                    continue;
                }
                if (bottom == -1)
                {
                    if (pixel->A != 0) { bottom = y + 1; break; }
                    if (x == width - 1) { y--; x = 0; } else x++;
                    continue;
                }
            }

            bitmapData.UnlockPixels();

            Bitmap trimmedBmp = bmp.Clone(new Rectangle(left, top, right - left, bottom - top), bmp.PixelFormat);
            bmp.Dispose();
            return trimmedBmp;
        }
    }
}
