PluginSync
==========

_This project is no longer maintained._

A Bukkit plugin to sync your server to a plugin depot, used on "Andrew McWatters' Server!"
