package com.andrewmcwatters.minecraft;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.json.JSONArray;
import org.json.JSONObject;

public class PluginSync extends JavaPlugin {
	private static final String URL_WEBAPI_BASE = "http://api.andrewmcwatters.com/minecraft";
	private static final String URL_DEPOT_BASE	= "http://depot.andrewmcwatters.com/minecraft";

	private String api(String method) {
		String ret = "";
		try {
			URL apiURL = new URL(URL_WEBAPI_BASE + method);
			URLConnection apiConnection = apiURL.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(apiConnection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			ret = response.toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ret;
	}

	private void downloadPlugin(String filename) {
		try {
			URL plugin = new URL(URL_DEPOT_BASE + "/plugins/" + filename);
			ReadableByteChannel rbc = Channels.newChannel(plugin.openStream());
			FileOutputStream fos = new FileOutputStream("./plugins/" + filename);
			fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private HashMap<String, String> getDepotPlugins() {
		JSONArray plugins			= new JSONArray(api("/plugins"));
		HashMap<String, String> map = new HashMap<String, String>();
		JSONObject plugin			= null;
		for (int i = 0; i < plugins.length(); i++) {
			plugin = plugins.getJSONObject(i);
			map.put(plugin.getString("filename"), plugin.getString("sha1"));
		}
		return map;
	}

	private HashMap<String, String> getPlugins() {
		File pluginsFolder			= new File("./plugins");
		File[] plugins				= pluginsFolder.listFiles();
		HashMap<String, String> map = new HashMap<String, String>();
		File plugin					= null;
		MessageDigest md			= null;
		for (int i = 0; i < plugins.length; i++) {
			Formatter formatter		= new Formatter();
			plugin = plugins[i];
			try {
				md = MessageDigest.getInstance("SHA-1");
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
			byte[] hash = null;
			try {
				hash = md.digest(Files.readAllBytes(plugin.toPath()));
			} catch (IOException e) {
				e.printStackTrace();
			}
			for (byte b : hash)
				formatter.format("%02x", b);
			map.put(plugin.getName(), formatter.toString());
			formatter.close();
		}
		return map;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command,
			String label, String[] args) {
		if (command.getName().equalsIgnoreCase("sync")) {
			HashMap<String, String> plugins = getDepotPlugins();
			Iterator<Entry<String, String>> it = plugins.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, String> pairs = it.next();
				String plugin = pairs.getKey();
				sender.sendMessage("Downloading \"" + plugin + "\"...");
				downloadPlugin(plugin);
			}
			sender.sendMessage("Reloading server...");
			getServer().reload();
			return true;
		}
		return false;
	}

	@Override
	public void onDisable() {
	}

	@Override
	public void onEnable() {
	}
}
