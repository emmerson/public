-------------------------------------------------------------------------------
-- Scripted interfacing for Steam Community
-- Steam Community Utilities
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local require = require

module( "steamcommunity" )

comment		= require( "steamcommunity.comment" )
comments	= require( "steamcommunity.comments" )
http		= require( "steamcommunity.http" )
member		= require( "steamcommunity.member" )
members		= require( "steamcommunity.members" )
url			= require( "steamcommunity.url" )

rootURL	= "http://steamcommunity.com"
