-------------------------------------------------------------------------------
-- HTTP wrapper module
-- Steam Community Utilities
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local error = error

module( "steamcommunity.http" )

-------------------------------------------------------------------------------
-- http.get()
-- Purpose: The get wrapper function for the steamcommunity module. All
--			retrieval functions rely on this wrapper for parsing. It must
--			return the full page if possible, a status code (200 OK), and
--			cookie data if possible.
-- Input: URL - URL to get
--		  session - session object to use, or nil
-- Output: document, status code, cookie
-------------------------------------------------------------------------------
function get( URL, session )
	error( "steamcommunity.http.get was not implemented!" )
end

-------------------------------------------------------------------------------
-- http.post()
-- Purpose: The post wrapper function for the steamcommunity module. All
--			submission functions rely on this wrapper for interaction. It must
--			return the full page if possible, a status code (200 OK), and
--			cookie data if possible.
-- Input: URL - URL to post to
--		  session - session object to use, or nil
--		  postData - table of POST information
-- Output: document, status code, cookie
-------------------------------------------------------------------------------
function post( URL, session, postData )
	error( "steamcommunity.http.post was not implemented!" )
end
