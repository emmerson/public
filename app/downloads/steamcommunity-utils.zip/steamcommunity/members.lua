-------------------------------------------------------------------------------
-- Members module
-- Steam Community Utilities
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local http = require( "steamcommunity.http" )
local member = require( "steamcommunity.member" )
local steamcommunity = require( "steamcommunity" )
local print = print
local string = string
local table = table
local tonumber = tonumber

module( "steamcommunity.members" )

-------------------------------------------------------------------------------
-- pageLinksLargePattern
-- Purpose: Pattern for detecting large page information. Below is what each
--			part of the pattern represents
-------------------------------------------------------------------------------
pageLinksLargePattern = "" ..
-- Page Links Beginning
"<div class=\"pageLinks\">" ..
-- Current Page
".-(%d+)&nbsp;&nbsp;" ..
-- Page Count
".-&nbsp;...&nbsp;<a href=\"%?p=(%d+)\">"

-------------------------------------------------------------------------------
-- pageLinksCurrentPagePattern
-- Purpose: Pattern for detecting current page information. Below is what each
--			part of the pattern represents
-------------------------------------------------------------------------------
pageLinksCurrentPagePattern = "" ..
-- Page Links Beginning
"<div class=\"pageLinks\">" ..
-- Current Page
".-(%d+)&nbsp;&nbsp;"

-------------------------------------------------------------------------------
-- pageLinksSmallPattern
-- Purpose: Pattern for detecting small page information. Below is what each
--			part of the pattern represents
-------------------------------------------------------------------------------
pageLinksSmallPattern = "" ..
-- Page
".-(%d+)</a>&nbsp;&nbsp;"

-------------------------------------------------------------------------------
-- memberBlockPattern
-- Purpose: Pattern for filling member objects on the member manage page. Below
--			is what each part of the pattern represents
-------------------------------------------------------------------------------
memberBlockPattern = "" ..
-- Member Beginning
"<div class=\"memberBlock\">" ..
-- Avatar
".-memberBlockIcon\".-avatarIcon\"><img src=\"(.-)\"" ..
-- Username
".-memberBlockName\">(.-)<br />" ..
-- Member URL
".-<a href=\"(.-)\"" ..
-- Kick Link DOM element
".-memberBlockKick\">(.-)</div>" ..
-- Member End
".-</div>"

-------------------------------------------------------------------------------
-- memberKickLinkPattern
-- Purpose: Pattern for kicking a member from a group. Below is what each part
--			of the pattern represents
-------------------------------------------------------------------------------
memberKickLinkPattern = ""..
-- SteamID
"href=\"javascript:kickMember%('(.-)',"
-- "href=\"javascript:kickMember%('(.-)'," ..
-- Username (REDUNDANT)
-- "'(.-)'%)\""

-------------------------------------------------------------------------------
-- members.getMembersManagePage()
-- Purpose: Returns 0 if the page is retrieved successfully, then the thread
--			page by ID and page number, if provided, otherwise it returns 1 and
--			nil
-- Input: groupURLName - custom URL name of the group to get
--		  pageNumber - number of the page to get
-- Output: error code, members manage page
-------------------------------------------------------------------------------
function getMembersManagePage( groupURLName, pageNumber )
	pageNumber = pageNumber or ""
	if ( pageNumber ~= "" ) then
		pageNumber = "?p=" .. pageNumber
	end
	local r, c = http.get( steamcommunity.rootURL .. "/groups/" .. groupURLName .. "/membersManage" .. pageNumber )
	if ( c == 200 ) then
		return 0, r
	else
		return 1, nil
	end
end

-------------------------------------------------------------------------------
-- members.getPageInfo()
-- Purpose: Returns the current page number, and total page count
-- Input: membersManagePage - string of the requested page
-- Output: current page number, total page count
-------------------------------------------------------------------------------
function getPageInfo( membersManagePage )
	local currentPage, pageCount = string.match( membersManagePage, pageLinksLargePattern )
	if ( currentPage == nil and pageCount == nil ) then
		currentPage = string.match( membersManagePage, pageLinksCurrentPagePattern )
		for i in string.gmatch( membersManagePage, pageLinksSmallPagePattern ) do
			pageCount = i
		end
	end
	currentPage, pageCount = tonumber( currentPage ), tonumber( pageCount )
	return currentPage, pageCount
end

-------------------------------------------------------------------------------
-- members.getMembersInPage()
-- Purpose: Returns all members on a given members manage page
-- Input: membersManagePage - string of the requested page
-- Output: table of comments
-------------------------------------------------------------------------------
function getMembersInPage( membersManagePage )
	local processURL = string.match( membersManagePage, "var processURL = '(.-)'" )
	local t = {}
	for avatar,
		username,
		memberURL,
		kickLink
		in string.gmatch( membersManagePage, memberBlockPattern ) do
		local member		= member()
		member.memberURL	= memberURL
		member.avatar		= avatar
		member.username		= username
		if ( string.find( member.username, "<br>Owner - no managing!" ) )
			member.username	= string.gsub( member.username, "<br>Owner - no managing!", "" )
		elseif ( string.find( member.username, "<br>You!" ) )
			member.username	= string.gsub( member.username, "<br>You!", "" )
		elseif ( kickLink ~= "&nbsp;" ) then
			member.kickLink	= processURL .. "?action=kick&memberId=" .. string.match( kickLink, memberKickLinkPattern )
		end
		table.insert( t, member )
	end
	return t
end
