-------------------------------------------------------------------------------
-- Comments module
-- Steam Community Utilities
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local comment = require( "steamcommunity.comment" )
local http = require( "steamcommunity.http" )
local member = require( "steamcommunity.member" )
local steamcommunity = require( "steamcommunity" )
local string = string
local table = table
local tonumber = tonumber

module( "steamcommunity.comments" )

-------------------------------------------------------------------------------
-- pageLinksPattern
-- Purpose: Pattern for detecting page information. Below is what each part of
--			the pattern represents
-------------------------------------------------------------------------------
pageLinksPattern = "" ..
-- Page Links Beginning
"<div class=\"pageLinks\">" ..
-- Current Page
".-(%d+)&nbsp;&nbsp;" ..
-- Page Count
".-&nbsp;...&nbsp;<a href=\"%?p=(%d+)\">"

-------------------------------------------------------------------------------
-- commentBlockPattern
-- Purpose: Pattern for filling comment and member objects on a page. Below is
--			what each part of the pattern represents
-------------------------------------------------------------------------------
commentBlockPattern = "" ..
-- Comment Beginning
"<div class=\"commentBlockControl\">" ..
-- Delete Link DOM element
"(.-)</div>" ..
-- Member Status
".-iconHolder_(.-)\"" ..
-- Member URL
".-avatarIcon\"><a href=\"(.-)\"" ..
-- Avatar
".-<img src=\"(.-)\"" ..
-- Username
".-commentByline\".-\">(.-)</a>" ..
-- Timestamp
".-posted on (.-)</div>" ..
-- Comment Content
".-commentContent\">(.-)</div>" ..
-- Comment End
".-<div style=\"clear: left;\"></div>"

-------------------------------------------------------------------------------
-- comments.getAllCommentsPage()
-- Purpose: Returns 0 if the page is retrieved successfully, then the thread
--			page by ID and page number, if provided, otherwise it returns 1 and
--			nil
-- Input: groupURLName - custom URL name of the group to get
--		  pageNumber - number of the page to get
-- Output: error code, comments page
-------------------------------------------------------------------------------
function getAllCommentsPage( groupURLName, pageNumber )
	pageNumber = pageNumber or ""
	if ( pageNumber ~= "" ) then
		pageNumber = "?p=" .. pageNumber
	end
	local r, c = http.get( steamcommunity.rootURL .. "/groups/" .. groupURLName .. "/allcomments" .. pageNumber )
	if ( c == 200 ) then
		return 0, r
	else
		return 1, nil
	end
end

-------------------------------------------------------------------------------
-- thread.getPageInfo()
-- Purpose: Returns the current page number, and total page count
-- Input: commentsPage - string of the requested page
-- Output: current page number, total page count
-------------------------------------------------------------------------------
function getPageInfo( commentsPage )
	local currentPage, pageCount = string.match( commentsPage, pageLinksPattern )
	currentPage, pageCount = tonumber( currentPage ), tonumber( pageCount )
	return currentPage, pageCount
end

-------------------------------------------------------------------------------
-- thread.getCommentsInPage()
-- Purpose: Returns all comments on a given comments page
-- Input: commentsPage - string of the requested page
-- Output: table of comments
-------------------------------------------------------------------------------
function getCommentsInPage( commentsPage )
	local t = {}
	for deleteLink,
		status,
		memberURL,
		avatar,
		username,
		timestamp,
		commentContent
		in string.gmatch( commentsPage, commentBlockPattern ) do
		local comment				= comment()
		if ( deleteLink ~= "&nbsp;" ) then
			comment.deleteLink		= string.match( deleteLink, "linkStandard\" href=\"(.-)\"" )
		end
		comment.member				= member()
		comment.member.status		= status
		comment.member.memberURL	= memberURL
		comment.member.avatar		= avatar
		comment.member.username		= username
		comment.timestamp			= timestamp
		comment.commentContent		= string.gsub( commentContent, "^%s*(.-)%s*$", "%1" )
		table.insert( t, comment )
	end
	return t
end
