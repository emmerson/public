-------------------------------------------------------------------------------
-- Comment module and class definition
-- Steam Community Utilities
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local http = require( "steamcommunity.http" )
local setmetatable = setmetatable

module( "steamcommunity.comment" )

-------------------------------------------------------------------------------
-- comment
-- Purpose: Class index
-------------------------------------------------------------------------------
local comment = {}

-------------------------------------------------------------------------------
-- __metatable
-- Purpose: Class metatable
-------------------------------------------------------------------------------
__metatable = {
	__index = comment,
	__type = "comment"
}

-------------------------------------------------------------------------------
-- comment.new()
-- Purpose: Creates a new comment object
-- Output: comment
-------------------------------------------------------------------------------
function new()
	local t = {
		deleteLink = nil,
		member = nil,
		timestamp = nil,
		commentContent = nil
	}
	setmetatable( t, __metatable )
	return t
end

-------------------------------------------------------------------------------
-- comment()
-- Purpose: Shortcut to comment.new()
-- Output: comment
-------------------------------------------------------------------------------
local metatable = {
	__call = function( _, ... )
		return new( ... )
	end
}
setmetatable( _M, metatable )

-------------------------------------------------------------------------------
-- comment:delete()
-- Purpose: Deletes a comment, returns 0 if successful, 1 otherwise
-- Output: error code
-------------------------------------------------------------------------------
function comment:delete()
	if ( self.deleteLink ) then
		local r, c = http.get( self.deleteLink )
		return c == 200 and 0 or 1
	else
		return 1
	end
end

-------------------------------------------------------------------------------
-- comment:__tostring()
-- Purpose: __tostring metamethod for comment
-------------------------------------------------------------------------------
function __metatable:__tostring()
	if not self.member then return "invalid comment" end
	return "comment: " .. self.member.username
end
