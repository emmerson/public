-------------------------------------------------------------------------------
-- Member module and class definition
-- Steam Community Utilities
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local http = require( "steamcommunity.http" )
local setmetatable = setmetatable

module( "steamcommunity.member" )

-------------------------------------------------------------------------------
-- member
-- Purpose: Class index
-------------------------------------------------------------------------------
local member = {}

-------------------------------------------------------------------------------
-- __metatable
-- Purpose: Class metatable
-------------------------------------------------------------------------------
__metatable = {
	__index = member,
	__type = "member"
}

-------------------------------------------------------------------------------
-- member.new()
-- Purpose: Creates a new member object
-- Output: member
-------------------------------------------------------------------------------
function new()
	local t = {
		kickLink = nil,
		status = nil,
		memberURL = nil,
		avatar = nil,
		username = nil,
	}
	setmetatable( t, __metatable )
	return t
end

-------------------------------------------------------------------------------
-- member()
-- Purpose: Shortcut to member.new()
-- Output: member
-------------------------------------------------------------------------------
local metatable = {
	__call = function( _, ... )
		return new( ... )
	end
}
setmetatable( _M, metatable )

-------------------------------------------------------------------------------
-- member:kick()
-- Purpose: Kicks a member from a group, returns 0 if successful, 1 otherwise
-- Output: error code
-------------------------------------------------------------------------------
function member:kick()
	if ( self.kickLink ) then
		local r, c = http.get( self.kickLink )
		return c == 200 and 0 or 1
	else
		return 1
	end
end

-------------------------------------------------------------------------------
-- member:__tostring()
-- Purpose: __tostring metamethod for member
-------------------------------------------------------------------------------
function __metatable:__tostring()
	if not self.username then return "invalid member" end
	return "member: " .. self.username
end
