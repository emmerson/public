-- grabs all comments on page one of a given group

local groupURLName = "phoenixerveinc"

local steamcommunity	= require( "steamcommunity" )
local comments			= steamcommunity.comments

require( "connectors.luasocket" )

local error, commentsPage = -1, ""
while error ~= 0 do
	error, commentsPage = comments.getAllCommentsPage( groupURLName )
end

local comments = comments.getCommentsInPage( commentsPage )
for _, comment in pairs( comments ) do
	print( comment )
	print( "\t delete link: " .. tostring( comment.deleteLink ) )
	print( "\t " .. tostring( comment.member ) )
	print( "\t\t status: " .. tostring( comment.member.status ) )
	print( "\t\t member url: " .. tostring( comment.member.memberURL ) )
	print( "\t\t avatar: " .. tostring( comment.member.avatar ) )
	print( "\t\t username: " .. tostring( comment.member.username ) )
	print( "\t timestamp: " .. tostring( comment.timestamp ) )
	print( "\t comment content: " .. tostring( comment.commentContent ) )
	print( "\n" )
end
