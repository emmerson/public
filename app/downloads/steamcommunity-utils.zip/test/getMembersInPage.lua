-- grabs all members on page one of a given group

local groupURLName = "maxofs2d"

local steamcommunity	= require( "steamcommunity" )
local members			= steamcommunity.members

require( "connectors.luasocket" )

local error, membersManagePage = -1, ""
while error ~= 0 do
	error, membersManagePage = members.getMembersManagePage( groupURLName )
end

local members = members.getMembersInPage( membersManagePage )
for _, member in pairs( members ) do
	print( member )
	print( "\t\t member url: " .. tostring( member.memberURL ) )
	print( "\t\t avatar: " .. tostring( member.avatar ) )
	print( "\t\t username: " .. tostring( member.username ) )
	print( "\t kick link: " .. tostring( member.kickLink ) )
	print( "\n" )
end
