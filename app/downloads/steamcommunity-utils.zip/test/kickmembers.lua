-- kicks all members from a given group
-- usage: lua test\kickmembers.lua

local groupURLName	= "maxofs2d"

local steamcommunity	= require( "steamcommunity" )
local members			= steamcommunity.members

require( "connectors.luasocket" )

local error, membersManagePage = -1, ""
while error ~= 0 do
	error, membersManagePage = members.getMembersManagePage( groupURLName, 1 )
end

local currentPage, pageCount = members.getPageInfo( membersManagePage )
local activeMembers = {}
for i = 1, pageCount do
	if ( i ~= 1 ) then
		error, membersManagePage = -1, ""
		while error ~= 0 do
			error, membersManagePage = members.getMembersManagePage( groupURLName, i )
		end
	end
	print( "Parsing page " .. i )
	activeMembers = members.getMembersInPage( membersManagePage )
	for _, member in pairs( activeMembers ) do
		print( "Kicking " .. member.username .. " from " .. groupURLName .. "...")
		member:kick()
	end
end
