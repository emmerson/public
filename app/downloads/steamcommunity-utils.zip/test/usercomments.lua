-- dumps a specific user's comments to standard output
-- usage: lua test\usercomments.lua

local username		= "Andrew McWatters"
local groupURLName	= "hl2sb"

local steamcommunity	= require( "steamcommunity" )
local comments			= steamcommunity.comments

require( "connectors.luasocket" )

local error, commentsPage = -1, ""
while error ~= 0 do
	error, commentsPage = comments.getAllCommentsPage( groupURLName, 1 )
end

local currentPage, pageCount = comments.getPageInfo( commentsPage )
local userComments = {}
for i = 1, pageCount do
	if ( i ~= 1 ) then
		error, commentsPage = -1, ""
		while error ~= 0 do
			error, commentsPage = comments.getAllCommentsPage( groupURLName, i )
		end
	end
	print( "Parsing page " .. i )
	userComments = comments.getCommentsInPage( commentsPage )
	for _, comment in pairs( userComments ) do
		if ( comment.member.username == username ) then
			print( comment.member.username .. ": " .. comment.commentContent .. "\n" )
		end
	end
end
