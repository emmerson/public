--======== Copyright © 2013, Andrew McWatters, All rights reserved. =========--
--
-- Purpose: Client monitor implementation
--
--===========================================================================--

net.Receive( "Filesystem Lua Monitor", function( len, pl )
	local filepath = net.ReadString()
	local chunk	   = net.ReadString()
	print( "Reloading " .. filepath .. "..." )
	chunk = CompileString( chunk, filepath, false )
	if ( chunk and type( chunk ) == "function" ) then
		local status, err = pcall( chunk )
		if ( status == false ) then
			print( err )
		end
	else
		print( chunk )
	end
end )
