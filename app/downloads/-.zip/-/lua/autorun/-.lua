--======== Copyright © 2013, Andrew McWatters, All rights reserved. =========--
--
-- Purpose: Watch implementation
--
--===========================================================================--

if ( SERVER ) then
	util.AddNetworkString( "Filesystem Lua Monitor" )
	AddCSLuaFile( "autorun/client/-.lua" )
end

package.watched = package.watched or {}

function watch()
	if ( package.watching ) then
		return
	end
	local filepath	= debug.getinfo( debug.getinfo( 2, "f" ).func ).short_src
	local filename	= string.GetFileFromFilename( filepath )
	local tree		= {}
	local foundRoot = false
	for dir in string.gmatch( filepath, "(.-)/" ) do
		if ( foundRoot ) then
			table.insert( tree, dir )
		end
		if ( dir == "lua" ) then
			foundRoot = true
		end
	end
	if ( #tree >= 1 ) then
		filepath = tree[ 1 ]
		table.remove( tree, 1 )
		for _, v in ipairs( tree ) do
			filepath = filepath .. "/" .. v
		end
	end
	filepath = filepath .. "/" .. filename
	table.insert( package.watched, {
		path	= filepath,
		modtime = file.Time( filepath, "LUA" )
	} )
end

hook.Add( "Initialize", "Filesystem Lua Monitor", function()
	package.watching = true

if ( SERVER ) then
	RunConsoleCommand( "sv_kickerrornum", "0" )
end
end )

local filesystem = file
local file		 = nil
local filepath	 = ""
local modtime	 = -1

hook.Add( "Tick", "Filesystem Lua Monitor", function()
	for i = #package.watched, 1, -1 do
		file	 = package.watched[ i ]
		filepath = file.path
if ( SERVER ) then
		modtime	 = filesystem.Time( filepath, "LUA" )
		if ( modtime ~= file.modtime ) then
			print( "Reloading " .. filepath .. "..." )
			-- HACKHACK: Reincluding just reloads the cached script. Since
			-- we're ultimately just loading the chunk again, read the file and
			-- load the string to avoid loading from the cache.
			local chunk = filesystem.Read( filepath, "LUA" )
			local code	= chunk
			if ( chunk ) then
				chunk = CompileString( chunk, filepath, false )
				if ( chunk and type( chunk ) == "function" ) then
					local status, err = pcall( chunk )
					if ( status == false ) then
						print( err )
					else
						net.Start( "Filesystem Lua Monitor" )
							net.WriteString( filepath )
							net.WriteString( code )
						net.Broadcast()
					end
				else
					print( chunk )
				end
			else
				print( "Missing " .. filepath .. "!" )
			end
			file.modtime = filesystem.Time( filepath, "LUA" )
		end
end
	end
end )

watch()
