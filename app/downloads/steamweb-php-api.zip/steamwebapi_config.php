<?php
/**
 * Steam Web PHP API
 */

const STEAM_WEB_API_KEY = '';
