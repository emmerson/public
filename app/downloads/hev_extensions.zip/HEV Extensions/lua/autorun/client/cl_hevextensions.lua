
include( "hud_functions.lua" )

ENT_PROJECTILE = {

	"grenade",
	"missile"

}

local function CHudProjectileIndicator()

	local player			= LocalPlayer()

	if ( !GetConVarBool( "r_drawhud" ) ) then return end
	if ( !player:Alive() ) then return end

	// Ask the gamemode if it's ok to do this
	if ( !gamemode.Call( "HUDShouldDraw", "CHudProjectileIndicator" ) ) then return end

	local text_font			= "Marlett"

	surface.SetFont( text_font )

	for k, Entity in pairs( ents.GetAll() ) do

		if ( Entity && Entity:IsValid() ) then

			for l, projectile in pairs( ENT_PROJECTILE ) do

				if ( string.find( Entity:GetClass(), projectile ) ) then

					local ENTITY	= Entity:GetClass()
					ENTITY			= ENTITY:upper()

					local pos		= Entity:LocalToWorld( Entity:OBBCenter() ):ToScreen()
					local text_xpos	= pos.x
					local text_ypos	= pos.y - surface.SScale( 32 )

					if ( pos.visible ) then

						local ARROW		= "6"

						Width, Height	= surface.GetTextSize( ARROW )

						draw.DrawText( ARROW,		text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_CENTER )

						text_font		= "HudSelectionText"

						surface.SetFont( text_font )

						local DISTANCE	= math.Round( player:GetPos():Distance( Entity:GetPos() ) / 12 ) .. " ft"

						Width, Height	= surface.GetTextSize( DISTANCE )

						text_ypos		= text_ypos - Height

						draw.DrawText( DISTANCE,	text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_CENTER )

						Width, Height	= surface.GetTextSize( ENTITY )

						text_ypos		= text_ypos - Height

						draw.DrawText( ENTITY,		text_font, text_xpos, text_ypos, color_white, TEXT_ALIGN_CENTER )

					end

				end

			end

		end

	end

end

hook.Add( "HUDPaint", "CHudProjectileIndicator", CHudProjectileIndicator )

