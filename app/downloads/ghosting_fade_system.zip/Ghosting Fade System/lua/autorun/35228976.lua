
local gmod_ghost_fadetime = CreateConVar( "gmod_ghost_fadetime", 10.0, { FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED } )

local function GhostThink()

	for _, prop in pairs( ents.FindByClass( "gmod_ghost" ) ) do

		if ( !prop.m_flFadeTime ) then

			prop.m_flFadeTime	= CurTime() + gmod_ghost_fadetime:GetFloat()
			prop.m_angLastAng	= prop:GetAngles()
			prop.m_vecLastPos	= prop:GetPos()

		elseif ( CurTime() >= prop.m_flFadeTime ) then

			if ( prop.m_angLastAng == prop:GetAngles() &&
				 prop.m_vecLastPos == prop:GetPos() ) then

				prop.m_bFadeOut		= true

			else

				prop.m_flFadeTime	= nil
				prop.m_bFadeOut		= false

			end

		end

		if ( prop.m_bFadeOut != nil ) then

			local r, g, b, a = prop:GetColor()

			if ( prop.m_bFadeOut == true ) then

				a = a - 2

			else

				a = a + 2

			end

			a = math.Clamp( a, 0, 150 )

			prop:SetColor( r, g, b, a )

		end

	end

end

hook.Add( "Think", "GhostThink", GhostThink )

