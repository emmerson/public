

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_ioncannon.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_ioncannon.vtf" )

	AddCSLuaFile( "shared.lua" )

	SWEP.HoldType			= "rpg"

end

if ( CLIENT ) then

	language.Add( "HL2_Ion_Cannon", "ION CANNON" )

	SWEP.PrintName			= "#HL2_Ion_Cannon"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "2"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:DrawWorldModel()

		local pPlayer = self.Owner;

		if ( !ValidEntity( pPlayer ) ) then
			self.Weapon:DrawModel();
			return;
		end

		if ( !self.m_hHands ) then
			self.m_hHands = pPlayer:LookupAttachment( "anim_attachment_rh" );
		end

		local hand = pPlayer:GetAttachment( self.m_hHands );

		local offset = hand.Ang:Right() * self.HoldPos.x + hand.Ang:Forward() * self.HoldPos.y + hand.Ang:Up() * self.HoldPos.z;

		hand.Ang:RotateAroundAxis( hand.Ang:Right(),	self.HoldAng.x );
		hand.Ang:RotateAroundAxis( hand.Ang:Forward(),	self.HoldAng.y );
		hand.Ang:RotateAroundAxis( hand.Ang:Up(),		self.HoldAng.z );

		self.Weapon:SetRenderOrigin( hand.Pos + offset )
		self.Weapon:SetRenderAngles( hand.Ang )

		self.Weapon:DrawModel()

	end

end


SWEP.Base				= "swep_ar2"
SWEP.Category			= "Half-Life 2"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.WorldModel			= "models/Combine_turrets/combine_cannon_gun.mdl"

SWEP.Primary.Sound			= Sound( "NPC_Combine_Cannon.FireBullet" )
SWEP.Primary.Damage			= 25
SWEP.Primary.Cone			= VECTOR_CONE_3DEGREES
SWEP.Primary.Delay			= 0.75
SWEP.Primary.Force			= 10
// SWEP.Primary.Ammo			= "CombineHeavyCannon"
SWEP.Primary.Tracer			= 0

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "None"

SWEP.HoldPos 			= Vector( -5, 2, -12 )
SWEP.HoldAng			= Vector( 17, -5, 60 )

PrecacheParticleSystem( "Weapon_Combine_Ion_Cannon" )

function SWEP:SecondaryAttack()

	if ( !self:CanSecondaryAttack() ) then return end

	self:ToggleZoom();

end

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	local pHL2MPPlayer = pPlayer;

	local info = {};
	info.Num = num_bullets;
	info.Src = pHL2MPPlayer:GetShootPos();
	info.Force = self.Primary.Force;
	info.Dir = pPlayer:GetAimVector();
	info.Spread = aimcone;
	info.Damage = damage;
	info.Tracer = self.Primary.Tracer;
	info.TracerName = self.Primary.TracerName;

	info.Owner = self.Owner
	info.Weapon = self.Weapon

	info.DoImpactEffect = self.DoImpactEffect;
	info.ShootCallback = self.ShootCallback;

	info.Callback = function( attacker, trace, dmginfo )
		return info:ShootCallback( attacker, trace, dmginfo );
	end

	pPlayer:gFireBullets( info );

end

function SWEP:ShootCallback( attacker, trace, dmginfo )

	local pOwner = self.Owner;

	if ( !pOwner ) then
		return;
	end

	local	vForward, vRight, vUp;

	vForward = pOwner:GetForward();
	vRight = pOwner:GetRight();
	vUp = pOwner:GetUp();

	local	muzzlePoint = pOwner:GetShootPos() + vForward * 12.0 + vRight * 3.5 + vUp * -3.0;

if ( !CLIENT ) then
	local PrimaryDelay = FrameTime() * 5

	local hEnd = ents.Create( "info_particle_system" )
	hEnd:SetKeyValue( "effect_name", "Weapon_Combine_Ion_Cannon" )
	hEnd:SetName( "info_particle_system" .. " (" .. pOwner:EntIndex() .. ")" )
	hEnd:SetPos( trace.HitPos )
	hEnd:Spawn()
	hEnd:Activate()
	hEnd:Fire( "Kill", nil, PrimaryDelay )

	local hStart = ents.Create( "info_particle_system" )
	hStart:SetKeyValue( "effect_name", "Weapon_Combine_Ion_Cannon" )
	hStart:SetKeyValue( "cpoint1", hEnd:GetName() )
	hStart:SetKeyValue( "start_active", tostring( 1 ) )
	hStart:SetPos( muzzlePoint )
	hStart:Spawn()
	hStart:Activate()
	hStart:Fire( "Kill", nil, PrimaryDelay )
end

end

function SWEP:Holster( wep )

	if ( self.m_bInZoom ) then
		self:ToggleZoom();
	end

	return self.BaseClass:Holster( wep );

end

local PrimaryCone = SWEP.Primary.Cone

function SWEP:ToggleZoom()

	local pPlayer = self.Owner;

	if ( pPlayer == NULL ) then
		return;
	end

if ( !CLIENT ) then

	if ( self.m_bInZoom ) then
		pPlayer:SetCanZoom( true )
		pPlayer:SetFOV( 0, 0.2 )
		self.m_bInZoom = false;
		self.Primary.Cone = PrimaryCone;
	else
		pPlayer:SetCanZoom( false )
		pPlayer:SetFOV( 20, 0.1 )
		self.m_bInZoom = true;
		self.Primary.Cone = vec3_origin;
	end
else

	if ( self.m_bInZoom ) then
		self.m_bInZoom = false;
		self.Primary.Cone = PrimaryCone;
	else
		self.m_bInZoom = true;
		self.Primary.Cone = vec3_origin;
	end
end

end
