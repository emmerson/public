
if ( SPropProtection ) then

	SPropProtection.HUDPaint = nil
	hook.Remove( "HUDPaint", "SPropProtection.HUDPaint" )

end

local function CHudOwner()

	local player = LocalPlayer()

	if ( !GetConVarBool( "r_drawhud" ) ) then return end
	if ( !GetConVarBool( "spp_check" ) ) then return end

	if ( !GAMEMODE.IsSandboxDerived ) then return end
	if ( SinglePlayer() ) then return end
	if ( !player:Alive() ) then return end

	// Ask the gamemode if it's ok to do this
	if ( !gamemode.Call( "HUDShouldDraw", "CHudOwner" ) ) then return end

	local vStart	= player:GetShootPos()
	local vForward	= player:GetCursorAimVector()

	local trace		= {}
	trace.start		= vStart
	trace.endpos	= vStart + ( vForward * 2048 )
	trace.filter	= player

	if ( player:InVehicle() ) then

		trace.filter = {

			player,
			player:GetVehicle()

		}

	end

	local tr = util.TraceLine( trace )

	if ( !tr.Entity ) then return end
	if ( !tr.Entity:IsValid() ) then return end
	if ( tr.Entity:IsPlayer() ) then return end
	if ( !tr.Entity:GetNetworkedString( "Owner" ) ) then return end
	if ( tr.Entity:GetNetworkedString( "Owner" ) == "World" ) then return end
	if ( tr.Entity:GetNetworkedString( "Owner" ) == "" ) then return end

	local text_font = "HudSelectionText"

	surface.SetFont( text_font )

	local PLAYER = tr.Entity:GetNetworkedString( "Owner" )

	local Width, Height = surface.GetTextSize( PLAYER )

	local xpos	= surface.SScale( 16 )
	local ypos	= surface.SScale( 396 )
	local wide	= surface.SScale( 102 )
	local tall	= surface.SScale( 26 )

	if ( wide < Width + surface.SScale( 2 ) + surface.SScale( 50 ) + surface.SScale( 8 ) ) then

		wide = wide + surface.SScale( 2 ) - surface.SScale( 50 ) + Width + surface.SScale( 8 )

	end

	draw.RoundedBox( 8, xpos, ypos, wide, tall, Panel.BgColor )

	local OWNER		= Localize( "OWNER" )

	Width, Height	= surface.GetTextSize( OWNER )
	local text_xpos	= xpos + surface.SScale( 8 )
	local text_ypos	= ypos + ( tall / 2 ) - ( Height / 2 )

	draw.DrawText( OWNER,	text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )

	text_xpos = text_xpos - surface.SScale( 8 ) + surface.SScale( 50 )

	draw.DrawText( PLAYER,	text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )

end

hook.Add( "HUDPaint", "CHudOwner", CHudOwner )

