
include( "hud_functions.lua" )

local r_drawaltimeter	= CreateClientConVar( "r_drawaltimeter", 1, true, false )

// This is the font that's used to draw the HUD numbers
surface.CreateFont( "HalfLife2", surface.SScale( 32 ), 0, true, true, "HudNumbers" )

local function CHudAltimeter()

	local player	= LocalPlayer()

	if ( !GetConVarBool( "r_drawhud" ) ) then return end
	if ( !GetConVarBool( "r_drawaltimeter" ) ) then return end
	if ( !player:Alive() ) then return end

	// Ask the gamemode if it's ok to do this
	if ( !gamemode.Call( "HUDShouldDraw", "CHudAltimeter" ) ) then return end

	local text_font		= "HudNumbers"
	local FgColor		= Panel.FgColor
	local BgColor		= Panel.BgColor

	surface.SetFont( text_font )

	local int			= math.Round( util.QuickTrace( player:GetPos(), player:GetPos() - Vector( 0, 0, 163840 ), player ).HitPos:Distance( player:GetPos() ) / 12 )

	if ( util.PointContents( player:GetPos() ) == CONTENTS_SOLID ) then

		int				= 0
		FgColor			= DamagedFg
		// BgColor			= DamagedBg

	end

	local Width, Height	= surface.GetTextSize( int )

	local xpos	= surface.SScale( 270 )
	local ypos	= surface.SScale( 432 )
	local wide	= surface.SScale( 108 )
	local tall	= surface.SScale( 36 )

	if ( ( player:Armor() <= 0 || !gamemode.Call( "HUDShouldDraw", "CHudArmor" ) ) ) then

		xpos	= surface.SScale( 140 )

	end

	if ( wide < Width + surface.SScale( 2 ) + surface.SScale( 50 ) + surface.SScale( 8 ) ) then

		wide	= wide + surface.SScale( 2 ) - surface.SScale( 50 ) + Width + surface.SScale( 8 )

	end

	draw.RoundedBox( 8, xpos, ypos, wide, tall, BgColor )

	local text_font		= "HudSelectionText"

	surface.SetFont( text_font )

	local ALTIMETER		= Localize( "ALTIMETER" )

	Width, Height		= surface.GetTextSize( ALTIMETER )
	local text_xpos		= xpos + surface.SScale( 8 )
	local text_ypos		= ypos + tall - surface.SScale( 20 ) + ( Height / 2 )

	draw.DrawText( ALTIMETER,	text_font, text_xpos, text_ypos, FgColor, TEXT_ALIGN_LEFT )

	local text_font		= "HudNumbers"

	surface.SetFont( text_font )

	text_xpos	= text_xpos + surface.SScale( 50 )
	text_ypos	= surface.SScale( 432 ) + surface.SScale( 2 )

	draw.DrawText( int,			text_font, text_xpos, text_ypos, FgColor, TEXT_ALIGN_LEFT )

end

hook.Add( "HUDPaint", "CHudAltimeter", CHudAltimeter )

