
hook.Add( "PlayerInitialSpawn", "ServerSetup", function()

	local SandboxSettings = KeyValuesToTable( file.Read( "../gamemodes/sandbox/content/settings/server_settings/gmod.txt" ) )
	for k, v in pairs( SandboxSettings[ "settings" ] ) do

		game.ConsoleCommand( k .. " " .. v[ "default" ] .. "\n" )

	end

	hook.Remove( "PlayerInitialSpawn", "ServerSetup" )

end )

