
local sbox_gravgun = CreateConVar( "sbox_gravgun", 1, { FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED } )

local function PlayerLoadout( Player )

	if ( GAMEMODE.IsSandboxDerived ) then

		if ( sbox_gravgun:GetBool() ) then

			Player:Give( "weapon_physcannon" )

		end

	end

end

hook.Add( "PlayerLoadout", "PlayerLoadout", PlayerLoadout )
