
//
// The server only runs this file so it can send it to the client
//

if ( SERVER ) then AddCSLuaFile( "dod_playerclothes.lua" ) end

---Americans
list.Set( "PlayerOptionsClothing", "american_assault", "models/player/dod_american.mdl" )
player_manager.AddValidModel( "american_assault", "models/player/dod_american.mdl" )

---German
list.Set( "PlayerOptionsClothing", "german_assault", "models/player/dod_german.mdl" )
player_manager.AddValidModel( "german_assault", "models/player/dod_german.mdl" )
