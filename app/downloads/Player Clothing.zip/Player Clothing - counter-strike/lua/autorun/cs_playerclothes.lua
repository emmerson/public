
//
// The server only runs this file so it can send it to the client
//

if ( SERVER ) then AddCSLuaFile( "cs_playerclothes.lua" ) end

----Counter terrorists
list.Set( "PlayerOptionsClothingMF", "urban", "models/player/urban.mdl" )
player_manager.AddValidModel( "urban", "models/player/urban.mdl" )

list.Set( "PlayerOptionsClothingMF", "swat", "models/player/swat.mdl" )
player_manager.AddValidModel( "swat", "models/player/swat.mdl" )

list.Set( "PlayerOptionsClothingMF", "gasmask", "models/player/gasmask.mdl" )
player_manager.AddValidModel( "gasmask", "models/player/gasmask.mdl" )

list.Set( "PlayerOptionsClothingMF", "riot", "models/player/riot.mdl" )
player_manager.AddValidModel( "riot", "models/player/riot.mdl" )

----Terrorists
list.Set( "PlayerOptionsClothingMF", "leet", "models/player/leet.mdl" )
player_manager.AddValidModel( "leet", "models/player/leet.mdl" )

list.Set( "PlayerOptionsClothingMF", "guerilla", "models/player/guerilla.mdl" )
player_manager.AddValidModel( "guerilla", "models/player/guerilla.mdl" )

list.Set( "PlayerOptionsClothingMF", "phoenix", "models/player/Phoenix.mdl" )
player_manager.AddValidModel( "phoenix", "models/player/Phoenix.mdl" )

list.Set( "PlayerOptionsClothingMF", "arctic", "models/player/arctic.mdl" )
player_manager.AddValidModel( "arctic", "models/player/arctic.mdl" )

------Hostages
list.Set( "PlayerOptionsClothingMF", "hostage_01", "models/player/Hostage/Hostage_01.mdl" )
player_manager.AddValidModel( "hostage_01", "models/player/Hostage/Hostage_01.mdl" )

list.Set( "PlayerOptionsClothingMF", "hostage_02", "models/player/Hostage/Hostage_02.mdl" )
player_manager.AddValidModel( "hostage_02", "models/player/Hostage/Hostage_02.mdl" )

list.Set( "PlayerOptionsClothingMF", "hostage_03", "models/player/Hostage/Hostage_03.mdl" )
player_manager.AddValidModel( "hostage_03", "models/player/Hostage/Hostage_03.mdl" )

list.Set( "PlayerOptionsClothingMF", "hostage_04", "models/player/Hostage/Hostage_04.mdl" )
player_manager.AddValidModel( "hostage_04", "models/player/Hostage/Hostage_04.mdl" )