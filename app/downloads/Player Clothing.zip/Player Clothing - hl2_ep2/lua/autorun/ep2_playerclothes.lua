
//
// The server only runs this file so it can send it to the client
//

if ( SERVER ) then AddCSLuaFile( "ep2_playerclothes.lua" ) end

list.Set( "PlayerOptionsClothing", "magnusson", "models/player/magnusson.mdl" )
player_manager.AddValidModel( "magnusson", "models/player/magnusson.mdl" )
