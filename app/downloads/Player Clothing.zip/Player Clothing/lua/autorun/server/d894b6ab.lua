

local GM = {}

/*---------------------------------------------------------
   Name: gamemode:PlayerDeath( )
   Desc: Called when a player dies.
---------------------------------------------------------*/
local function PlayerDeath( Victim, Inflictor, Attacker )

	if ( ValidEntity( Victim.m_hClothing ) ) then
		Victim.m_hModel:SetParent( Victim:GetRagdollEntity() )
		Victim.m_hModel:Initialize()
		Victim.m_hClothing:SetParent( Victim:GetRagdollEntity() )
		Victim.m_hClothing:Initialize()
	end

end

hook.Add( "PlayerDeath", "PlayerRemoveClothing", PlayerDeath )

local function RemovePlayerClothing( ply )

	if ( ply.m_hClothing && ply.m_hClothing:IsValid() ) then

		ply.m_hModel:Remove()
		ply.m_hModel = nil
		ply.m_hClothing:Remove()
		ply.m_hClothing = nil

		ply:SetMaterial( "" )

	end

end

/*---------------------------------------------------------
   Name: gamemode:PlayerInitialSpawn( )
   Desc: Called just before the player's first spawn
---------------------------------------------------------*/
local function PlayerInitialSpawn( pl )

	// Delay set player clothing
	timer.Simple( 0.1, function()
		hook.Call( "PlayerSetClothing", GM, pl )
	end )

end

hook.Add( "PlayerInitialSpawn", "PlayerSetClothing", PlayerInitialSpawn )

/*---------------------------------------------------------
   Name: gamemode:PlayerSpawn( )
   Desc: Called when a player spawns
---------------------------------------------------------*/
local function PlayerSpawn( pl )

	// Set player clothing
	hook.Call( "PlayerSetClothing", GM, pl )

end

hook.Add( "PlayerSpawn", "PlayerSetClothing", PlayerSpawn )

/*---------------------------------------------------------
   Name: gamemode:PlayerSetClothing( )
   Desc: Set the player's clothing
---------------------------------------------------------*/
function GM:PlayerSetClothing( pl )

	RemovePlayerClothing( pl )
	local cl_playerclothing = pl:GetInfo( "cl_playerclothing" )
	if ( cl_playerclothing == "" ) then return end
	if ( cl_playerclothing == "none" ) then return end
	local modelname = player_manager.TranslatePlayerModel( cl_playerclothing )
	util.PrecacheModel( modelname )
	pl.m_hModel = ents.Create( "player_model" )
	pl.m_hModel:SetParent( pl )
	pl.m_hModel:SetPos( pl:GetPos() )
	pl.m_hModel:SetAngles( pl:GetAngles() )
	pl.m_hModel:Spawn()
	pl.m_hClothing = ents.Create( "player_clothing" )
	pl.m_hClothing:SetModel( modelname )
	pl.m_hClothing:SetParent( pl )
	pl.m_hClothing:SetPos( pl:GetPos() )
	pl.m_hClothing:SetAngles( pl:GetAngles() )
	pl.m_hClothing:Spawn()

end
