
// Some client info CVars

// These are mainly for the benefit of gamemodes so players don't have to
// fill this information in on every gamemode that wants a peice of it.

CreateClientConVar( "cl_playerclothing", "none"	, true, true )