
//
// The server only runs this file so it can send it to the client
//

if ( SERVER ) then AddCSLuaFile( "clothing_menu.lua" ) return end

//
// The PlayerOptionsClothing defines which models will
// appear on the player clothing menu. It doesn't define
// which models are valid. Just which choices will appear.
//
// Look at player_manager to see how to define which models
// are valid.
//

list.Set( "PlayerOptionsClothing", "kleiner", 	"models/player/Kleiner.mdl" )
list.Set( "PlayerOptionsClothing", "mossman", 	"models/player/mossman.mdl" )
list.Set( "PlayerOptionsClothing", "alyx", 		"models/player/alyx.mdl" )
list.Set( "PlayerOptionsClothing", "barney", 	"models/player/barney.mdl" )
list.Set( "PlayerOptionsClothing", "breen", 	"models/player/breen.mdl" )
list.Set( "PlayerOptionsClothingMF", "odessa", 	"models/player/odessa.mdl" )
//list.Set( "PlayerOptionsClothingMF", "zombie", 	"models/player/classic.mdl" )
//list.Set( "PlayerOptionsClothingMF", "charple", "models/player/charple01.mdl" )
list.Set( "PlayerOptionsClothingMF", "combine", "models/player/combine_soldier.mdl" )
list.Set( "PlayerOptionsClothingMF", "prison", 	"models/player/combine_soldier_prisonguard.mdl" )
list.Set( "PlayerOptionsClothingMF", "super", 	"models/player/combine_super_soldier.mdl" )
list.Set( "PlayerOptionsClothingMF", "police", 	"models/player/police.mdl" )
list.Set( "PlayerOptionsClothing", "gman", 		"models/player/gman_high.mdl" )
list.Set( "PlayerOptionsClothing", "stripped", 	"models/player/soldier_stripped.mdl" )
//list.Set( "PlayerOptionsClothingMF", "fzombie", "models/player/Zombiefast.mdl" )

list.Set( "PlayerOptionsClothingMF", "female1",	"models/player/Group01/female_01.mdl" )
list.Set( "PlayerOptionsClothingMF", "female2",	"models/player/Group01/female_02.mdl" )
list.Set( "PlayerOptionsClothingMF", "female3",	"models/player/Group01/female_03.mdl" )
list.Set( "PlayerOptionsClothingMF", "female4",	"models/player/Group01/female_04.mdl" )
list.Set( "PlayerOptionsClothingMF", "female5",	"models/player/Group01/female_06.mdl" )
list.Set( "PlayerOptionsClothingMF", "female6",	"models/player/Group01/female_07.mdl" )
list.Set( "PlayerOptionsClothingMF", "female7",	"models/player/Group03/female_01.mdl" )
list.Set( "PlayerOptionsClothingMF", "female8",	"models/player/Group03/female_02.mdl" )
list.Set( "PlayerOptionsClothingMF", "female9",	"models/player/Group03/female_03.mdl" )
list.Set( "PlayerOptionsClothingMF", "female10","models/player/Group03/female_04.mdl" )
list.Set( "PlayerOptionsClothingMF", "female11","models/player/Group03/female_06.mdl" )
list.Set( "PlayerOptionsClothingMF", "female12","models/player/Group03/female_07.mdl" )

list.Set( "PlayerOptionsClothingMF", "male1",	"models/player/Group01/male_01.mdl" )
list.Set( "PlayerOptionsClothingMF", "male2",	"models/player/Group01/male_02.mdl" )
list.Set( "PlayerOptionsClothingMF", "male3",	"models/player/Group01/male_03.mdl" )
list.Set( "PlayerOptionsClothingMF", "male4",	"models/player/Group01/male_04.mdl" )
list.Set( "PlayerOptionsClothingMF", "male5",	"models/player/Group01/male_05.mdl" )
list.Set( "PlayerOptionsClothingMF", "male6",	"models/player/Group01/male_06.mdl" )
list.Set( "PlayerOptionsClothingMF", "male7",	"models/player/Group01/male_07.mdl" )
list.Set( "PlayerOptionsClothingMF",  "male8",	"models/player/Group01/male_08.mdl" )
list.Set( "PlayerOptionsClothingMF",  "male9",	"models/player/Group01/male_09.mdl" )

list.Set( "PlayerOptionsClothingMF", "male10",	"models/player/Group03/male_01.mdl" )
list.Set( "PlayerOptionsClothingMF", "male11",	"models/player/Group03/male_02.mdl" )
list.Set( "PlayerOptionsClothingMF", "male12",	"models/player/Group03/male_03.mdl" )
list.Set( "PlayerOptionsClothingMF", "male13",	"models/player/Group03/male_04.mdl" )
list.Set( "PlayerOptionsClothingMF", "male14",	"models/player/Group03/male_05.mdl" )
list.Set( "PlayerOptionsClothingMF", "male15",	"models/player/Group03/male_06.mdl" )
list.Set( "PlayerOptionsClothingMF", "male16",	"models/player/Group03/male_07.mdl" )
list.Set( "PlayerOptionsClothingMF", "male17",	"models/player/Group03/male_08.mdl" )
list.Set( "PlayerOptionsClothingMF", "male18",	"models/player/Group03/male_09.mdl" )

// Todo: If owns ep1 or 2
//list.Set( "PlayerOptionsClothingMF", "zombine", "models/player/zombie_soldier.mdl" )

// Todo: If owns ep2 (Fix eyes first)
//list.Set( "PlayerOptionsClothing", "magnusson", 	"models/player/magnusson.mdl" )

local PlayerOptionsIncompatibleClothing = { "models/player/classic.mdl",
											"models/player/charple01.mdl",
											"models/player/Zombiefast.mdl",
											"models/player/zombie_soldier.mdl" }

local strInformation =  Localize( "Clothing_Notice", "This model has no clothes.")

//
//
//
local PANEL

local function PlayerClothing( CPanel )

	CPanel:ClearControls()

	PANEL = CPanel

	local PanelSelect = CPanel:PanelSelect()
	PanelSelect:SetAutoSize( true )

	local PlayerOptionsClothing = list.Get( "PlayerOptionsClothing" )
	local cl_playermodel = GetConVar( "cl_playermodel" ):GetString()
	local modelname = player_manager.TranslatePlayerModel( cl_playermodel )

	if ( table.HasValue( list.Get( "PlayerOptionsClothingMF" ), modelname ) ) then

		PlayerOptionsClothing = list.Get( "PlayerOptionsClothingMF" )

	end

	if ( table.HasValue( PlayerOptionsIncompatibleClothing, modelname ) ) then

		CPanel:Help( strInformation )
		PlayerOptionsClothing = {}

	end

	for name, clothing in pairs( PlayerOptionsClothing ) do

		local icon = vgui.Create( "SpawnIcon" )
		icon:SetModel( clothing )
		icon:SetSize( 64, 64 )
		icon:SetTooltip( name )

		PanelSelect:AddPanel( icon, { cl_playerclothing = name } )

	end

	// Work it out so we have 2 per row
	//local NumRows = Format( "%i", (table.Count(ClothingList)+1) / 2 )

	//local params = { Options = {}, ConVar = "cl_playerclothing", Label = "#PlayerClothing", Height = "100", Width = "100", Rows = NumRows }

	//for k, v in pairs( ClothingList ) do
	//	params.Options[ k ] = { Material = v, Value = k, cl_playerclothing = k }
	//end

	//CPanel:AddControl( "MaterialGallery", params )

end


local function OnChangeModel( name, oldvalue, newvalue )

	RunConsoleCommand( "cl_playerclothing", GetConVar( "cl_playerclothing" ):GetDefault() )

	if ( PANEL ) then
		PlayerClothing( PANEL )
	end

end

cvars.AddChangeCallback( "cl_playermodel", OnChangeModel )


local function OnChangeClothing( name, oldvalue, newvalue )

	if ( newvalue == GetConVar( name ):GetDefault() ) then return end
	if ( newvalue == oldvalue ) then return end

	local bModelIsMissingFinger = false
	local cl_playermodel = GetConVar( "cl_playermodel" ):GetString()
	local modelname = player_manager.TranslatePlayerModel( cl_playermodel )

	if ( newvalue == GetConVar( "cl_playermodel" ):GetString() ||
		 table.HasValue( PlayerOptionsIncompatibleClothing, modelname ) ) then

		RunConsoleCommand( "cl_playerclothing", GetConVar( "cl_playerclothing" ):GetDefault() )

	end

	if ( table.HasValue( list.Get( "PlayerOptionsClothingMF" ), modelname ) ) then

		bModelIsMissingFinger = true

	end

	local bClothingIsMissingFinger = false
	modelname = player_manager.TranslatePlayerModel( newvalue )

	if ( table.HasValue( list.Get( "PlayerOptionsClothingMF" ), modelname ) ) then

		bClothingIsMissingFinger = true

	end

	if ( bModelIsMissingFinger != bClothingIsMissingFinger ) then

		RunConsoleCommand( "cl_playerclothing", oldvalue )

	end

end

cvars.AddChangeCallback( "cl_playerclothing", OnChangeClothing )


/*
// Tool Menu
*/
local function PopulateClothingMenu()

	spawnmenu.AddToolMenuOption( "Options", "Player", "Clothing", "#Clothing", "", "", PlayerClothing )

end

hook.Add( "PopulateToolMenu", "PopulateClothingMenu", PopulateClothingMenu )

/*
// Tool Menu
*/
local function ClothingMenuOpen()

	if ( PANEL ) then
		PlayerClothing( PANEL )
	end

end

hook.Add( "SpawnMenuOpen", "ClothingMenuOpen", ClothingMenuOpen )

