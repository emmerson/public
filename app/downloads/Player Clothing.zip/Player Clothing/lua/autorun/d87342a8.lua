AddCSLuaFile( "client/eb95800f.lua" )
resource.AddFile( "materials/models/null.vmt" )
resource.AddFile( "materials/models/null.vtf" )
