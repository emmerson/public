
local meta = FindMetaTable( "PhysObj" )
if (meta.SetAngleVelocity) then return end

function meta:SetAngleVelocity( velocity )

	self:AddAngleVelocity( -self:GetAngleVelocity() + velocity )

end

