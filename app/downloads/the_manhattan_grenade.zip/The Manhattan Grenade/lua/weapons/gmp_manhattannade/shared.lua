

if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "Manhattannade"
	SWEP.Author				= "Nicolas Arduino"
	SWEP.IconLetter			= "4"

	killicon.AddFont( "sent_manhattannade", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_frag"
SWEP.Category			= "Garry's Mod Plus"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= true

SWEP.Primary.Damage			= 1024
SWEP.Primary.AmmoType		= "sent_manhattannade"
