
ENT.Sound				= {}
ENT.Sound.Blip			= "Grenade.Blip"
ENT.Sound.Explode		= "BaseGrenade.Explode"

ENT.Trail				= {}
ENT.Trail.Color			= Color( 3, 140, 199, 255 )
ENT.Trail.Material		= "sprites/bluelaser1.vmt"
ENT.Trail.StartWidth	= 8.0
ENT.Trail.EndWidth		= 1.0
ENT.Trail.LifeTime		= 1.0

local entClasses		= {

	"ai_",
	"func_",
	"gmod_ghost",
	"info_",
	"physgun_",
	"player_",
	"predicted_",
	"scene_",
	"trigger_"

}

local entConstraints	= {

	"Ballsocket",
	"Hydraulic",
	"Nail",
	"Slider",
	"Weld"

}

// Nice helper function, this does all the work.

/*---------------------------------------------------------
   Name: DoExplodeEffect
---------------------------------------------------------*/
function ENT:DoExplodeEffect()

	self.Entity:SetNetworkedBool( "m_bDetonated", true )

end

local function entInvalid( Entity )

	if ( Entity:GetClass() == "sent_manhattannade" ) then return true end
	if ( Entity:IsPlayer() ) then return true end
	if ( Entity:IsWeapon() ) then return true end

	for k, v in pairs( entClasses ) do

		if ( string.find( Entity:GetClass(), v ) ) then

			return true

		end

	end

	return false

end

/*---------------------------------------------------------
   Name: OnExplode
   Desc: The grenade has just exploded.
---------------------------------------------------------*/
function ENT:OnExplode( pTrace )

	if ( self.m_pGlowTrail && self.m_pGlowTrail:IsValid() ) then

		self.m_pGlowTrail:Remove()

	end

	local Pos1 = self.Entity:GetPos()
	local Pos2

	local Distance

	for k, v in pairs( ents.FindInSphere( Pos1, self:GetDamageRadius() ) ) do

		if ( v != self.Entity && !entInvalid( v ) && ( !constraint.HasConstraints( v ) || v.m_bIsRadiated ) ) then

			for l, w in pairs( entConstraints ) do

				constraint.RemoveConstraints( v, w )

			end

			Pos2 = v:GetPos()

			Distance = Pos1:Distance( Pos2 )

			if ( v:GetClass() == "prop_ragdoll" ) then

				for i = 1, v:GetPhysicsObjectCount() do

					local phys = v:GetPhysicsObjectNum( i )
					if (phys && phys:IsValid()) then
						phys:EnableGravity( false )
						phys:EnableMotion( true )
						phys:ApplyForceCenter( ( Pos2 - Pos1 ) * ( Distance * 3 ) )
						phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
					end

				end

			else

				local phys = v:GetPhysicsObject()
				if (phys:IsValid()) then
					phys:EnableGravity( false )
					phys:EnableMotion( true )
					phys:ApplyForceCenter( ( Pos2 - Pos1 ) * ( Distance * 3 ) )
					phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
				end

			end

			v:SetPhysicsAttacker( self:GetOwner() )
			table.insert( self.m_tRadiatedEntities, v )

		end

	end

	self.m_bDetonated			= true
	self.m_flPhysicsDuration	= CurTime() + 2.0
	self.Entity:SetNetworkedVector( "m_vecSingularityPos", self.Entity:GetPos() + Vector( 0, 0, 180 ) )

end

/*---------------------------------------------------------
   Name: OnInitialize
---------------------------------------------------------*/
function ENT:OnInitialize()
end

/*---------------------------------------------------------
   Name: StartTouch
---------------------------------------------------------*/
function ENT:StartTouch( entity )
end

/*---------------------------------------------------------
   Name: EndTouch
---------------------------------------------------------*/
function ENT:EndTouch( entity )
end

/*---------------------------------------------------------
   Name: Touch
---------------------------------------------------------*/
function ENT:Touch( entity )
end

/*---------------------------------------------------------
   Name: OnThink
---------------------------------------------------------*/
function ENT:OnThink()

	if ( !self.m_bDetonated ) then

		return

	end

	if ( !self.m_bHalted ) then

		for k, v in pairs( self.m_tRadiatedEntities ) do

			if ( v && v:IsValid() ) then

				if ( v:GetClass() == "prop_ragdoll" ) then

					for i = 1, v:GetPhysicsObjectCount() do

						local phys = v:GetPhysicsObjectNum( i )
						if (phys && phys:IsValid()) then
							phys:SetVelocity( phys:GetVelocity() / 2 )
						end

					end

				else

					local phys = v:GetPhysicsObject()
					if (phys:IsValid()) then
						phys:SetVelocity( phys:GetVelocity() / 2 )
					end

				end

			end

		end

		if ( CurTime() > self.m_flPhysicsDuration ) then

			self.m_bHalted				= true
			self.m_flPhysicsDuration	= CurTime() + 1.0

		end

	elseif ( CurTime() <= self.m_flPhysicsDuration ) then

		for k, v in pairs( self.m_tRadiatedEntities ) do

			if ( v && v:IsValid() ) then

				local vecDirection = self.Entity:GetNetworkedVector( "m_vecSingularityPos" ) - v:GetPos()

				if ( v:GetClass() == "prop_ragdoll" ) then

					for i = 1, v:GetPhysicsObjectCount() do

						for l, w in pairs( self.m_tRadiatedEntities ) do

							if ( w && w:IsValid() ) then

								constraint.RemoveConstraints( v, "NoCollide" )
								constraint.NoCollide( w, v, 0, i )

							end

						end

						local phys = v:GetPhysicsObjectNum( i )
						if (phys && phys:IsValid()) then
							phys:SetVelocity( vecDirection * ( vecDirection:Length() / 3 ) )
						end

					end

				else

					for l, w in pairs( self.m_tRadiatedEntities ) do

						if ( w && w:IsValid() ) then

							constraint.RemoveConstraints( v, "NoCollide" )
							constraint.NoCollide( w, v, 0, 0 )

						end

					end

					local phys = v:GetPhysicsObject()
					if (phys:IsValid()) then
						phys:SetVelocity( vecDirection * ( vecDirection:Length() / 3 ) )
					end

				end

			else

				table.remove( self.m_tRadiatedEntities, k )

			end

		end

		for k, v in pairs( ents.FindInSphere( self.Entity:GetNetworkedVector( "m_vecSingularityPos" ), 256 ) ) do

			if ( v && v:IsValid() ) then

				if ( v:GetClass() == "prop_ragdoll" ) then

					for i = 1, v:GetPhysicsObjectCount() do

						local phys = v:GetPhysicsObjectNum( i )
						if (phys && phys:IsValid()) then
							phys:SetVelocity( phys:GetVelocity() / 3 )
							phys:SetAngleVelocity( phys:GetAngleVelocity() / 3 )
						end

					end

				else

					local phys = v:GetPhysicsObject()
					if (phys:IsValid()) then
						phys:SetVelocity( phys:GetVelocity() / 3 )
						phys:SetAngleVelocity( phys:GetAngleVelocity() / 3 )
					end

				end

			end

		end

	else

		self.Entity:Remove()

		if ( #self.m_tRadiatedEntities >= 1 ) then

			local info = EffectData();
			info:SetMagnitude( 1 );
			info:SetScale( 1 );
			info:SetOrigin( self.Entity:GetNetworkedVector( "m_vecSingularityPos" ) );

			util.Effect( "shockwave", info );

		end

		for k, v in pairs( self.m_tRadiatedEntities ) do

			if ( v && v:IsValid() ) then

				if ( v:GetClass() == "prop_ragdoll" ) then

					for i = 1, v:GetPhysicsObjectCount() do

						for l, w in pairs( self.m_tRadiatedEntities ) do

							if ( w && w:IsValid() ) then

								constraint.Weld( w, v, 0, i, 0, true )

							end

						end

						local phys = v:GetPhysicsObjectNum( i )
						if (phys && phys:IsValid()) then
							phys:EnableGravity( true )
							phys:SetVelocity( vec3_origin )
							phys:SetAngleVelocity( vec3_angle )
						end

					end

				else

					for l, w in pairs( self.m_tRadiatedEntities ) do

						if ( w && w:IsValid() ) then

							constraint.Weld( w, v, 0, 0, 0, true )

						end

					end

					local phys = v:GetPhysicsObject()
					if (phys:IsValid()) then
						phys:EnableGravity( true )
						phys:SetVelocity( vec3_origin )
						phys:SetAngleVelocity( vec3_angle )
					end

				end

				v.m_bIsRadiated = true

			end

		end

		if ( #self.m_tRadiatedEntities >= 1 ) then

			local phys = ents.Create( "sent_collision_effect" )

			phys:SetPos( self.Entity:GetNetworkedVector( "m_vecSingularityPos" ) )
			phys:Spawn()

		end

	end

end