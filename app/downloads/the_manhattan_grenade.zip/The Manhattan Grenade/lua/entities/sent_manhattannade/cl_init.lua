
ENT.RenderGroup 	= RENDERGROUP_TRANSLUCENT

include('shared.lua')

function ENT:Initialize()

	self.PixVis = util.GetPixelVisibleHandle()

end

/*---------------------------------------------------------
   Name: Draw
---------------------------------------------------------*/
function ENT:Draw()

	self.BaseClass.Draw( self, true )

end

/*---------------------------------------------------------
   Name: Think
---------------------------------------------------------*/
function ENT:Think()

	local r, g, b, a = self:GetColor()

	local dlight = DynamicLight( self:EntIndex() )
	if ( dlight ) then
		dlight.Pos = self:GetPos()
		dlight.r = r
		dlight.g = g
		dlight.b = b
		dlight.Brightness = 2
		dlight.Decay = 1024 * 5
		dlight.Size = 1024
		dlight.DieTime = CurTime() + 1
	end

	if ( self.Entity:GetNetworkedBool( "m_bDetonated" ) ) then

		local dlight = DynamicLight( self:EntIndex() )
		if ( dlight ) then
			dlight.Pos = self.Entity:GetNetworkedVector( "m_vecSingularityPos" )
			dlight.r = 255
			dlight.g = 255
			dlight.b = 255
			dlight.Brightness = 6
			dlight.Decay = 1024 * 5
			dlight.Size = 1024
			dlight.DieTime = CurTime() + 1
		end

	end

end
