
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )


/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	// Use the helibomb model just for the physics
	self.Entity:SetModel( "models/Combine_Helicopter/helicopter_bomb01.mdl" )
	self.Entity:SetNoDraw( true )

	// Use the model's physics
	self.Entity:PhysicsInit( SOLID_VPHYSICS )

	// Wake the physics object up.
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end

	// Set collision group
	self.Entity:SetCollisionGroup( COLLISION_GROUP_WORLD )

end


/*---------------------------------------------------------
   Name: PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide( data, physobj )

	self.Entity:Remove();

	// Draw effect on collision
	local info = EffectData();
	info:SetOrigin( data.HitPos );
	info:SetScale( 512 );
	util.Effect( "ThumperDust", info );

	util.ScreenShake( data.HitPos, 25.0, 150.0, 1.0, 750.0 );

end



