
/*---------------------------------------------------------
   resource.AddFolder
---------------------------------------------------------*/
function resource.AddFolder( foldername )

	local tree = file.FindDir( "../" .. foldername .. "/*" )

	for _, fdir in pairs( tree ) do

		if ( fdir != ".svn" || fdir != "_svn" ) then resource.AddFolder( fdir ) end

	end

	for k, v in pairs( file.Find( "../" .. foldername .. "/*" ) ) do

		resource.AddFile( foldername .. "/" .. v )

	end

end
