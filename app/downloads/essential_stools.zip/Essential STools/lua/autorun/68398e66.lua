
include( "c7a8a77b.lua" )

if ( CLIENT ) then return end

resource.AddFolder( "settings/controls" )
