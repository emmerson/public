TOOL.Category		= "Construction"
TOOL.Name			= "#Rotator"
TOOL.Command		= nil
TOOL.ConfigName		= nil


TOOL.ClientConVar[ "pitch" ]	= "0"
TOOL.ClientConVar[ "yaw" ]		= "0"
TOOL.ClientConVar[ "roll" ]		= "0"
if ( CLIENT ) then

	language.Add( "Tool_rotator_name", "Rotator" )
	language.Add( "Tool_rotator_desc", "Rotate props" )
	language.Add( "Tool_rotator_0", "Left click to rotate a prop. Right click to copy it's angles." )
	language.Add( "Undone_Rotator", "Undone Rotation")

end


function TOOL:LeftClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	local p = self:GetClientNumber( "pitch" )
	local y = self:GetClientNumber( "yaw" )
	local r = self:GetClientNumber( "roll" )
	trace.Entity:SetAngles( Angle( p, y, r ) )

	return true

end

function TOOL:RightClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	local ang = trace.Entity:GetAngles()
	self:GetOwner():ConCommand( "rotator_pitch " .. ang.p )
	self:GetOwner():ConCommand( "rotator_yaw " .. ang.y )
	self:GetOwner():ConCommand( "rotator_roll " .. ang.r )

	return true

end

function TOOL.BuildCPanel( CPanel )

	CPanel:AddControl( "Header", { Text		= "#Tool_rotator_name", Description = "#Tool_rotator_desc" } )
	CPanel:AddControl( "Slider", { Label	= "#Pitch",	Type = "Integer", Min = -360, Max = 360, Command = "rotator_pitch" } )
	CPanel:AddControl( "Slider", { Label	= "#Yaw",	Type = "Integer", Min = -360, Max = 360, Command = "rotator_yaw" } )
	CPanel:AddControl( "Slider", { Label	= "#Roll",	Type = "Integer", Min = -360, Max = 360, Command = "rotator_roll" } )

end
