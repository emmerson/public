TOOL.Category		= "Construction"
TOOL.Name			= "#Buoyancy"
TOOL.Command		= nil
TOOL.ConfigName		= nil


TOOL.ClientConVar[ "ratio" ]	= "1"
if ( CLIENT ) then

	language.Add( "Tool_buoyancy_name", "Buoyancy Tool" )
	language.Add( "Tool_buoyancy_desc", "Change the buoyancy of a prop" )
	language.Add( "Tool_buoyancy_0", "Left click to apply the settings." )

	language.Add( "BuoyancyTool_ratio", "Ratio:")
	language.Add( "BuoyancyTool_ratio_desc", "The buoyancy ratio of the prop")

end


local function SetBuoyancy( ply, ent, tbl )

	if ( CLIENT ) then return end

	if ( tbl.Buoyancy ) then

		local phys = ent:GetPhysicsObject()
		if ( phys:IsValid() ) then
			phys:SetBuoyancyRatio( tbl.Buoyancy )
			ent.Buoyancy = tbl.Buoyancy
		end

	end

	duplicator.StoreEntityModifier( ent, "buoyancy", tbl )

end

duplicator.RegisterEntityModifier( "buoyancy", SetBuoyancy )

function TOOL:LeftClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	local phys     = trace.Entity:GetPhysicsObject()
	local ply      = self:GetOwner()

	local num = self:GetClientNumber( "ratio" )
	SetBuoyancy( ply, trace.Entity, { Buoyancy = num } )

	return true

end

if ( SERVER ) then

	local function OnDropped( player, target )

		if ( target.Buoyancy ) then

			local phys = target:GetPhysicsObject()
			if ( phys:IsValid() ) then
				timer.Simple( 0, function()
					phys:SetBuoyancyRatio( target.Buoyancy )
				end )
			end

		end

	end

	hook.Add( "GravGunOnDropped", "GravGunOnDropped", OnDropped )
	hook.Add( "PhysgunDrop", "PhysgunDrop", OnDropped )

end
