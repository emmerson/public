TOOL.Category		= "Construction"
TOOL.Name			= "#Freezer"
TOOL.Command		= nil
TOOL.ConfigName		= nil


TOOL.ClientConVar[ "unfreeze" ] = "1"
if ( CLIENT ) then

	language.Add( "Tool_freezer_name", "Freezer" )
	language.Add( "Tool_freezer_desc", "Freeze entities" )
	language.Add( "Tool_freezer_0", "Left click to freeze a group of entities. Right click to unfreeze them." )

	language.Add( "FreezerTool_unfreeze", "Unfreeze:" )
	language.Add( "FreezerTool_unfreeze_desc", "This will unfreeze the entities when you shoot it." )

end


local function DoUnfreezeEntity( ent )

	local ConstrainedEntities = constraint.GetAllConstrainedEntities( ent )
	for _, obj in pairs( ConstrainedEntities ) do

		obj:GetPhysicsObject():EnableMotion( true )
		obj:GetPhysicsObject():Wake()

		DoPropSpawnedEffect( obj )

	end

end

function TOOL:LeftClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	if ( self:GetClientNumber( "unfreeze" ) == 1 ) then

		DoUnfreezeEntity(trace.Entity)

		return true

	end

 	local ConstrainedEntities = constraint.GetAllConstrainedEntities(trace.Entity)
 	for _, obj in pairs( ConstrainedEntities ) do

		obj:GetPhysicsObject():EnableMotion( false )
		obj:GetPhysicsObject():Sleep()

		DoPropSpawnedEffect( obj )

 	end

	return true

end

function TOOL:RightClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	DoUnfreezeEntity(trace.Entity)

	return true

end

function TOOL:Reload( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	DoUnfreezeEntity(trace.Entity)

	return true

end
