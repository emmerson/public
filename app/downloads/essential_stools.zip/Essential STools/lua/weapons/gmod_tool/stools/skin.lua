TOOL.Category		= "Render"
TOOL.Name			= "#Skin"
TOOL.Command		= nil
TOOL.ConfigName		= nil


TOOL.ClientConVar[ "number" ]	= "1"
if ( CLIENT ) then

	language.Add( "Tool_skin_name", "Skin Tool" )
	language.Add( "Tool_skin_desc", "Change the skin of a prop" )
	language.Add( "Tool_skin_0", "Left click to apply the settings." )

	language.Add( "SkinTool_number", "Skin:")
	language.Add( "SkinTool_number_desc", "Which skin the prop uses")

end


function TOOL:LeftClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end

	if ( CLIENT ) then return true end

	local num = self:GetClientNumber( "number" )
	trace.Entity:SetSkin( num )

	return true

end

function TOOL:RightClick( trace )

	return self:LeftClick( trace )

end
