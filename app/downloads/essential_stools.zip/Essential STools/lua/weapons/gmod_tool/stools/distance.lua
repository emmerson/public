TOOL.Category		= "Construction"
TOOL.Name			= "#Distance"
TOOL.Command		= nil
TOOL.ConfigName		= nil


TOOL.ClientConVar[ "length" ]	= ""
if ( CLIENT ) then

	language.Add( "Tool_distance_name", "Distance Tool" )
	language.Add( "Tool_distance_desc", "Measure the length between two entities" )
	language.Add( "Tool_distance_0", "Click on 2 objects to find the distance between them." )
	language.Add( "Tool_distance_1", "Now click somewhere else" )

end


function TOOL:LeftClick( trace )

	if (trace.Entity:IsPlayer()) then return end

	// If there's no physics object then we can't constraint it!
	if ( SERVER && !util.IsValidPhysicsObject( trace.Entity, trace.PhysicsBone ) ) then return false end

	local iNum = self:NumObjects()

	local Phys = trace.Entity:GetPhysicsObjectNum( trace.PhysicsBone )
	self:SetObject( iNum + 1, trace.Entity, trace.HitPos, Phys, trace.PhysicsBone, trace.HitNormal )

	if (CLIENT) then

		if ( iNum > 0 ) then
			self:ClearObjects()
		end

		return true

	end

	if ( iNum > 0 ) then

		// Get information we're about to use
		local WPos1, WPos2 = self:GetPos(1),	 self:GetPos(2)
		self:GetOwner():ConCommand( "distance_length " .. ( WPos1 - WPos2):Length() )

		self:ClearObjects()

	else

		self:SetStage( iNum+1 )

	end

	return true

end

function TOOL.BuildCPanel( CPanel )

	CPanel:AddControl( "Header", { Text		= "#Tool_distance_name", Description = "#Tool_distance_desc" } )
	CPanel:AddControl( "TextBox", { Label	= "#Length",	MaxLength = 16, Text = "", Command = "distance_length" } )

end
