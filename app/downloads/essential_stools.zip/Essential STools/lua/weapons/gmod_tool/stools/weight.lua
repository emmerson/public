TOOL.Category		= "Construction"
TOOL.Name			= "#Weight"
TOOL.Command		= nil
TOOL.ConfigName		= nil


TOOL.ClientConVar[ "mass" ]	= "1"
if ( CLIENT ) then

	language.Add( "Tool_weight_name", "Weight Tool" )
	language.Add( "Tool_weight_desc", "Change the mass of a prop" )
	language.Add( "Tool_weight_0", "Left click to apply the settings. Right click to copy it's mass." )
	language.Add( "Undone_Weight", "Undone Weight")

	language.Add( "WeightTool_mass", "Mass:")
	language.Add( "WeightTool_mass_desc", "How heavy the prop is")

end


local function SetMass( ply, ent, tbl )

	if ( CLIENT ) then return end

	if ( tbl.Mass ) then

		local phys = ent:GetPhysicsObject()
		if ( phys:IsValid() ) then phys:SetMass( tbl.Mass ) end

	end

	duplicator.StoreEntityModifier( ent, "mass", tbl )

end

duplicator.RegisterEntityModifier( "mass", SetMass )

function TOOL:LeftClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	local phys = trace.Entity:GetPhysicsObject()
	local ply  = self:GetOwner()
	local mass = phys:GetMass()
	local function weight( undo, ent, mass )
		if ( ent:IsValid() ) then
			SetMass( ply, ent, { Mass = mass } )
		end
	end

	local num = self:GetClientNumber( "mass" )
	if ( num == 0 ) then num = 1 end
	SetMass( ply, trace.Entity, { Mass = num } )

	undo.Create( "Weight" )
		undo.AddFunction( weight, trace.Entity, mass )
		undo.SetPlayer( ply )
	undo.Finish()

	return true

end

function TOOL:RightClick( trace )

	if (!trace.Entity) then return false end
	if (!trace.Entity:IsValid()) then return false end
	if (trace.Entity:IsPlayer()) then return false end

	if ( CLIENT ) then return true end

	local phys = trace.Entity:GetPhysicsObject()
	local mass = phys:GetMass()
	self:GetOwner():ConCommand( "weight_mass " .. mass )

	return true

end
