

if ( SERVER ) then

	if ( !util.IsValidModel( "models/weapons/v_rif_ak47.mdl" ) ) then

		SWEP.m_bIsDisabled	= true

		return

	end

	AddCSLuaFile( "shared.lua" )

	SWEP.HoldType			= "ar2"

end

if ( CLIENT ) then

	SWEP.PrintName			= "An AK47 That Shoots Babies"
	SWEP.Author				= "Andrew McWatters"
	SWEP.WepSelectFont		= "CSweaponsSmall"
	SWEP.WepSelectLetter	= "B"

	killicon.AddFont( "sent_baby", "CSKillIcons", "b", Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_smg1"
SWEP.Category			= "Facepunch"
SWEP.m_bFiresUnderwater	= true;

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.ViewModelFOV		= 54
SWEP.ViewModelFlip		= true
SWEP.CSMuzzleFlashes	= true
SWEP.ViewModel			= "models/weapons/v_rif_ak47.mdl"
SWEP.WorldModel			= "models/weapons/w_rif_ak47.mdl"
SWEP.AnimPrefix			= "anim"

SWEP.Primary.Sound			= Sound( "Weapon_AK47.Single" )
SWEP.Primary.Cone			= VECTOR_CONE_6DEGREES
SWEP.Primary.ClipSize		= 30
SWEP.Primary.Delay			= 0.1
SWEP.Primary.DefaultClip	= 30
SWEP.Primary.Ammo			= BULLET_PLAYER_762MM

SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "None"

function SWEP:SecondaryAttack()
end

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	// Only the player fires this way so we can cast
	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	local vecSrc		= pPlayer:GetShootPos();
	local vecAiming		= pPlayer:GetAimVector();

	local info = { Num = num_bullets, Src = vecSrc, Dir = vecAiming, Spread = aimcone, Damage = damage };
	info.Attacker = pPlayer;

	if ( CLIENT ) then return end

	// Fire the melons, and force the first shot to be perfectly juicy
	for i = 1, info.Num do

		local Src		= info.Spread || vec3_origin
		local Dir		= info.Dir + Vector( math.Rand( -Src.x, Src.x ), math.Rand( -Src.y, Src.y ), math.Rand( -Src.y, Src.y ) )
		local pBaby		= ents.Create( "sent_baby" );

		pBaby:SetPos( info.Src + ( Dir * 32 ) )
		pBaby:SetAngles( Dir:Angle() + Angle( -90, 0, 180 ) );
		pBaby.m_iDamage = self.Primary.Damage;
		pBaby:SetOwner( pPlayer );
		pBaby:Spawn()

		pBaby:SetPos( info.Src + ( Dir * pBaby:BoundingRadius() ) );

		if ( pPlayer:WaterLevel() == 3 ) then
			pBaby:GetPhysicsObject():SetVelocity( Dir * BOLT_WATER_VELOCITY );
		else
			pBaby:GetPhysicsObject():SetVelocity( Dir * BOLT_AIR_VELOCITY );
		end

	end

end
