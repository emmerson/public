
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )


/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	// Use the doll model
	self.Entity:SetModel( "models/props_c17/doll01.mdl" )
	self.Entity:SetMoveType( MOVETYPE_FLYGRAVITY );
	self.Entity:SetMoveCollide( MOVECOLLIDE_FLY_CUSTOM );
	self.Entity:SetGravity( 0.05 );

	// Use the model's physics
	self.Entity:PhysicsInit( SOLID_VPHYSICS, "flesh" )

	// Wake the physics object up. It's time to have babies!
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end

end


//-----------------------------------------------------------------------------
// Purpose:
// Input  : *pOther -
//-----------------------------------------------------------------------------
function ENT:Touch( pOther )

	local	tr;
	tr = {}
	tr.startpos = self.Entity:NearestPoint( pOther:OBBCenter() );
	tr.endpos = pOther:NearestPoint( self.Entity:OBBCenter() );
	tr.filter = self.Entity;
	tr = util.TraceLine( tr );
	local	vecNormalizedVel = self.Entity:GetVelocity();

	vecNormalizedVel = VectorNormalize( vecNormalizedVel );

	if( self.Entity:GetOwner() && self.Entity:GetOwner():IsPlayer() && pOther:IsNPC() ) then
		local	dmgInfo = DamageInfo();
		dmgInfo:SetInflictor( self.Entity );
		dmgInfo:SetAttacker( self.Entity:GetOwner() );
		dmgInfo:SetDamage( self.m_iDamage );
		dmgInfo:SetDamageType( DMG_NEVERGIB );
		dmgInfo:SetDamagePosition( tr.HitPos );
		pOther:DispatchTraceAttack( dmgInfo, vecNormalizedVel, tr.HitPos );
	else
		local	dmgInfo = DamageInfo();
		dmgInfo:SetInflictor( self.Entity );
		dmgInfo:SetAttacker( self.Entity:GetOwner() );
		dmgInfo:SetDamage( self.m_iDamage );
		dmgInfo:SetDamageType( DMG_BULLET | DMG_NEVERGIB );
		dmgInfo:SetDamagePosition( tr.HitPos );
		pOther:DispatchTraceAttack( dmgInfo, vecNormalizedVel, tr.HitPos );
	end

	self.Entity:SetVelocity( Vector( 0, 0, 0 ) );

	// play body "thwack" sound
	self.Entity:EmitSound( "Weapon_Crossbow.BoltHitBody" );

	local vForward;

	vForward = self.Entity:GetUp();
	vForward = VectorNormalize ( vForward );

	self.Touch = function( ... ) return end;
	self.Think = function( ... ) return end;

	local Pos1 = tr.HitPos + tr.HitNormal
	local Pos2 = tr.HitPos - tr.HitNormal
	util.Decal( "Blood", Pos1, Pos2 )

end

/*---------------------------------------------------------
   Name: PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide( data, physobj )

	// Shoot some blood
	local effectdata = EffectData();
	effectdata:SetOrigin( self.Entity:GetPos() );
	util.Effect( "BloodImpact", effectdata );

	local Pos1 = data.HitPos + data.HitNormal
	local Pos2 = data.HitPos - data.HitNormal
	util.Decal( "Blood", Pos1, Pos2 )

	// Play sound on death
	if (data.Speed > 80 && data.DeltaTime > 0.2 ) then
		self.Entity:EmitSound( "Weapon_Crossbow.BoltHitBody" );
	end

	SafeRemoveEntityDelayed( self.Entity, 0.1 );

end

/*---------------------------------------------------------
   Name: OnTakeDamage
---------------------------------------------------------*/
function ENT:OnTakeDamage( dmginfo )

	// React physically when shot/getting blown
	self.Entity:TakePhysicsDamage( dmginfo )

end



