

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Baby"
ENT.Author			= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
