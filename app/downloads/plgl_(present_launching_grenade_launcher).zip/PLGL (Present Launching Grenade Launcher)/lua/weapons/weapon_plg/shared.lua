

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_plg.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_plg.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "PLG (Present-Launching Grenade)"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "34"

	killicon.AddFont( "sent_grenade_present", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_rpg"
SWEP.Category			= SWEP.Author

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.Sound			= Sound( "Weapon_SMG1.Double" )
SWEP.Primary.AmmoType		= "sent_grenade_present"
