
ENT.Sound				= {}
ENT.Sound.Blip			= "Grenade.Blip"
ENT.Sound.Explode		= "BaseGrenade.Explode"

ENT.Trail				= {}
ENT.Trail.Color			= nil
ENT.Trail.Material		= "trails/laser.vmt"
ENT.Trail.StartWidth	= 8.0
ENT.Trail.EndWidth		= 1.0
ENT.Trail.LifeTime		= 0.5

// Nice helper function, this does all the work.

ENT.m_tPresents			= {

	Model( "models/effects/bday_gib01.mdl" ),
	Model( "models/effects/bday_gib02.mdl" ),
	Model( "models/effects/bday_gib03.mdl" ),
	Model( "models/effects/bday_gib04.mdl" )

}

/*---------------------------------------------------------
   Name: DoExplodeEffect
---------------------------------------------------------*/
function ENT:DoExplodeEffect()

	local info = EffectData();
	info:SetEntity( self.Entity );
	info:SetOrigin( self.Entity:GetPos() );

	util.Effect( "Explosion", info );

	info = EffectData();
	info:SetStart( Vector( 0, 255, 0 ) );

	util.Effect( "balloon_pop", info );

	info = EffectData();
	info:SetStart( Vector( 255, 0, 0 ) );

	util.Effect( "balloon_pop", info );

end

/*---------------------------------------------------------
   Name: OnExplode
   Desc: The grenade has just exploded.
---------------------------------------------------------*/
function ENT:OnExplode( pTrace )

	for i = 1, math.random( 3, 7 ) do

		if ( GAMEMODE.IsSandboxDerived ) then

			if ( !self:GetOwner():CheckLimit( "props" ) ) then return false end

		end

		local Src		= VECTOR_CONE_10DEGREES
		local Dir		= self.Entity:GetUp() + Vector( math.Rand( -Src.x, Src.x ), math.Rand( -Src.y, Src.y ), math.Rand( -Src.y, Src.y ) )
		local phys		= ents.Create( "prop_physics_multiplayer" )

		phys:SetPos( self.Entity:GetPos() + ( Dir * 32 ) )
		phys:SetAngles( Dir:Angle() )

		local r, g, b, a = self.Trail.Color.r,
						   self.Trail.Color.g,
						   self.Trail.Color.b,
						   self.Trail.Color.a
		phys:SetColor( r, g, b, a )
		phys:SetModel( table.Random( self.m_tPresents ) )
		phys:SetPhysicsAttacker( self:GetOwner() )
		phys:SetSkin( math.random( 1, 2 ) )

		phys:Spawn()

		if ( GAMEMODE.IsSandboxDerived ) then

			DoPropSpawnedEffect( phys )

			undo.Create("Prop")
				undo.AddEntity( phys )
				undo.SetPlayer( self:GetOwner() )
			undo.Finish()

			self:GetOwner():AddCleanup( "props", phys )
			self:GetOwner():AddCount( "props", phys )

		end

		phys:SetPos( self.Entity:GetPos() + ( Dir * phys:BoundingRadius() ) )

		phys = phys:GetPhysicsObject()
		if (phys:IsValid()) then
			phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
			phys:SetMass( phys:GetMass() * self:GetDamage() )
			phys:SetVelocity( Vector( math.Rand( -Src.x, Src.x ), math.Rand( -Src.y, Src.y ), math.Rand( -Src.y, Src.y ) ) * 1500 )
		end

	end

	local Pos1 = Vector( self.Entity:GetPos().x, self.Entity:GetPos().y, pTrace.HitPos.z ) + pTrace.HitNormal
	local Pos2 = Vector( self.Entity:GetPos().x, self.Entity:GetPos().y, pTrace.HitPos.z ) - pTrace.HitNormal

 	util.Decal( "Scorch", Pos1, Pos2 );

end

/*---------------------------------------------------------
   Name: OnInitialize
---------------------------------------------------------*/
function ENT:OnInitialize()

	local Ang = self.Entity:GetAngles()
	self.Entity:SetAngles( Ang + Angle( 90, 0, 0 ) )

	local phys = self.Entity:GetPhysicsObject()
	if ( phys:IsValid() ) then
		phys:SetVelocity( self.Entity:GetUp() * 3500 )
	end

end

/*---------------------------------------------------------
   Name: StartTouch
---------------------------------------------------------*/
function ENT:StartTouch( entity )
end

/*---------------------------------------------------------
   Name: EndTouch
---------------------------------------------------------*/
function ENT:EndTouch( entity )
end

/*---------------------------------------------------------
   Name: Touch
---------------------------------------------------------*/
function ENT:Touch( entity )

	if ( !entity ) then return end
	if ( !entity:IsValid() ) then return end
	if ( entity:IsPlayer() || entity:IsNPC() ) then self:Detonate() end

end

/*---------------------------------------------------------
   Name: OnThink
---------------------------------------------------------*/
function ENT:OnThink()
end