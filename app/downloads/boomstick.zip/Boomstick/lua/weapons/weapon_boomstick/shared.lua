

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_boomstick.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_boomstick.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "Boomstick"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Quidsy the Squidsy"
	SWEP.IconLetter			= "!"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_stunstick"
SWEP.Category			= "Quidsy the Squidsy"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.Damage			= 100
SWEP.Primary.DamageRadius	= 100

function SWEP:ImpactEffect( traceHit )

	local	data = EffectData();

	data:SetNormal( traceHit.HitNormal );
	data:SetOrigin( traceHit.HitPos + ( traceHit.HitNormal * 4.0 ) );

	util.Effect( "StunstickImpact", data );

	local	data = EffectData();

	data:SetNormal( traceHit.HitNormal );
	data:SetOrigin( traceHit.HitPos + ( traceHit.HitNormal * 4.0 ) );

	util.Effect( "Explosion", data );

	util.ImpactTrace( traceHit, self.Owner );

end

function SWEP:Hit( traceHit, pPlayer )

	local vecSrc = pPlayer:GetShootPos();

	if ( SERVER ) then
		pPlayer:TraceHullAttack( vecSrc, traceHit.HitPos, Vector( -16, -16, -40 ), Vector( 16, 16, 16 ), self:GetDamageForActivity(), self.Primary.DamageType, self.Primary.Force, false );
	end

	hook.Add( "EntityTakeDamage", self:GetClass() .. " (" .. self:EntIndex() .. ")", function( ent, inflictor, attacker, amount, dmginfo )

		if ( ent == self:GetOwner() ) then

			dmginfo:SetDamage( 0 )

		end

	end )

	if ( traceHit.Fraction != 1.0 ) then
		local vecNormal = traceHit.HitNormal;
		local pdata = traceHit.MatType;

		util.BlastDamage( self.Weapon,
			self:GetOwner(),
			self.Weapon:GetPos(),
			self.Primary.DamageRadius,
			self:GetDamageForActivity() );
	else
		util.BlastDamage( self.Weapon,
			self:GetOwner(),
			self.Weapon:GetPos(),
			self.Primary.DamageRadius,
			self:GetDamageForActivity() );
	end

	hook.Remove( "EntityTakeDamage", self:GetClass() .. " (" .. self:EntIndex() .. ")" )

	self:ImpactEffect( traceHit );

end
