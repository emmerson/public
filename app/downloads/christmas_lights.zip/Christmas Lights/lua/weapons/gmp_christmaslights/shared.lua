

if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )

	function SWEP:OnRemove()

		for k, v in pairs( self.Bulbs ) do

			if ( ValidEntity( v ) ) then

				v.m_bTriggered = true

			end

		end

	end

end

if ( CLIENT ) then

	SWEP.PrintName			= "Christmas Lights"
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "4"

	killicon.AddFont( "sent_grenade_bulb", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_pistol"
SWEP.Category			= "Garry's Mod Plus"
SWEP.AlternateColor		= false
SWEP.Bulbs				= {}

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= true

function SWEP:SecondaryAttack()

	self.Weapon:EmitSound( self.Primary.Empty );
	self.Weapon:SendWeaponAnim( ACT_VM_DRYFIRE );

	local Weapon = self.Weapon

	timer.Simple( self.Weapon:SequenceDuration(), function()

		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		Weapon:SendWeaponAnim( ACT_VM_IDLE );

	end )

	for k, v in pairs( self.Bulbs ) do

		if ( ValidEntity( v ) ) then

			v.m_bTriggered = true

		end

	end

end

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	// Only the player fires this way so we can cast
	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	local vecSrc		= pPlayer:GetShootPos();
	local vecAiming		= pPlayer:GetAimVector();

	local info = { Num = num_bullets, Src = vecSrc, Dir = vecAiming, Spread = aimcone, Damage = damage };
	info.Attacker = pPlayer;

	if ( CLIENT ) then return end

	// Fire the lights, and force the first shot to be perfectly merry
	for i = 1, info.Num do

		local Src		= info.Spread || vec3_origin
		local Dir		= info.Dir + Vector( math.Rand( -Src.x, Src.x ), math.Rand( -Src.y, Src.y ), math.Rand( -Src.y, Src.y ) )
		local phys		= ents.Create( "sent_grenade_bulb" )

		phys:SetPos( info.Src + ( Dir * 32 ) )
		phys:SetAngles( Dir:Angle() + Angle( 90, 0, 0 ) )

		phys:SetOwner( pPlayer )

		phys:Spawn()

		if ( self.AlternateColor ) then

			phys:SetColor( 255, 0, 0, 255 )

		else

			phys:SetColor( 0, 255, 0, 255 )

		end

		self.AlternateColor = !self.AlternateColor

		for k, v in pairs( self.Bulbs ) do

			if ( !ValidEntity( v ) ) then

				table.remove( self.Bulbs, k )

			else

				constraint.NoCollide( v, phys, 0, 0 )

			end

		end

		if ( #self.Bulbs >= 1 ) then

			local LastBulb	= self.Bulbs[ #self.Bulbs ]

			if ( ValidEntity( LastBulb ) ) then

				// Get client's CVars
				local forcelimit = 0
				local addlength	 = 0
				local material 	 = "cable/rope"
				local width 	 = 2
				local rigid	 	= false

				// Get information we're about to use
				local Ent1,  Ent2  = LastBulb,	                    phys
				local Bone1, Bone2 = 0,	                            0
				local WPos1, WPos2 = LastBulb:GetPos(),             phys:GetPos()
				local LPos1, LPos2 = LastBulb:WorldToLocal( WPos1 ),phys:WorldToLocal( WPos2 )
				local length = ( WPos1 - WPos2):Length()

				constraint.CreateKeyframeRope( WPos1, width, material, Ent1, Ent1, LPos1, Bone1, Ent2, LPos2, Bone2, {} )

			else

				table.remove( self.Bulbs, #self.Bulbs )

			end

		end

		table.insert( self.Bulbs, phys )

		phys:SetPos( info.Src + ( Dir * phys:BoundingRadius() ) )
		phys:GetPhysicsObject():AddGameFlag( FVPHYSICS_WAS_THROWN )
		phys:GetPhysicsObject():SetVelocity( Dir * 1500 )

	end

end
