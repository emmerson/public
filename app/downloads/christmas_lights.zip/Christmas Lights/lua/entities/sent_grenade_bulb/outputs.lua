
ENT.Sound				= {}
ENT.Sound.Blip			= "Grenade.Blip"
ENT.Sound.Explode		= "Glass.BulletImpact"

ENT.Trail				= {}
ENT.Trail.Color			= Color( 255, 0, 0, 255 )
ENT.Trail.Material		= "sprites/bluelaser1.vmt"
ENT.Trail.StartWidth	= 8.0
ENT.Trail.EndWidth		= 1.0
ENT.Trail.LifeTime		= 0.5

// Nice helper function, this does all the work.

/*---------------------------------------------------------
   Name: DoExplodeEffect
---------------------------------------------------------*/
function ENT:DoExplodeEffect()

	local r, g, b = self.Entity:GetColor()

	local effectdata = EffectData()
		effectdata:SetOrigin( self.Entity:GetPos() )
		effectdata:SetStart( Vector( r, g, b ) )
	util.Effect( "balloon_pop", effectdata )

	local info = EffectData();
	info:SetNormal( self.HitNormal || self.Entity:GetAngles() );
	info:SetOrigin( self.Entity:GetPos() );

	util.Effect( "GlassImpact", info );

end

/*---------------------------------------------------------
   Name: OnExplode
   Desc: The grenade has just exploded.
---------------------------------------------------------*/
function ENT:OnExplode( pTrace )
end

/*---------------------------------------------------------
   Name: OnInitialize
---------------------------------------------------------*/
function ENT:OnInitialize()

	self:OnThink()

end

/*---------------------------------------------------------
   Name: StartTouch
---------------------------------------------------------*/
function ENT:StartTouch( entity )
end

/*---------------------------------------------------------
   Name: EndTouch
---------------------------------------------------------*/
function ENT:EndTouch( entity )
end

/*---------------------------------------------------------
   Name: Touch
---------------------------------------------------------*/
function ENT:Touch( entity )

	if (!entity ) then return end
	if (!entity:IsValid()) then return end
	if (!(entity:IsPlayer() || entity:IsNPC())) then return end
	if (string.find(entity:GetClass(), "trigger_")) then return end

	self.Entity:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.Entity:SetParent( entity )

end

/*---------------------------------------------------------
   Name: PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide( data, physobj )

	if ( data.HitEntity:GetClass() == self.Entity:GetClass() ) then return end

	// If there's no physics object then we can't constraint it!
	if ( SERVER && !util.IsValidPhysicsObject( data.HitEntity, 0 ) ) then return end

	self.HitWeld = true
	self.Ent1 = data.HitEntity
	self.HitNormal = data.HitNormal

	self.PhysicsCollide = function( ... ) return end

end

/*---------------------------------------------------------
   Name: OnThink
---------------------------------------------------------*/
function ENT:OnThink()

	hook.Add( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")", function()

		if ( self.HitWeld ) then

			self.HitWeld = false

			constraint.Weld( self.Ent1, self.Entity, 0, 0, 0, true )

		end

		if ( self.m_bTriggered ) then

			hook.Remove( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")" )

			self:Detonate()

		end

	end )

end