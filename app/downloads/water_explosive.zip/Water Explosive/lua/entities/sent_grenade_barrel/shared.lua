

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Barrel"
ENT.Author			= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
