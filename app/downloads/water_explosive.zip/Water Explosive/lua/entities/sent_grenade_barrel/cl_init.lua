
include('shared.lua')

/*---------------------------------------------------------
   Name: Draw
---------------------------------------------------------*/
function ENT:Draw()

	self.Entity:SetModelScale( Vector( 1 / 5, 1 / 5, 1 / 5 ) )
	self.Entity:DrawModel()

end
