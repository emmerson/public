

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_waterexplosive.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_waterexplosive.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	language.Add( "HL2_Water_Explosive", "WATER EXPLOSIVE" )

	SWEP.PrintName			= "#HL2_Water_Explosive"
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "4"

	killicon.AddFont( "sent_grenade_barrel", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_grenade"
SWEP.Category			= SWEP.Author

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.AmmoType		= "sent_grenade_barrel"
