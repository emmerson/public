
local gmod_ragdoll_fadetime = CreateClientConVar( "gmod_ragdoll_fadetime", 10.0, true, false )

hook.Add( "Think", "RagdollThink", function()

	local RagdollEntities = {}
	table.Add( RagdollEntities, ents.FindByClass( "class C_ClientRagdoll" ) )
	table.Add( RagdollEntities, ents.FindByClass( "gib" ) )

	for _, ragdoll in pairs( RagdollEntities ) do

		if ( !ragdoll.m_flFadeTime ) then

			ragdoll.m_flFadeTime	= CurTime() + gmod_ragdoll_fadetime:GetFloat()
			ragdoll.m_angLastAng	= ragdoll:GetAngles()
			ragdoll.m_vecLastPos	= ragdoll:GetPos()

		elseif ( ragdoll.m_flFadeTime <= CurTime() ||
				 ragdoll.m_angLastAng != ragdoll:GetAngles() ||
				 ragdoll.m_vecLastPos != ragdoll:GetPos() ) then

			if ( ragdoll.m_angLastAng == ragdoll:GetAngles() &&
				 ragdoll.m_vecLastPos == ragdoll:GetPos() ) then

				ragdoll.m_bFadeOut		= true

			else

				ragdoll.m_flFadeTime	= nil

			end

		end

		if ( ragdoll.m_bFadeOut ) then

			local r, g, b, a = ragdoll:GetColor()
			a = math.Clamp( a - 2, 0, 255 )

			if ( a <= 0 ) then

				ragdoll:Remove()

				return

			end

			ragdoll:SetColor( r, g, b, a )

		end

	end

end )

