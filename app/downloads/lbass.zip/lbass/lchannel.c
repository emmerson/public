/*
* lchannel.c
* Channel bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 12 Jan 2012 08:50:00
* This code is hereby placed in the public domain.
*/

#include "bass.h"
#include "lua.h"
#include "lauxlib.h"
#include "lauxlibex.h"

/*
** access functions (stack -> C)
*/


LUA_API DWORD lua_tochannel (lua_State *L, int idx) {
  DWORD handle = *(DWORD *)lua_touserdata(L, idx);
  return handle;
}



/*
** push functions (C -> stack)
*/


LUA_API void lua_pushchannel (lua_State *L, DWORD channel) {
  DWORD *pHandle = (DWORD *)lua_newuserdata(L, sizeof(DWORD));
  *pHandle = channel;
  luaL_getmetatable(L, "channel");
  lua_setmetatable(L, -2);
}


LUALIB_API DWORD luaL_checkchannel (lua_State *L, int narg) {
  DWORD d = *(DWORD *)luaL_checkudata(L, narg, "channel");
  return d;
}


static int channel_Bytes2Seconds (lua_State *L) {
  lua_pushnumber(L, BASS_ChannelBytes2Seconds(luaL_checkchannel(L, 1), luaL_checkinteger(L, 2)));
  return 1;
}

static int channel_Get3DAttributes (lua_State *L) {
  DWORD mode = 0;
  float min = 0.0f;
  float max = 0.0f;
  DWORD iangle = 0;
  DWORD oangle = 0;
  float outvol = 0.0f;
  lua_pushinteger(L, BASS_ChannelGet3DAttributes(luaL_checkchannel(L, 1), &mode, &min, &max, &iangle, &oangle, &outvol));
  lua_pushinteger(L, mode);
  lua_pushnumber(L, min);
  lua_pushnumber(L, max);
  lua_pushinteger(L, iangle);
  lua_pushinteger(L, oangle);
  lua_pushnumber(L, outvol);
  return 7;
}

static int channel_GetData (lua_State *L) {
  int length = luaL_checkinteger(L, 2);
  int stack = 0;
  int i = 0;
  switch (length) {
	case BASS_DATA_FFT256: {
	  float buffer[128] = { 0.0f };
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), &buffer, length));
	  lua_newtable(L);
	  for ( i = 0; i<128; i++ ) {
		  lua_pushinteger(L, i);
		  lua_pushnumber(L, buffer[i]);
		  lua_settable(L, -3);
	  }
	  stack = 2;
	  break;
	}
	case BASS_DATA_FFT512: {
	  float buffer[256] = { 0.0f };
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), &buffer, length));
	  lua_newtable(L);
	  for ( i = 0; i<256; i++ ) {
		  lua_pushinteger(L, i);
		  lua_pushnumber(L, buffer[i]);
		  lua_settable(L, -3);
	  }
	  stack = 2;
	  break;
	}
	case BASS_DATA_FFT1024: {
	  float buffer[512] = { 0.0f };
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), &buffer, length));
	  lua_newtable(L);
	  for ( i = 0; i<512; i++ ) {
		  lua_pushinteger(L, i);
		  lua_pushnumber(L, buffer[i]);
		  lua_settable(L, -3);
	  }
	  stack = 2;
	  break;
	}
	case BASS_DATA_FFT2048: {
	  float buffer[1024] = { 0.0f };
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), &buffer, length));
	  lua_newtable(L);
	  for ( i = 0; i<1024; i++ ) {
		  lua_pushinteger(L, i);
		  lua_pushnumber(L, buffer[i]);
		  lua_settable(L, -3);
	  }
	  stack = 2;
	  break;
	}
	case BASS_DATA_FFT4096: {
	  float buffer[2048] = { 0.0f };
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), &buffer, length));
	  lua_newtable(L);
	  for ( i = 0; i<2048; i++ ) {
		  lua_pushinteger(L, i);
		  lua_pushnumber(L, buffer[i]);
		  lua_settable(L, -3);
	  }
	  stack = 2;
	  break;
	}
	case BASS_DATA_FFT8192: {
	  float buffer[4096] = { 0.0f };
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), &buffer, length));
	  lua_newtable(L);
	  for ( i = 0; i<4096; i++ ) {
		  lua_pushinteger(L, i);
		  lua_pushnumber(L, buffer[i]);
		  lua_settable(L, -3);
	  }
	  stack = 2;
	  break;
	}
	case BASS_DATA_FFT16384: {
	  float buffer[8192] = { 0.0f };
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), &buffer, length));
	  lua_newtable(L);
	  for ( i = 0; i<8192; i++ ) {
		  lua_pushinteger(L, i);
		  lua_pushnumber(L, buffer[i]);
		  lua_settable(L, -3);
	  }
	  stack = 2;
	  break;
	}
	case BASS_DATA_AVAILABLE: {
	  lua_pushinteger(L, BASS_ChannelGetData(luaL_checkchannel(L, 1), NULL, length));
	  stack = 1;
	  break;
	}
  }
  return stack;
}

static int channel_GetDevice (lua_State *L) {
  lua_pushinteger(L, BASS_ChannelGetDevice(luaL_checkchannel(L, 1)));
  return 1;
}

static int channel_GetLength (lua_State *L) {
  DWORD channel = luaL_checkchannel(L, 1);
  QWORD len = BASS_ChannelGetLength(channel, BASS_POS_BYTE);
  double time = BASS_ChannelBytes2Seconds(channel, len);
  lua_pushnumber(L, time);
  return 1;
}

static int channel_GetLevel (lua_State *L) {
  DWORD level, left, right;
  level = BASS_ChannelGetLevel(luaL_checkchannel(L, 1));
  left = LOWORD(level);
  right = HIWORD(level);
  lua_pushinteger(L, left);
  lua_pushinteger(L, right);
  return 2;
}

static int channel_IsActive (lua_State *L) {
  lua_pushinteger(L, BASS_ChannelIsActive(luaL_checkchannel(L, 1)));
  return 1;
}

static int channel_IsSliding(lua_State *L) {
  lua_pushboolean(L, BASS_ChannelIsSliding(luaL_checkchannel(L, 1), luaL_checkinteger(L, 2)));
  return 1;
}

static int channel_Lock(lua_State *L) {
  lua_pushboolean(L, BASS_ChannelLock(luaL_checkchannel(L, 1), luaL_checkboolean(L, 2)));
  return 1;
}

static int channel_Pause(lua_State *L) {
  lua_pushboolean(L, BASS_ChannelPause(luaL_checkchannel(L, 1)));
  return 1;
}

static int channel_Play(lua_State *L) {
  lua_pushboolean(L, BASS_ChannelPlay(luaL_checkchannel(L, 1), luaL_checkboolean(L, 2)));
  return 1;
}

static int channel_RemoveLink(lua_State *L) {
  lua_pushboolean(L, BASS_ChannelRemoveLink(luaL_checkchannel(L, 1), luaL_checkchannel(L, 2)));
  return 1;
}

static int channel_Seconds2Bytes(lua_State *L) {
  lua_pushinteger(L, (int)BASS_ChannelSeconds2Bytes(luaL_checkchannel(L, 1), luaL_checknumber(L, 2)));
  return 1;
}

static int channel_Set3DAttributes (lua_State *L) {
  lua_pushboolean(L, BASS_ChannelSet3DAttributes(luaL_checkchannel(L, 1), luaL_checkinteger(L, 1), (float)luaL_checknumber(L, 2), (float)luaL_checknumber(L, 3), luaL_checkinteger(L, 4), luaL_checkinteger(L, 5), (float)luaL_checknumber(L, 6)));
  return 1;
}

static int channel_SetAttribute (lua_State *L) {
  lua_pushboolean(L, BASS_ChannelSetAttribute(luaL_checkchannel(L, 1), luaL_checkinteger(L, 1), (float)luaL_checknumber(L, 2)));
  return 1;
}

static int channel_SetDevice (lua_State *L) {
  lua_pushboolean(L, BASS_ChannelSetDevice(luaL_checkchannel(L, 1), luaL_checkinteger(L, 1)));
  return 1;
}

static int channel_SetLink (lua_State *L) {
  lua_pushboolean(L, BASS_ChannelSetLink(luaL_checkchannel(L, 1), luaL_checkchannel(L, 2)));
  return 1;
}

static int channel_SlideAttribute (lua_State *L) {
  lua_pushboolean(L, BASS_ChannelSlideAttribute(luaL_checkchannel(L, 1), luaL_checkinteger(L, 2), (float)luaL_checknumber(L, 3), luaL_checkinteger(L, 4)));
  return 1;
}

static int channel_Stop (lua_State *L) {
  lua_pushboolean(L, BASS_ChannelStop(luaL_checkchannel(L, 1)));
  return 1;
}

static int channel_Update (lua_State *L) {
  lua_pushboolean(L, BASS_ChannelUpdate(luaL_checkchannel(L, 1), luaL_optinteger(L, 2, 0)));
  return 1;
}

static int channel___eq (lua_State *L) {
  DWORD a = lua_tochannel(L, 1);
  DWORD b = lua_tochannel(L, 2);
  lua_pushboolean(L, (int)(a == b) );
  return 1;
}

static int channel___tostring (lua_State *L) {
  DWORD handle = lua_tochannel(L, 1);
  lua_pushfstring(L, "channel: %i", handle);
  return 1;
}


static const luaL_Reg channelmeta[] = {
  {"Bytes2Seconds", channel_Bytes2Seconds},
  {"Get3DAttributes", channel_Get3DAttributes},
  {"GetData", channel_GetData},
  {"GetDevice", channel_GetDevice},
  {"GetLength", channel_GetLength},
  {"GetLevel", channel_GetLevel},
  {"IsActive", channel_IsActive},
  {"IsSliding", channel_IsSliding},
  {"Lock", channel_Lock},
  {"Pause", channel_Pause},
  {"Play", channel_Play},
  {"RemoveLink", channel_RemoveLink},
  {"Seconds2Bytes", channel_Seconds2Bytes},
  {"Set3DAttributes", channel_Set3DAttributes},
  {"SetAttribute", channel_SetAttribute},
  {"SetDevice", channel_SetDevice},
  {"SetLink", channel_SetLink},
  {"SlideAttribute", channel_SlideAttribute},
  {"Stop", channel_Stop},
  {"Update", channel_Update},
  {"__eq", channel___eq},
  {"__tostring", channel___tostring},
  {NULL, NULL}
};


/*
** Open channel object
*/
int luaopen_channel (lua_State* L) {
  luaL_newmetatable(L, "channel");
  luaL_register(L, NULL, channelmeta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "channel");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "channel" */
  lua_pop(L, 1);
  return 1;
}

