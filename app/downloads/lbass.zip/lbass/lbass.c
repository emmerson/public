/*
* lbass.c
* BASS for Lua 5.1
* Andrew McWatters <me@andrewmcwatters.com>
* 12 Jan 2012 08:42:00
* This code is hereby placed in the public domain.
*/

#include "bass.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "lua.h"
#include "lauxlib.h"
#include "lchannel.h"

static int lBASS_ErrorGetCode (lua_State *L) {
  lua_pushinteger(L, BASS_ErrorGetCode());
  return 1;
}

static int lBASS_Free (lua_State *L) {
  lua_pushboolean(L, BASS_Free());
  return 1;
}

static int lBASS_GetCPU (lua_State *L) {
  lua_pushnumber(L, BASS_GetCPU());
  return 1;
}

static int lBASS_GetDevice (lua_State *L) {
  lua_pushinteger(L, BASS_GetDevice());
  return 1;
}

static int lBASS_GetVersion (lua_State *L) {
  lua_pushinteger(L, BASS_GetVersion());
  return 1;
}

static int lBASS_GetVolume (lua_State *L) {
  lua_pushnumber(L, BASS_GetVolume());
  return 1;
}

static int lBASS_Init (lua_State *L) {
  lua_pushboolean(L, BASS_Init(luaL_checkinteger(L, 1), luaL_checkinteger(L, 2), luaL_checkinteger(L, 3), FindWindowA(NULL, luaL_checkstring(L, 4)), NULL));
  return 1;
}

static int lBASS_Pause (lua_State *L) {
  lua_pushboolean(L, BASS_Pause());
  return 1;
}

static int lBASS_SetDevice (lua_State *L) {
  lua_pushboolean(L, BASS_SetDevice(luaL_checkinteger(L, 1)));
  return 1;
}

static int lBASS_SetVolume (lua_State *L) {
  lua_pushboolean(L, BASS_SetVolume((float)luaL_checknumber(L, 1)));
  return 1;
}

static int lBASS_Start (lua_State *L) {
  lua_pushboolean(L, BASS_Start());
  return 1;
}

static int lBASS_Stop (lua_State *L) {
  lua_pushboolean(L, BASS_Stop());
  return 1;
}

static int lBASS_Update (lua_State *L) {
  lua_pushboolean(L, BASS_Update(luaL_checkinteger(L, 1)));
  return 1;
}

static int lBASS_StreamCreateFile (lua_State *L) {
  lua_pushchannel(L, BASS_StreamCreateFile(FALSE, luaL_checkstring(L, 1), luaL_checkinteger(L, 2), luaL_checkinteger(L, 3), luaL_checkinteger(L, 4)));
  return 1;
}

static int lBASS_RecordFree (lua_State *L) {
  lua_pushboolean(L, BASS_RecordFree());
  return 1;
}

static int lBASS_RecordGetDevice (lua_State *L) {
  lua_pushinteger(L, BASS_RecordGetDevice());
  return 1;
}

static int lBASS_RecordGetInput (lua_State *L) {
  float volume = 0.0f;
  lua_pushinteger(L, BASS_RecordGetInput(luaL_checkinteger(L, 1), &volume));
  lua_pushnumber(L, volume);
  return 2;
}

static int lBASS_RecordGetInputName (lua_State *L) {
  lua_pushstring(L, BASS_RecordGetInputName(luaL_checkinteger(L, 1)));
  return 1;
}

static int lBASS_RecordInit (lua_State *L) {
  lua_pushboolean(L, BASS_RecordInit(luaL_checkinteger(L, 1)));
  return 1;
}

static int lBASS_RecordSetDevice (lua_State *L) {
  lua_pushboolean(L, BASS_RecordSetDevice(luaL_checkinteger(L, 1)));
  return 1;
}

static int lBASS_RecordSetInput (lua_State *L) {
  lua_pushboolean(L, BASS_RecordSetInput(luaL_checkinteger(L, 1), luaL_checkinteger(L, 2), (float)luaL_checknumber(L, 3)));
  return 1;
}

static int lBASS_RecordStart (lua_State *L) {
  lua_pushchannel(L, BASS_RecordStart(luaL_checkinteger(L, 1), luaL_checkinteger(L, 2), luaL_checkinteger(L, 3), NULL, NULL));
  return 1;
}


static const luaL_Reg BASS_funcs[] = {
  {"ErrorGetCode", lBASS_ErrorGetCode},
  {"Free", lBASS_Free},
  {"GetCPU", lBASS_GetCPU},
  {"GetDevice", lBASS_GetDevice},
  {"GetVersion", lBASS_GetVersion},
  {"GetVolume", lBASS_GetVolume},
  {"Init", lBASS_Init},
  {"Pause", lBASS_Pause},
  {"SetDevice", lBASS_SetDevice},
  {"SetVolume", lBASS_SetVolume},
  {"Start", lBASS_Start},
  {"Stop", lBASS_Stop},
  {"Update", lBASS_Update},
  {"StreamCreateFile", lBASS_StreamCreateFile},
  {"RecordFree", lBASS_RecordFree},
  {"RecordGetDevice", lBASS_RecordGetDevice},
  {"RecordGetInput", lBASS_RecordGetInput},
  {"RecordGetInputName", lBASS_RecordGetInputName},
  {"RecordInit", lBASS_RecordInit},
  {"RecordSetDevice", lBASS_RecordSetDevice},
  {"RecordStart", lBASS_RecordStart},
  {NULL, NULL}
};


LUALIB_API int luaopen_lbass (lua_State* L) {
  luaopen_channel(L);
  luaL_register(L, "BASS", BASS_funcs);
  return 1;
}

