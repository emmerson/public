/*
* lchannel.h
* Channel bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 12 Jan 2012 08:50:00
* This code is hereby placed in the public domain.
*/

LUA_API DWORD     *(lua_tochannel) (lua_State *L, int idx);


LUA_API void  (lua_pushchannel) (lua_State *L, DWORD channel);



LUALIB_API DWORD (luaL_checkchannel) (lua_State *L, int narg);


int luaopen_channel(lua_State *L);


