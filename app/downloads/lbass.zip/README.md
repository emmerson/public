lbass
=====

_This project is no longer maintained._

BASS Audio Library bindings for Lua 5.1
