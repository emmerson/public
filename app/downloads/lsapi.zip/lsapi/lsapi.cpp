/*
* lsapi.cpp
* Microsoft Speech API for Lua 5.1
* Andrew McWatters <me@andrewmcwatters.com>
* 4 Jan 2012 09:20:00
* This code is hereby placed in the public domain.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "sapi.h"
#include "process.h"

#include "lua.hpp"

ISpVoice *gpVoice = NULL;
ISpRecoContext *gpRecoContext = NULL;
ISpRecoGrammar *gpRecoGrammar = NULL;

HANDLE hVoiceThread = NULL;
SPSTATEHANDLE hStateLua = NULL;

char *lpSpokenResult = NULL;
WCHAR *pwszText = NULL;

BOOL APIENTRY DllMain( HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved ) {
  switch (ul_reason_for_call) {
    case DLL_PROCESS_ATTACH:
      if (FAILED(::CoInitialize(NULL)))
        return FALSE;
    case DLL_PROCESS_DETACH:
      ::CoUninitialize();
      break;
  }
  return TRUE;
}

static int ISpVoice_GetRate(lua_State* L) {
  long RateAdjust = 0;
  gpVoice->GetRate(&RateAdjust);
  lua_pushinteger(L, (int)RateAdjust);
  return 1;
}

static int ISpVoice_GetVolume(lua_State* L) {
  USHORT Volume = 0;
  gpVoice->GetVolume(&Volume);
  lua_pushinteger(L, (int)Volume);
  return 1;
}

static int ISpVoice_Pause(lua_State* L) {
  gpVoice->Pause();
  return 0;
}

unsigned __stdcall lfnSpeak(void* pArguments) {
  size_t size;
  const char *pChar = (const char *)pArguments;
  wchar_t wChar[255];
  mbstowcs_s(&size, wChar, 255, pChar, 255);
  gpVoice->Speak(wChar, SPF_ASYNC, NULL);
  gpVoice->WaitUntilDone(-1);
  _endthreadex(0);
  return 0;
}

static int ISpVoice_SetRate(lua_State* L) {
  gpVoice->SetRate(luaL_checkinteger(L, 1));
  return 0;
}

static int ISpVoice_SetVolume(lua_State* L) {
  gpVoice->SetVolume(luaL_checkinteger(L, 1));
  return 0;
}

static int ISpVoice_Speak(lua_State* L) {
  CloseHandle(hVoiceThread);
  unsigned threadID;
  hVoiceThread = (HANDLE)_beginthreadex(NULL, 0, &lfnSpeak, (void *)luaL_checkstring(L, 1), 0, &threadID);
  return 0;
}

static int ISpVoice_Resume(lua_State* L) {
  gpVoice->Resume();
  return 0;
}

static const luaL_Reg ISpVoicelib[] = {
  {"GetRate", ISpVoice_GetRate},
  {"GetVolume", ISpVoice_GetRate},
  {"Pause", ISpVoice_Pause},
  {"SetRate", ISpVoice_SetRate},
  {"SetVolume", ISpVoice_SetVolume},
  {"Speak", ISpVoice_Speak},
  {"Resume", ISpVoice_Resume},
  {NULL, NULL}
};


static int ISpRecoContext_Pause(lua_State* L) {
  gpRecoContext->Pause(NULL);
  return 0;
}

static int ISpRecoContext_Resume(lua_State* L) {
  gpRecoContext->Resume(NULL);
  return 0;
}

static const luaL_Reg ISpRecoContextlib[] = {
  {"Pause", ISpRecoContext_Pause},
  {"Resume", ISpRecoContext_Resume},
  {NULL, NULL}
};


static int ISpRecoGrammar_AddWordTransition(lua_State* L) {
  size_t PhraseSize;
  size_t size;
  const char *pszWord = luaL_checklstring(L, 1, &PhraseSize);
  wchar_t wsz[255];
  mbstowcs_s(&size, wsz, 255, pszWord, PhraseSize);
  gpRecoGrammar->AddWordTransition(hStateLua, NULL, (LPCWSTR)&wsz, L" ", SPWT_LEXICAL, 1, NULL);
  return 0;
}

static int ISpRecoGrammar_Commit(lua_State* L) {
  gpRecoGrammar->Commit(NULL);
  return 0;
}

#if 0
static int ISpRecoGrammar_IsPronounceable(lua_State* L) {
  size_t WordSize;
  size_t size;
  const char *pszWord = luaL_checklstring(L, 1, &WordSize);
  wchar_t wszWord[255];
  mbstowcs_s(&size, wszWord, 255, pszWord, WordSize);
  SPWORDPRONOUNCEABLE WordPronounceable;
  gpRecoGrammar->IsPronounceable((LPCWSTR)&wszWord, &WordPronounceable);
  lua_pushinteger(L, WordPronounceable);
  return 1;
}
#endif

static int ISpRecoGrammar_GetRule(lua_State* L) {
  size_t RuleSize;
  size_t size;
  const char *pszRuleName = luaL_checklstring(L, 1, &RuleSize);
  wchar_t wszRuleName[255];
  mbstowcs_s(&size, wszRuleName, 255, pszRuleName, RuleSize);
  gpRecoGrammar->GetRule((LPCWSTR)&wszRuleName, 0, SPRAF_TopLevel | SPRAF_Active, TRUE, &hStateLua);
  return 0;
}

static int ISpRecoGrammar_LoadDictation(lua_State* L) {
  gpRecoGrammar->LoadDictation(NULL, SPLO_DYNAMIC);
  return 0;
}

static int ISpRecoGrammar_SetDictationState(lua_State* L) {
  gpRecoGrammar->SetDictationState((SPRULESTATE)luaL_checkinteger(L, 1));
  return 0;
}

static int ISpRecoGrammar_SetRuleState(lua_State* L) {
  size_t RuleSize;
  size_t size;
  const char *pszRuleName = luaL_checklstring(L, 1, &RuleSize);
  wchar_t wszRuleName[255];
  mbstowcs_s(&size, wszRuleName, 255, pszRuleName, RuleSize);
  gpRecoGrammar->SetRuleState((LPCWSTR)&wszRuleName, NULL, (SPRULESTATE)luaL_checkinteger(L, 2));
  return 0;
}

static int ISpRecoGrammar_UnloadDictation(lua_State* L) {
  gpRecoGrammar->UnloadDictation();
  return 0;
}

static const luaL_Reg ISpRecoGrammarlib[] = {
  {"AddWordTransition", ISpRecoGrammar_AddWordTransition},
  {"Commit", ISpRecoGrammar_Commit},
  {"GetRule", ISpRecoGrammar_GetRule},
#if 0
  {"IsPronounceable", ISpRecoGrammar_IsPronounceable},
#endif
  {"LoadDictation", ISpRecoGrammar_LoadDictation},
  {"SetDictationState", ISpRecoGrammar_SetDictationState},
  {"SetRuleState", ISpRecoGrammar_SetRuleState},
  {"UnloadDictation", ISpRecoGrammar_UnloadDictation},
  {NULL, NULL}
};


static int ISpRecoResult_GetText(lua_State* L) {
  if (lpSpokenResult == NULL)
    lua_pushstring(L, "");
  else {
    char SpokenResult[255];
    strcpy_s(SpokenResult, lpSpokenResult);
    lua_pushstring(L, lpSpokenResult);
    delete[] lpSpokenResult;
    lpSpokenResult = NULL;
  }
  return 1;
}

static const luaL_Reg ISpRecoResultlib[] = {
  {"GetText", ISpRecoResult_GetText},
  {NULL, NULL}
};


void _stdcall lfnRecoCallback(WPARAM wParam, LPARAM lParam) {
  SPEVENT event;
  HRESULT hr = gpRecoContext->GetEvents(1, &event, NULL);
  if ( SUCCEEDED( hr ) ) {
    ISpRecoResult *pResult = reinterpret_cast<ISpRecoResult *>(event.lParam);
    pResult->GetText(SP_GETWHOLEPHRASE, SP_GETWHOLEPHRASE, FALSE, &pwszText, NULL);
    size_t size;
    char *pSpokenResult = new char[255];
    wcstombs_s(&size, pSpokenResult, 255, pwszText, 255);
    lpSpokenResult = pSpokenResult;
  }
}

extern "C" {
	LUALIB_API int luaopen_sapi (lua_State* L);
}

LUALIB_API int luaopen_sapi (lua_State* L) {
  HRESULT hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&gpVoice);
  if(!SUCCEEDED(hr))
    return 0;
  
  hr = CoCreateInstance(CLSID_SpSharedRecoContext, NULL, CLSCTX_ALL, IID_ISpRecoContext, (void **)&gpRecoContext);
  if(!SUCCEEDED(hr))
    return 0;

  gpRecoContext->CreateGrammar(1, &gpRecoGrammar);
  gpRecoGrammar->LoadDictation(NULL, SPLO_STATIC);
  gpRecoGrammar->SetDictationState(SPRS_ACTIVE);
  gpRecoContext->SetNotifyCallbackFunction(&lfnRecoCallback, NULL, NULL);
  gpRecoContext->SetInterest(SPFEI(SPEI_RECOGNITION), SPFEI(SPEI_RECOGNITION));

  luaL_register(L, "ISpVoice", ISpVoicelib);
  luaL_register(L, "ISpRecoContext", ISpRecoContextlib);
  luaL_register(L, "ISpRecoGrammar", ISpRecoGrammarlib);
  luaL_register(L, "ISpRecoResult", ISpRecoResultlib);
  lua_pop(L, 4);
  return 0;
}

