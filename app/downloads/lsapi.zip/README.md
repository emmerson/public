lsapi
=====

_This project is no longer maintained._

Microsoft Speech API bindings for Lua 5.1
