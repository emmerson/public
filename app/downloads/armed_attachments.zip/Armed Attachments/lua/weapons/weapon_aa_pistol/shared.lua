

if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "2"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:DrawHUD()

		self:SetupAttachmentPoints()

		local bAttach = self.Weapon:GetNetworkedBool( "Attachments" )

		if (!bAttach) then
			return;
		end

		local text_font		= "HudSelectionText"

		surface.SetFont( text_font )

		local i				= 1

		for k, nAttachment in pairs( self.m_Attachments ) do

			local Width, Height	= surface.GetTextSize( i )

			nAttachment			= nAttachment:ToScreen()
			local xpos			= nAttachment.x
			local ypos			= nAttachment.y
			local wide			= surface.SScale( 32 )
			local tall			= surface.SScale( 32 )

			draw.RoundedBox( 8, xpos, ypos, wide, tall, Panel.BgColor )

			local text_xpos		= xpos + surface.SScale( 4 )
			local text_ypos		= ypos + surface.SScale( 4 )

			draw.DrawText( i,	text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )

			i					= i + 1

		end

	end

end


SWEP.Base				= "swep_pistol"
SWEP.Category			= "Armed Attachments"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "None"

SWEP.AttachmentsPos		= Vector( 20.5, -8.75, 19 )
SWEP.AttachmentsAng		= Vector( 52.85, 38, 90 )

function SWEP:Initialize()

	self.BaseClass:Initialize()

	if ( SERVER ) then
		self:SetWeaponHoldType( self.HoldType )
	end

	self.Weapon:SetNetworkedBool( "Attachments", false )

end

function SWEP:PrimaryAttack()

	local bAttach = self.Weapon:GetNetworkedBool( "Attachments" )

	if (bAttach) then
		return;
	end

	local pPlayer = self.Owner;
	if (!pPlayer) then
		return;
	end

	if ( self.m_bAlternateInput && !self.m_bChangedFiringMode ) then
		self.m_bChangedFiringMode	= true;
		self.Weapon:EmitSound( self.Primary.Empty );
		self.Primary.Automatic		= !self.Primary.Automatic;
		if ( !self.Primary.Automatic ) then
			self.Primary.Cone		= VECTOR_CONE_2DEGREES
		else
			self.Primary.Cone		= VECTOR_CONE_3DEGREES
		end

		self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 );
		self.Weapon:SendWeaponAnim( ACT_VM_DRYFIRE );

		return;
	end

	if (self.m_bChangedFiringMode) then
		return;
	end

	if ( self.Weapon:Clip1() <= 0 && self.Primary.ClipSize > -1 ) then
		if ( self:Ammo1() > 0 ) then
			self.Weapon:EmitSound( self.Primary.Empty );
			self:Reload();
		else
			self.Weapon:EmitSound( self.Primary.Empty );
			self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay );
		end

		return;
	end

	if ( self.m_bIsUnderwater && !self.m_bFiresUnderwater ) then
		self.Weapon:EmitSound( self.Primary.Empty );
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 );

		return;
	end

	if ( (self.Primary.ClipSize > -1 && self.Weapon:Clip1() == 0) || ( self.Primary.ClipSize <= -1 && !pPlayer:GetAmmoCount(self.Primary.Ammo) ) ) then
		return;
	end

	pPlayer:MuzzleFlash();

	local iBulletsToFire = 0;
	local fireRate = self.Primary.Delay;

	self.Weapon:EmitSound(self.Primary.Sound);
	self.Weapon:SetNextPrimaryFire( CurTime() + fireRate );
	iBulletsToFire = iBulletsToFire + self.Primary.NumShots;

	if ( self.Primary.ClipSize > -1 ) then
		if ( iBulletsToFire > self.Weapon:Clip1() ) then
			iBulletsToFire = self.Weapon:Clip1();
		end
		self:TakePrimaryAmmo( self.Primary.NumAmmo );
	end

	self:ShootBullet( self.Primary.Damage, iBulletsToFire, self.Primary.Cone );

	if ( !pPlayer:IsNPC() ) then
		self:AddViewKick();
	end

	self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK );
	pPlayer:SetAnimation( PLAYER_ATTACK1 );

	self.m_nShotsFired = self.m_nShotsFired + 1

end

function SWEP:Reload()

	local bAttach = self.Weapon:GetNetworkedBool( "Attachments" )

	if (bAttach) then
		return;
	end

	self.Weapon:DefaultReload( ACT_VM_RELOAD );

end

local ATTACHMENT_TIME = 0.25

function SWEP:GetViewModelPosition( pos, ang )

	if ( !self.AttachmentsPos ) then return pos, ang end

	local bAttach = self.Weapon:GetNetworkedBool( "Attachments" )

	if ( bAttach != self.bLastAttach ) then

		self.bLastAttach = bAttach
		self.fAttachTime = CurTime()

	end

	local fAttachTime = self.fAttachTime or 0

	if ( !bAttach && fAttachTime < CurTime() - ATTACHMENT_TIME ) then
		return pos, ang
	end

	local Mul = 1.0

	if ( fAttachTime > CurTime() - ATTACHMENT_TIME ) then

		Mul = math.Clamp( (CurTime() - fAttachTime) / ATTACHMENT_TIME, 0, 1 )

		if (!bAttach) then Mul = 1 - Mul end

	end

	local Offset	= self.AttachmentsPos

	if ( self.AttachmentsAng ) then

		ang = ang * 1
		ang:RotateAroundAxis( ang:Right(), 		self.AttachmentsAng.x * Mul )
		ang:RotateAroundAxis( ang:Up(), 		self.AttachmentsAng.y * Mul )
		ang:RotateAroundAxis( ang:Forward(), 	self.AttachmentsAng.z * Mul )


	end

	local Right 	= ang:Right()
	local Up 		= ang:Up()
	local Forward 	= ang:Forward()



	pos = pos + Offset.x * Right * Mul
	pos = pos + Offset.y * Forward * Mul
	pos = pos + Offset.z * Up * Mul

	return pos, ang

end

function SWEP:ShowAttachments( b )

	local pPlayer = self.Owner;

	if ( pPlayer == NULL ) then
		return;
	end

	self.Weapon:SetNetworkedBool( "Attachments", b )

	if ( b ) then

		if ( SERVER ) then
			pPlayer:CrosshairDisable()
		end

	else

		if ( SERVER ) then
			pPlayer:CrosshairEnable()
		end

	end

end


SWEP.NextSecondaryAttack = 0
function SWEP:SecondaryAttack()

	if ( !self.AttachmentsPos ) then return end
	if ( self.NextSecondaryAttack > CurTime() ) then return end

	bAttachments = !self.Weapon:GetNetworkedBool( "Attachments", false )

	self:ShowAttachments( bAttachments )

	self.Weapon:SetNextPrimaryFire( CurTime() + 0.3 )
	self.m_fFireDuration = 0.0
	self.NextSecondaryAttack = CurTime() + 0.3

end

function SWEP:Think()

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( pPlayer:WaterLevel() >= 3 ) then
		self.m_bIsUnderwater = true;
	else
		self.m_bIsUnderwater = false;
	end

	if ( pPlayer:KeyDown( IN_USE ) ) then
		self.m_bAlternateInput		= true;
	elseif ( !pPlayer:KeyDown( IN_USE ) ) then
		self.m_bAlternateInput		= false;
		self.m_bChangedFiringMode	= false;
	end

	if ( pPlayer:KeyDown( IN_ATTACK ) ) then
		self.m_fFireDuration	= self.m_fFireDuration + FrameTime();
	elseif ( !pPlayer:KeyDown( IN_ATTACK ) ) then
		self.m_fFireDuration	= 0.0;
		self.m_nShotsFired		= 0;
	end

	if ( self.m_bShotDelayed && CurTime() > self.m_flDelayedFire ) then
		self:DelayedAttack();
	end

	self.BaseClass:Think();

end

function SWEP:SetupAttachmentPoints()

	self.m_Attachments					= self.m_Attachments || {};
	self.m_Attachments[ "muzzle" ]		= self:GetOwner():GetViewModel():GetAttachment( self:GetOwner():GetViewModel():LookupAttachment( "muzzle" ) ).Pos;
	self.m_Attachments[ "muzzle" ]		= self.m_Attachments[ "muzzle" ]	+ ( self:GetOwner():GetViewModel():GetForward()	* 10 );
	self.m_Attachments[ "secondary" ]	= self.m_Attachments[ "muzzle" ]	- ( self:GetOwner():GetViewModel():GetForward()	* 22 );
	self.m_Attachments[ "secondary" ]	= self.m_Attachments[ "secondary" ]	- ( self:GetOwner():GetViewModel():GetUp()		* 5 );

end

function SWEP:OnRestore()

	self.NextSecondaryAttack = 0
	self:ShowAttachments( false )

	local pPlayer = self.Owner;

	if ( pPlayer == NULL ) then
		return;
	end

	pPlayer:CrosshairEnable()

end

function SWEP:OnDrop()

	self:OnRestore()

	local pPlayer = self.Owner;

	if ( pPlayer == NULL ) then
		return;
	end

	pPlayer:CrosshairEnable()

end
