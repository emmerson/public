-------------------------------------------------------------------------------
-- Pod module and class definition
-- lwolframalpha
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local setmetatable = setmetatable

module( "wolframalpha.pod" )

-------------------------------------------------------------------------------
-- pod
-- Purpose: Class index
-------------------------------------------------------------------------------
local pod = {}

-------------------------------------------------------------------------------
-- __metatable
-- Purpose: Class metatable
-------------------------------------------------------------------------------
__metatable = {
	__index = pod,
	__type = "pod"
}

-------------------------------------------------------------------------------
-- pod.new()
-- Purpose: Creates a new pod object
-- Output: pod
-------------------------------------------------------------------------------
function new()
	local t = {
		title = nil,
		scanner = nil,
		id = nil,
		position = nil,
		error = nil,
		numsubpods = nil,
		primary = nil,
		subpods = {}
	}
	setmetatable( t, __metatable )
	return t
end

-------------------------------------------------------------------------------
-- pod()
-- Purpose: Shortcut to pod.new()
-- Output: pod
-------------------------------------------------------------------------------
local metatable = {
	__call = function( _, ... )
		return new( ... )
	end
}
setmetatable( _M, metatable )

-------------------------------------------------------------------------------
-- pod:__tostring()
-- Purpose: __tostring metamethod for pod
-------------------------------------------------------------------------------
function __metatable:__tostring()
	if not self.title then return "invalid pod" end
	return "pod: " .. self.title
end
