-------------------------------------------------------------------------------
-- Queryresult module and class definition
-- lwolframalpha
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local error = error
local ipairs = ipairs
local pairs = pairs
local pod = require( "wolframalpha.pod" )
local setmetatable = setmetatable
local string = string
local subpod = require( "wolframalpha.subpod" )
local tostring = tostring

module( "wolframalpha.queryresult" )

-------------------------------------------------------------------------------
-- queryresult
-- Purpose: Class index
-------------------------------------------------------------------------------
local queryresult = {}

-------------------------------------------------------------------------------
-- __metatable
-- Purpose: Class metatable
-------------------------------------------------------------------------------
__metatable = {
	__index = queryresult,
	__type = "queryresult"
}

-------------------------------------------------------------------------------
-- queryresult.parse()
-- Purpose: Creates a new queryresult object from an XML tree
-- Input: t - XML tree
-- Output: queryresult
-------------------------------------------------------------------------------
function parse( t )
	local queryresult = new()
	for k, v in pairs( t[ 2 ].xarg ) do
		queryresult[ k ] = v
	end
	if ( t[ 2 ][ 1 ].label and t[ 2 ][ 1 ].label == "error" ) then
		queryresult.errortable.code	= t[ 2 ][ 1 ][ 1 ][ 1 ]
		queryresult.errortable.msg	= t[ 2 ][ 1 ][ 2 ][ 1 ]
	end
	-- Andrew; Do we need to continue from here if there was an error?
	for i, v in ipairs( t[ 2 ] ) do
		if ( v.label == "pod" ) then
			local pod = pod()
			for k, w in pairs( v.xarg ) do
				pod[ k ] = w
			end
			for j, w in ipairs( v ) do
				if ( w.label == "subpod" ) then
					local subpod = subpod()
					for k, x in pairs( w.xarg ) do
						subpod[ k ] = x
					end
					for k, x in ipairs( w ) do
						if ( #x.xarg > 1 ) then
							subpod[ x.label ] = {}
							for l, y in pairs( x.xarg ) do
								subpod[ x.label ][ l ] = y
							end
						else
							subpod[ x.label ] = x[ 1 ]
						end
					end
					pod.subpods[ w.xarg.title == "" and j or w.xarg.title ] = subpod
				end
			end
			queryresult.pods[ v.xarg.title ] = pod
		end
	end
	return queryresult
end

-------------------------------------------------------------------------------
-- queryresult.new()
-- Purpose: Creates a new queryresult object
-- Output: queryresult
-------------------------------------------------------------------------------
function new()
	local t = {
		success = nil,
		error = nil,
		numpods = nil,
		datatypes = nil,
		timedout = nil,
		timedoutpods = nil,
		timing = nil,
		parsetiming = nil,
		parsetimedout = nil,
		recalculate = nil,
		id = nil,
		host = nil,
		server = nil,
		related = nil,
		version = nil,
		pods = {},
		errortable = {}
	}
	t.__address = string.gsub( tostring( t ), "table: ", "" )
	setmetatable( t, __metatable )
	return t
end

-------------------------------------------------------------------------------
-- queryresult()
-- Purpose: Shortcut to queryresult.new()
-- Output: queryresult
-------------------------------------------------------------------------------
local metatable = {
	__call = function( _, ... )
		return new( ... )
	end
}
setmetatable( _M, metatable )

-------------------------------------------------------------------------------
-- queryresult:geterror()
-- Purpose: Returns the error table of the queryresult
-------------------------------------------------------------------------------
function queryresult:geterror()
	return self.errortable
end

-------------------------------------------------------------------------------
-- queryresult:getinputinterpretation()
-- Purpose: Returns the plaintext input interpretation value of the queryresult
-------------------------------------------------------------------------------
function queryresult:getinputinterpretation()
	return self.pods[ "Input interpretation" ].subpods[ 1 ].plaintext
end

-------------------------------------------------------------------------------
-- queryresult:getresult()
-- Purpose: Returns the plaintext result value of the queryresult
-------------------------------------------------------------------------------
function queryresult:getresult()
	if ( self.pods[ "Result" ] == nil ) then error( "queryresult has no result!", 2 ) end
	return self.pods[ "Result" ].subpods[ 1 ].plaintext
end

-------------------------------------------------------------------------------
-- queryresult:__tostring()
-- Purpose: __tostring metamethod for queryresult
-------------------------------------------------------------------------------
function __metatable:__tostring()
	return "queryresult: " .. self.__address
end
