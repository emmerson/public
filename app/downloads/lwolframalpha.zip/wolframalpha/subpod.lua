-------------------------------------------------------------------------------
-- Subpod module and class definition
-- lwolframalpha
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local setmetatable = setmetatable

module( "wolframalpha.subpod" )

-------------------------------------------------------------------------------
-- subpod
-- Purpose: Class index
-------------------------------------------------------------------------------
local subpod = {}

-------------------------------------------------------------------------------
-- __metatable
-- Purpose: Class metatable
-------------------------------------------------------------------------------
__metatable = {
	__index = subpod,
	__type = "subpod"
}

-------------------------------------------------------------------------------
-- subpod.new()
-- Purpose: Creates a new subpod object
-- Output: subpod
-------------------------------------------------------------------------------
function new()
	local t = {
		title = nil,
		plaintext = nil,
		img = {}
	}
	setmetatable( t, __metatable )
	return t
end

-------------------------------------------------------------------------------
-- subpod()
-- Purpose: Shortcut to subpod.new()
-- Output: subpod
-------------------------------------------------------------------------------
local metatable = {
	__call = function( _, ... )
		return new( ... )
	end
}
setmetatable( _M, metatable )

-------------------------------------------------------------------------------
-- subpod:__tostring()
-- Purpose: __tostring metamethod for subpod
-------------------------------------------------------------------------------
function __metatable:__tostring()
	return "subpod: " .. self.title
end
