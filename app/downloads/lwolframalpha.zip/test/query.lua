-- query.lua
-- performs a general query on Wolfram|Alpha's Webservice API
-- usage: lua test\query.lua

local wolframalpha = require( "wolframalpha" )
io.write( "appid: " )
local appid = io.read()
io.write( "query: " )
local query = io.read()

wolframalpha.setappid( appid )
wolframalpha.setversion( 2 )

require( "connectors.luasocket" )

local c, r = wolframalpha.query( query )
if ( r.error == true ) then
	print( "error: " .. r:geterror().msg )
else
	-- Andrew; not all queries have linear results!!
	print( "result: " .. r:getresult() )
end
