-- hello, world!

local wolframalpha = require( "wolframalpha" )
io.write( "appid: " )
wolframalpha.setappid( io.read() )
wolframalpha.setversion( 2 )

require( "connectors.luasocket" )

local c, r = wolframalpha.query( "Hello, Wolfram|Alpha!" )
if ( r.error == true ) then
	print( r:geterror().msg )
else
	print( r:getresult() )
end
