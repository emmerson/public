-------------------------------------------------------------------------------
-- LuaSocket connector
-- lwolframalpha
-- Author: Andrew McWatters
-------------------------------------------------------------------------------
local http = require( "socket.http" )

function wolframalpha.http.get( URL )
	local b, c, h = http.request( URL )
	return b, c
end
