-------------------------------------------------------------------------------
-- LuaCURL connector
-- lwolframalpha
-- Authors: Andrew McWatters
--			Gran PC
--			Gregor Steiner
-------------------------------------------------------------------------------
require( "luacurl" )

local curl = curl
local string = string
local table = table
local tonumber = tonumber

local function curlWrite( bufferTable )
	return function( stream, buffer )
		table.insert( bufferTable, buffer )
		return string.len( buffer )
	end
end

function wolframalpha.http.get( URL )
	local ht = {}
	local t = {}
	local curlObj = curl.new()
	
	curlObj:setopt( curl.OPT_WRITEFUNCTION, curlWrite( t ) )
	curlObj:setopt( curl.OPT_URL, URL )
	
	curlObj:perform()
	curlObj:close()
	
	local r = table.concat( t, "" )
	local h, c, m = string.match( r, "(.-) (.-) (.-)\n" )
	return r, tonumber( c )
end
