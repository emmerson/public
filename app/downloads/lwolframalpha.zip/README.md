lwolframalpha
=============

_This project is no longer maintained._

Wolfram|Alpha Webservice API bindings for Lua 5.1
