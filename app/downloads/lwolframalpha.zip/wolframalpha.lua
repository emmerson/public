-----------------------------------------------------------------------------
-- Wolfram|Alpha Webservice API
-- lwolframalpha
-- Author: Andrew McWatters
-----------------------------------------------------------------------------
local require	= require
local tostring	= tostring

module( "wolframalpha" )

http		= require( "wolframalpha.http" )
pod			= require( "wolframalpha.pod" )
queryresult	= require( "wolframalpha.queryresult" )
subpod		= require( "wolframalpha.subpod" )
url			= require( "wolframalpha.url" )
xml			= require( "wolframalpha.xml" )

rootURL		= "http://api.wolframalpha.com"
appid		= "XXXX"
version		= "v2"

-------------------------------------------------------------------------------
-- wolframalpha.setappid()
-- Purpose: Sets the appid to use with queries
-- Input: appId - appid string
-------------------------------------------------------------------------------
function setappid( appId )
	appid = appId
end

-------------------------------------------------------------------------------
-- wolframalpha.setversion()
-- Purpose: Sets the version of the webservice API to use with queries
-- Input: n - version number
-------------------------------------------------------------------------------
function setversion( n )
	version = "v" .. tostring( n )
end

-------------------------------------------------------------------------------
-- wolframalpha.query()
-- Purpose: Returns 0 if the query is retrieved successfully, then a
--			queryresult object, otherwise -1 if the query was not retrieved at
--			all and nil, or 1 if the query was not successful along with
--			details in a partial queryresult object
-- Input: s - string query
-- Output: error code, queryresult
-------------------------------------------------------------------------------
function query( s )
	local r, c = http.get( rootURL .. "/" ..
						   version .. "/query" ..
						   "?input=" .. url.escape( s ) ..
						   "&appid=" .. appid )
	if ( c ~= 200 ) then
		return -1, nil
	end

	local t = xml.collect( r )
	-- xml.printt( t )
	local queryresult = queryresult.parse( t )
	if ( queryresult.success ) then
		return 0, queryresult
	else
		return 1, queryresult
	end
end
