//========= Copyright � 1996-2005, Valve Corporation, All rights reserved. ============//
//
// Purpose: Definitions that are shared by the game DLL and the client DLL.
//
// $NoKeywords: $
//=============================================================================//

WATERJUMP_HEIGHT			= 8

MAX_CLIMB_SPEED		= 200

TIME_TO_DUCK		= 0.4
TIME_TO_DUCK_MS		= 400.0
TIME_TO_UNDUCK		= 0.2
TIME_TO_UNDUCK_MS	= 200.0

MAX_WEAPON_SLOTS		= 6		// hud item selection slots
MAX_WEAPON_POSITIONS	= 20	// max number of items within a slot
MAX_ITEM_TYPES			= 6		// hud item selection slots
MAX_WEAPONS				= 48	// Max number of weapons available

MAX_ITEMS				= 5	// hard coded item types

WEAPON_NOCLIP			= -1	// clip sizes set to this tell the weapon it doesn't use a clip

MAX_AMMO_TYPES	= 32		// ???
MAX_AMMO_SLOTS  = 32		// not really slots

//===================================================================================================================
// Player Defines

// Max number of players in a game ( see const.h for ABSOLUTE_PLAYER_LIMIT (256 ) )
// The Source engine is really designed for 32 or less players.  If you raise this number above 32, you better know what you are doing
//  and have a good answer for a bunch of perf question related to player simulation, thinking logic, tracelines, networking overhead, etc.
// But if you are brave or are doing something interesting, go for it...   ywb 9/22/03

//You might be wondering why these aren't multiple of 2. Well the reason is that if servers decide to have HLTV enabled we need the extra slot.
//This is ok since MAX_PLAYERS is used for code specific things like arrays and loops, but it doesn't really means that this is the max number of players allowed
//Since this is decided by the gamerules (and it can be whatever number as long as its less than MAX_PLAYERS).
MAX_PLAYERS				= 129  // Absolute max players supported

MAX_PLACE_NAME_LENGTH		= 18

//===================================================================================================================
// Team Defines
TEAM_INVALID			= -1
// Start your team numbers after this
LAST_SHARED_TEAM		= TEAM_SPECTATOR

// The first team that's game specific (i.e. not unassigned / spectator)
FIRST_GAME_TEAM			= (LAST_SHARED_TEAM+1)

MAX_TEAMS				= 32	// Max number of teams in a game
MAX_TEAM_NAME_LENGTH	= 32	// Max length of a team's name

// -----------------------------------------
// Skill Level
// -----------------------------------------
SKILL_EASY		= 1
SKILL_MEDIUM	= 2
SKILL_HARD		= 3


MAX_BEAM_ENTS			= 10

// HL2 has 600 gravity by default
// NOTE: The discrete ticks can have quantization error, so these numbers are biased a little to
// make the heights more exact
PLAYER_FATAL_FALL_SPEED		= 922.5 // approx 60 feet sqrt( 2 * gravity * 60 * 12 )
PLAYER_MAX_SAFE_FALL_SPEED	= 526.5 // approx 20 feet sqrt( 2 * gravity * 20 * 12 )
PLAYER_LAND_ON_FLOATING_OBJECT	= 173 // Can fall another 173 in/sec without getting hurt
PLAYER_MIN_BOUNCE_SPEED		= 173
PLAYER_FALL_PUNCH_THRESHOLD = 303.0 // won't punch player's screen/make scrape noise unless player falling at least this fast - at least a 76" fall (sqrt( 2 * g * 76))
DAMAGE_FOR_FALL_SPEED		= 100.0 / ( PLAYER_FATAL_FALL_SPEED - PLAYER_MAX_SAFE_FALL_SPEED ) // damage per unit per second.


AUTOAIM_2DEGREES  = 0.0348994967025
AUTOAIM_5DEGREES  = 0.08715574274766
AUTOAIM_8DEGREES  = 0.1391731009601
AUTOAIM_10DEGREES = 0.1736481776669
AUTOAIM_20DEGREES = 0.3490658503989

AUTOAIM_SCALE_DEFAULT		= 1.0
AUTOAIM_SCALE_DIRECT_ONLY	= 0.0

// settings for m_takedamage
DAMAGE_NO				= 0
DAMAGE_EVENTS_ONLY		= 1		// Call damage functions, but don't modify health
DAMAGE_YES				= 2
DAMAGE_AIM				= 3

LAST_PLAYER_OBSERVERMODE	= OBS_MODE_ROAMING

// basic team colors
color_red		= Color(255, 64, 64, 255)
color_blue		= Color(153, 204, 255, 255)
color_yellow	= Color(255, 178, 0, 255)
color_green		= Color(153, 255, 153, 255)
color_grey		= Color(204, 204, 204, 255)

// Shared think context stuff
MAX_CONTEXT_LENGTH		= 32
NO_THINK_CONTEXT	= -1

//-----------------------------------------------------------------------------
MAX_SCREEN_OVERLAYS		= 10

MAX_ACTORS_IN_SCENE = 16

//-----------------------------------------------------------------------------
// Multiplayer specific defines
//-----------------------------------------------------------------------------
MAX_CONTROL_POINTS			= 8
MAX_CONTROL_POINT_GROUPS	= 8

// Maximum number of points that a control point may need owned to be cappable
MAX_PREVIOUS_POINTS			= 3

// The maximum number of teams the control point system knows how to deal with
MAX_CONTROL_POINT_TEAMS		= 8

// Maximum length of the cap layout string
MAX_CAPLAYOUT_LENGTH		= 32

// Maximum length of the current round printname
MAX_ROUND_NAME				= 32

// Maximum length of the current round name
MAX_ROUND_IMAGE_NAME		= 64

// Score added to the team score for a round win
TEAMPLAY_ROUND_WIN_SCORE	= 1

//-----------------------------------------------------------------------------
// Commentary Mode
//-----------------------------------------------------------------------------
// The player's method of starting / stopping commentary
COMMENTARY_BUTTONS		= (IN_USE)
