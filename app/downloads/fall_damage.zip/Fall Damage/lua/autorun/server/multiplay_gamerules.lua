//========= Copyright � 1996-2005, Valve Corporation, All rights reserved. ============//
//
// Purpose: Contains the implementation of game rules for multiplayer.
//
// $NoKeywords: $
//=============================================================================//

game.ConsoleCommand( "mp_falldamage 1\n" )

//=========================================================
//=========================================================
local function FlPlayerFallDamage( pPlayer, m_flFallVelocity )
	local iFallDamage = server_settings.Bool( "mp_falldamage", 1 );

	if ( iFallDamage ) then
		m_flFallVelocity = m_flFallVelocity - PLAYER_MAX_SAFE_FALL_SPEED;
		return m_flFallVelocity * DAMAGE_FOR_FALL_SPEED;
	else
		return 10;
	end
end

hook.Add( "GetFallDamage", "FlPlayerFallDamage", FlPlayerFallDamage )
