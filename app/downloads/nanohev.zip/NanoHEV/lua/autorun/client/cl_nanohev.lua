
local function BinocularZoomIn( player, key )

	if ( player:GetCanZoom() && key == IN_ZOOM ) then

		surface.PlaySound( "interface_suit/Binocular Zoom In.wav" )

	end

end

hook.Add( "KeyPress", "BinocularZoomIn", BinocularZoomIn )

local function BinocularZoomOut( player, key )

	if ( player:GetCanZoom() && key == IN_ZOOM ) then

		surface.PlaySound( "interface_suit/Binocular Zoom Out.wav" )

	end

end

hook.Add( "KeyRelease", "BinocularZoomOut", BinocularZoomOut )

local function SuitBreathUnderwater()

	local ply = LocalPlayer()

	if ( ply:WaterLevel() >= 3 ) then

		if ( !ply.m_bIsUsingSuitOxygen ) then

			ply.m_bIsUsingSuitOxygen = true
			surface.PlaySound( "interface_suit/Suit Breath Underwater Activat.wav" )

		end

	else

		ply.m_bIsUsingSuitOxygen = false

	end

end

hook.Add( "Think", "SuitBreathUnderwater", SuitBreathUnderwater )

