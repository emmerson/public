

if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "Time Grenade"
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "4"

	killicon.AddFont( "sent_grenade_time", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_frag"
SWEP.Category			= "Garry's Mod Plus"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.AmmoType		= "sent_grenade_time"
