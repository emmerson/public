
ENT.Sound				= {}
ENT.Sound.Blip			= {

	Sound( "npc/overwatch/radiovoice/one.wav" ),
	Sound( "npc/overwatch/radiovoice/two.wav" ),
	Sound( "npc/overwatch/radiovoice/three.wav" ),
	Sound( "npc/overwatch/radiovoice/four.wav" ),
	Sound( "npc/overwatch/radiovoice/five.wav" ),
	Sound( "npc/overwatch/radiovoice/six.wav" ),
	Sound( "npc/overwatch/radiovoice/seven.wav" ),
	Sound( "npc/overwatch/radiovoice/eight.wav" ),
	Sound( "npc/overwatch/radiovoice/nine.wav" )

}

ENT.Sound.pilB			= {

	Sound( "npc/overwatch/radiovoice/eno.wav" ),
	Sound( "npc/overwatch/radiovoice/owt.wav" ),
	Sound( "npc/overwatch/radiovoice/eerht.wav" ),
	Sound( "npc/overwatch/radiovoice/ruof.wav" ),
	Sound( "npc/overwatch/radiovoice/evif.wav" ),
	Sound( "npc/overwatch/radiovoice/xis.wav" ),
	Sound( "npc/overwatch/radiovoice/neves.wav" ),
	Sound( "npc/overwatch/radiovoice/thgie.wav" ),
	Sound( "npc/overwatch/radiovoice/enin.wav" )

}

for k, v in pairs( ENT.Sound.pilB ) do

	if ( !CLIENT ) then resource.AddFile( v ) end

end

ENT.Sound.Explode		= {

	Sound( "ambient/explosions/citadel_end_explosion1.wav" ),
	Sound( "ambient/explosions/citadel_end_explosion2.wav" )

}

ENT.Sound.Time			= 0.0

ENT.Trail				= {}
ENT.Trail.Color			= Color( 0, 0, 255, 255 )
ENT.Trail.Material		= "trails/tube.vmt"
ENT.Trail.StartWidth	= 4.0
ENT.Trail.EndWidth		= 0.5

for _, v in pairs( ENT.Sound.Blip ) do
	ENT.Sound.Time		= ENT.Sound.Time + SoundDuration( v ) + FRAG_GRENADE_BLIP_FREQUENCY
end

ENT.Sound.Time			= ENT.Sound.Time - FRAG_GRENADE_BLIP_FREQUENCY * 2

ENT.Trail.LifeTime		= ENT.Sound.Time * 2

// Nice helper function, this does all the work.

/*---------------------------------------------------------
   Name: DoExplodeEffect
---------------------------------------------------------*/
function ENT:DoExplodeEffect()

	if ( self.ConstrainedEntities ) then

		for k, v in pairs( self.ConstrainedEntities ) do

			if ( v && v:IsValid() ) then

				local info = EffectData();
				info:SetOrigin( v:LocalToWorld( v:OBBCenter() ) );
				info:SetMagnitude( 0.01 );
				info:SetScale( 0.5 );

				util.Effect( "shockwave", info );

			end

		end

		return;

	end

	local info = EffectData();
	info:SetOrigin( self.Entity:LocalToWorld( self.Entity:OBBCenter() ) );
	info:SetMagnitude( 0.01 );
	info:SetScale( 0.05 );

	util.Effect( "shockwave", info );

end

/*---------------------------------------------------------
   Name: OnExplode
   Desc: The grenade has just exploded.
---------------------------------------------------------*/
function ENT:OnExplode( pTrace )

	self.m_bDetonated		= true
	self.m_flRewindDuration	= CurTime() + self.Sound.Time - 0.1

	if ( !self.ConstrainedEntities ) then
		return
	end

	if ( #self.ConstrainedEntities <= 0 ) then
		return
	end

	for k, v in pairs( self.ConstrainedEntities ) do

		if ( v && v:IsValid() ) then

			for i = 1, v:GetPhysicsObjectCount() do

				if ( v:IsVehicle() || v:GetPhysicsObjectCount() == 1 ) then

					local Phys = v:GetPhysicsObject()
					if ( Phys ) then

						Phys:EnableMotion( false )

					end

				else

					local Phys = v:GetPhysicsObjectNum( i )
					if ( Phys ) then

						Phys:EnableMotion( false )

					end

				end

			end

			v:SetUnFreezable( true )

		end

	end

end

/*---------------------------------------------------------
   Name: OnInitialize
---------------------------------------------------------*/
function ENT:OnInitialize()

	self.m_flDetonateTime = CurTime() + self.Sound.Time
	self:OnThink()

end

/*---------------------------------------------------------
   Name: StartTouch
---------------------------------------------------------*/
function ENT:StartTouch( entity )

	if (entity.m_bIsRecording) then return end
	if (self.m_bDetonated) then return end

	if (!entity ) then return end
	if (!entity:IsValid()) then return end
	if (entity:IsPlayer()) then return end
	if (entity:IsNPC()) then return end
	if (string.find(entity:GetClass(), "trigger_")) then return end
	if (entity:GetClass() == self:GetClass()) then return end

	self.Entity:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.Entity:SetParent( entity )

end

/*---------------------------------------------------------
   Name: EndTouch
---------------------------------------------------------*/
function ENT:EndTouch( entity )

	if (entity.m_bIsRecording) then return end
	if (self.m_bDetonated) then return end

	if (!entity ) then return end
	if (!entity:IsValid()) then return end
	if (entity:IsPlayer()) then return end
	if (entity:IsNPC()) then return end
	if (string.find(entity:GetClass(), "trigger_")) then return end
	if (entity:GetClass() == self:GetClass()) then return end

	self.ConstrainedEntities = {}

	local ents = constraint.GetAllConstrainedEntities( entity )

	for _, v in pairs( ents ) do
		v.m_bIsRecording = true
		table.insert( self.ConstrainedEntities, v )
	end

end

/*---------------------------------------------------------
   Name: Touch
---------------------------------------------------------*/
function ENT:Touch( entity )

	if (entity.m_bIsRecording) then return end
	if (self.m_bDetonated) then return end

	if (!entity ) then return end
	if (!entity:IsValid()) then return end
	if (entity:IsPlayer()) then return end
	if (entity:IsNPC()) then return end
	if (string.find(entity:GetClass(), "trigger_")) then return end
	if (entity:GetClass() == self:GetClass()) then return end

	self.Entity:EmitSound( "Buttons.snd19" )

end

/*---------------------------------------------------------
   Name: OnThink
---------------------------------------------------------*/
function ENT:OnThink()

	hook.Add( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")", function()

		if ( !self.ConstrainedEntities && !self.m_bDetonated ) then

			self.EntIteration	= self.EntIteration	|| 0
			self.EntKeyFrames	= self.EntKeyFrames	|| {}

			if ( self.Entity && self.Entity:IsValid() ) then

				local Data		= {}
				Data.Pos		= self.Entity:GetPos()
				Data.Angle		= self.Entity:GetAngles()

				self.EntKeyFrames						= self.EntKeyFrames							|| {}
				self.EntKeyFrames[ self.EntIteration ]	= self.EntKeyFrames[ self.EntIteration ]	|| {}
				table.insert( self.EntKeyFrames[ self.EntIteration ], Data )

				self.EntIteration	= self.EntIteration	+ 1

			end

		elseif ( !self.ConstrainedEntities ) then

			if ( self.Entity && self.Entity:IsValid() && self.EntKeyFrames ) then

				if ( self.EntKeyFrames[ self.EntIteration ] ) then

					if ( self.EntKeyFrames[ self.EntIteration ][ 1 ] ) then

						local Data = self.EntKeyFrames[ self.EntIteration ][ 1 ]

						self.Entity:SetPos( Data.Pos )
						self.Entity:SetAngles( Data.Angle )

					end

				end

			end

			self.EntIteration	= self.EntIteration	|| 0
			self.EntIteration	= self.EntIteration	- 1

			if ( self.EntIteration < 1 ) then

				self.EntIteration = 1

			end

		end

		if ( self.Entity && self.Entity:IsValid() ) then

			if ((self.m_flRewindDuration < CurTime()) && self.m_bDetonated) then

				if ( !self.m_bRespawned ) then

					local Data	= {}
					Data.Model	= self.Entity:GetModel()
					Data.Pos	= self.Entity:GetPos()
					Data.Angle	= self.Entity:GetAngles()

					local pGrenade = ents.Create( "gmp_timegrenade" )
					duplicator.DoGeneric( pGrenade, Data )
					pGrenade:Spawn()

					constraint.NoCollide( pGrenade, self.Entity, 0, 0 )

					self.m_bRespawned = true

				end

			end

		end

		if ( !self.ConstrainedEntities ) then
			return
		end

		if ((self.m_flRewindDuration < CurTime()) && self.m_bDetonated) then

			for k, v in pairs( self.ConstrainedEntities ) do

				if ( v && v:IsValid() ) then

					for i = 1, v:GetPhysicsObjectCount() do

						if ( v:IsVehicle() || v:GetPhysicsObjectCount() == 1 ) then

							local Phys = v:GetPhysicsObject()
							if ( Phys ) then

								Phys:EnableMotion( true )
								Phys:Wake()

							end

						else

							local Phys = v:GetPhysicsObjectNum( i )
							if ( Phys ) then

								Phys:EnableMotion( true )
								Phys:Wake()

							end

						end

					end

					v.m_bIsRecording = nil
					v:SetUnFreezable( false )

				end

			end

			hook.Remove( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")" )

		end

		if ( !self.m_bDetonated ) then

			self.Iteration	= self.Iteration	|| 0
			self.KeyFrames	= self.KeyFrames	|| {}

			for k, v in pairs( self.ConstrainedEntities ) do

				if ( v && v:IsValid() ) then

					for i = 1, v:GetPhysicsObjectCount() do

						if ( v:IsVehicle() || v:GetPhysicsObjectCount() == 1 ) then

							local Data		= {}
							Data.Pos		= v:GetPos()
							Data.Angle		= v:GetAngles()

							self.KeyFrames[ k ]						= self.KeyFrames[ k ]					|| {}
							self.KeyFrames[ k ][ self.Iteration ]	= self.KeyFrames[ k ][ self.Iteration ]	|| {}
							table.insert( self.KeyFrames[ k ][ self.Iteration ], Data )

						else

							local Pos, Ang	= v:GetBonePosition( v:TranslatePhysBoneToBone( i ) )

							local Data		= {}
							Data.Pos		= Pos
							Data.Angle		= Ang

							self.KeyFrames[ k ]							= self.KeyFrames[ k ]							|| {}
							self.KeyFrames[ k ][ self.Iteration ]		= self.KeyFrames[ k ][ self.Iteration ]			|| {}
							self.KeyFrames[ k ][ self.Iteration ][ i ]	= self.KeyFrames[ k ][ self.Iteration ][ i ]	|| {}
							table.insert( self.KeyFrames[ k ][ self.Iteration ][ i ], Data )

						end

					end

				end

			end

			self.Iteration	= self.Iteration	+ 1

		else

			for k, v in pairs( self.ConstrainedEntities ) do

				if ( v && v:IsValid() && self.KeyFrames[ k ] ) then

					if ( self.KeyFrames[ k ][ self.Iteration ] ) then

						if ( self.KeyFrames[ k ][ self.Iteration ][ 1 ] ) then

							for i = 1, v:GetPhysicsObjectCount() do

								if ( v:IsVehicle() || v:GetPhysicsObjectCount() == 1 ) then

									local Data = self.KeyFrames[ k ][ self.Iteration ][ 1 ]

									v:SetPos( Data.Pos )
									v:SetAngles( Data.Angle )

								else

									local Data = self.KeyFrames[ k ][ self.Iteration ][ i ][ 1 ]

									local Phys = v:GetPhysicsObjectNum( i )
									if ( Phys ) then

										Phys:SetPos( Data.Pos )
										Phys:SetAngle( Data.Angle )

									end

								end

							end

						end

					end

				end

			end

			self.Iteration	= self.Iteration	|| 0
			self.Iteration	= self.Iteration	- 1

			if ( self.Iteration < 1 ) then

				self.Iteration = 1

			end

		end

	end )

end