

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_boxnade.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_boxnade.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	language.Add( "HL2_Boxnade", "BOXNADE" )

	SWEP.PrintName			= "#HL2_Boxnade"
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "4"

	killicon.AddFont( "sent_grenade_box", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_grenade"
SWEP.Category			= SWEP.Author

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.AmmoType		= "sent_grenade_box"
