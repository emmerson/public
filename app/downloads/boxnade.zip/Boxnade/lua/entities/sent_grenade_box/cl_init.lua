
include('shared.lua')

/*---------------------------------------------------------
   Name: Draw
---------------------------------------------------------*/
function ENT:Draw()

	self.Entity:SetModelScale( Vector( 1 / 3, 1 / 3, 1 / 3 ) )
	self.Entity:DrawModel()

end
