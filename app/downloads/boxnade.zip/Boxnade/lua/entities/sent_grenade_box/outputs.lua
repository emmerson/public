
// Nice helper function, this does all the work.

/*---------------------------------------------------------
   Name: DoExplodeEffect
---------------------------------------------------------*/
function ENT:DoExplodeEffect()

	local info = EffectData();
	info:SetEntity( self.Entity );
	info:SetOrigin( self.Entity:GetPos() );

	util.Effect( "Explosion", info );

end

/*---------------------------------------------------------
   Name: OnExplode
   Desc: The grenade has just exploded.
---------------------------------------------------------*/
function ENT:OnExplode( pTrace )

	local Pos1 = Vector( self.Entity:GetPos().x, self.Entity:GetPos().y, pTrace.HitPos.z ) + pTrace.HitNormal
	local Pos2 = Vector( self.Entity:GetPos().x, self.Entity:GetPos().y, pTrace.HitPos.z ) - pTrace.HitNormal

 	util.Decal( "Scorch", Pos1, Pos2 );

	local Data	= {}
	Data.Model	= self:GetModel()
	Data.Pos	= self:GetPos()
	Data.Angle	= self:GetAngles()

	local angVel	= self.Entity:GetPhysicsObject():GetAngleVelocity();
	local Vel		= self.Entity:GetPhysicsObject():GetVelocity();

	local pBox = ents.Create( "prop_physics_multiplayer" )
	duplicator.DoGeneric( pBox, Data )
	pBox:Spawn();

	if ( GAMEMODE.IsSandboxDerived ) then

		undo.Create("Prop")
			undo.AddEntity( pBox )
			undo.SetPlayer( self:GetOwner() )
		undo.Finish()

		self:GetOwner():AddCleanup( "props", pBox )
		self:GetOwner():AddCount( "props", pBox )

	end

	local phys = pBox:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:SetAngleVelocity( angVel );
		phys:SetVelocity( Vel );
	end

end

/*---------------------------------------------------------
   Name: OnInitialize
---------------------------------------------------------*/
function ENT:OnInitialize()
end

/*---------------------------------------------------------
   Name: StartTouch
---------------------------------------------------------*/
function ENT:StartTouch( entity )
end

/*---------------------------------------------------------
   Name: EndTouch
---------------------------------------------------------*/
function ENT:EndTouch( entity )
end

/*---------------------------------------------------------
   Name: Touch
---------------------------------------------------------*/
function ENT:Touch( entity )
end

/*---------------------------------------------------------
   Name: OnThink
---------------------------------------------------------*/
function ENT:OnThink()
end