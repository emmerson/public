
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
resource.AddFile( "resource/fonts/Cstrike.ttf" )

include( "shared.lua" )

SWEP.AutoSwitchTo		= true		// Auto switch to if we pick it up
SWEP.AutoSwitchFrom		= true		// Auto switch from if you pick up a better weapon


