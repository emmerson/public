
local g_AddCSLuaFile	= AddCSLuaFile
local g_AddFile			= resource.AddFile

/*---------------------------------------------------------
   GetConVarBoolean
---------------------------------------------------------*/
function GetConVarBoolean( command )

	return tobool( GetConVarNumber( command ) )

end

function GetConVarBool( command )

	return tobool( GetConVarNumber( command ) )

end
