
AddCSLuaFile( "client/cstrike_functions.lua" )
AddCSLuaFile( "client/cstrike_manifest.lua" )
AddCSLuaFile( "client/hud_functions.lua" )

AddCSLuaFile( "base_manifest.lua" )
AddCSLuaFile( "cstrike_ammotypes.lua" )

