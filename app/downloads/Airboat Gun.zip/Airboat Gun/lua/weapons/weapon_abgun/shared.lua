

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_abgun.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_abgun.vtf" )

	AddCSLuaFile( "shared.lua" )

	SWEP.HoldType			= "ar2"

	function SWEP:OnRemove()

		self:OnDrop()

	end

	function SWEP:OnDrop()

		if ( ValidEntity( self.Weapon ) ) then
			if (self.m_pGunFiringSound) then
				self:DestroySounds()
			end
		end

		self.Owner = nil

	end

end

if ( CLIENT ) then

	language.Add( "AirboatGun_ammo", "Airboat Gun Ammo" )
	language.Add( "HL2_Airboat_Gun", "AIRBOAT GUN" )

	SWEP.PrintName			= "#HL2_Airboat_Gun"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "2"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:CustomAmmoDisplay()

		if ( !ValidEntity( self.Owner ) ) then return 0 end

		self.AmmoDisplay = self.AmmoDisplay or {}

		self.AmmoDisplay.Draw = false

		self.AmmoDisplay.PrimaryClip 	= -1
		self.AmmoDisplay.PrimaryAmmo 	= self.Weapon:Clip1()
		self.AmmoDisplay.SecondaryAmmo 	= -1

		return self.AmmoDisplay

	end

	function SWEP:DrawWorldModel()

		local pPlayer = self.Owner;

		if ( !ValidEntity( pPlayer ) ) then
			self.Weapon:DrawModel();
			return;
		end

		if ( !self.m_hHands ) then
			self.m_hHands = pPlayer:LookupAttachment( "anim_attachment_rh" );
		end

		local hand = pPlayer:GetAttachment( self.m_hHands );

		local offset = hand.Ang:Right() * self.HoldPos.x + hand.Ang:Forward() * self.HoldPos.y + hand.Ang:Up() * self.HoldPos.z;

		hand.Ang:RotateAroundAxis( hand.Ang:Right(),	self.HoldAng.x );
		hand.Ang:RotateAroundAxis( hand.Ang:Forward(),	self.HoldAng.y );
		hand.Ang:RotateAroundAxis( hand.Ang:Up(),		self.HoldAng.z );

		self.Weapon:SetRenderOrigin( hand.Pos + offset )
		self.Weapon:SetRenderAngles( hand.Ang )

		self.Weapon:DrawModel()

	end

end


SWEP.Base						= "swep_ar2"
SWEP.Category					= "Half-Life 2"
SWEP.m_bFiresUnderwater			= true;
SWEP.m_flChargeRemainder		= 0.0;
SWEP.m_flDrainRemainder			= 0.0;
SWEP.m_flNextHeavyShotTime		= 0.0;
SWEP.m_bIsFiring				= false;
SWEP.m_flLastImpactEffectTime	= -1;

FIRING_DISCHARGE_RATE = (1.0 / 3.0)

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.WorldModel			= "models/Airboatgun.mdl"

SWEP.Primary.Sound			= Sound( "common/null.wav" )
SWEP.Primary.Damage			= 3
SWEP.Primary.Cone			= VECTOR_CONE_5DEGREES
SWEP.Primary.ClipSize		= GetConVarNumber( "sk_airboat_max_ammo" )
SWEP.Primary.Delay			= FIRING_DISCHARGE_RATE * 0.1
SWEP.Primary.DefaultClip	= GetConVarNumber( "sk_airboat_max_ammo" )
SWEP.Primary.Ammo			= "AirboatGun"
SWEP.Primary.Tracer			= 1

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "None"

SWEP.HoldPos 			= Vector( 0, 0, 0 )
SWEP.HoldAng			= Vector( 17, -5, 0 )

function SWEP:Precache()

	self.BaseClass:Precache();
	util.PrecacheSound( "Airboat.FireGunLoop" );
	util.PrecacheSound( "Airboat.FireGunRevDown");
	self:CreateSounds();

end

function SWEP:Initialize()

	if ( SERVER ) then
		self:SetWeaponHoldType( self.HoldType )
		self:SetNPCMinBurst( 2 )
		self:SetNPCMaxBurst( 5 )
		self:SetNPCFireRate( self.Primary.Delay )
	end

	self.m_nGunBarrelAttachment = self.Weapon:LookupAttachment( "muzzle" );

end

function SWEP:CreateSounds()

	if (!self.m_pGunFiringSound) then
		self.m_pGunFiringSound = CreateSound( self.Weapon, "Airboat.FireGunLoop" );
		self.m_flSoundVolume = 0;
		self.m_pGunFiringSound:PlayEx( self.m_flSoundVolume, 100 );
	end
end

function SWEP:DestroySounds()

	self.m_pGunFiringSound:Stop();
	self.m_pGunFiringSound = nil;
end


function SWEP:StartFiring()
	if ( !self.m_bIsFiring ) then
		local flVolume = self.m_flSoundVolume;
		self.m_pGunFiringSound:ChangeVolume( 1.0, 0.1 * (1.0 - flVolume) );
		self.m_flSoundVolume = 1.0;
		self.m_bIsFiring = true;
	end
end

function SWEP:StopFiring()
	if ( self.m_bIsFiring ) then
		local flVolume = self.m_flSoundVolume;
		self.m_pGunFiringSound:ChangeVolume( 0.0, 0.1 * flVolume );
		self.m_flSoundVolume = 0.0;
		self.Weapon:EmitSound( "Airboat.FireGunRevDown" );
		self.m_bIsFiring = false;
	end
end


function SWEP:AddViewKick()
end

function SWEP:Reload()
end

function SWEP:PreThink()

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( !self.m_bPrecached ) then
		self:CreateSounds();
		self.m_bPrecached = true;
	end

	if ( pPlayer:KeyDown( IN_ATTACK ) && self:CanPrimaryAttack() ) then
		self:StartFiring();
	else
		self:StopFiring();
	end

	if ( !pPlayer:KeyDown( IN_ATTACK ) ) then
		self:RechargeAmmo();
	end

end

function SWEP:GetTracerType()
	if ( CurTime() >= self.m_flNextHeavyShotTime ) then
		return "AirboatGunHeavyTracer";
	end

	return "AirboatGunTracer";
end


function SWEP:DoMuzzleFlash()

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( (self.m_nGunBarrelAttachment != 0) ) then
		if ( ( CLIENT && GetViewEntity() == pPlayer ) ||
			 ( SinglePlayer() && pPlayer:GetViewEntity() == pPlayer ) ) then
			local data = EffectData();
			data:SetEntity( pPlayer:GetViewModel() );
			data:SetAttachment( self.m_nGunBarrelAttachment );
			data:SetScale( 1.0 );
			util.Effect( "AirboatMuzzleFlash", data );
		else
			local data = EffectData();
			data:SetEntity( self.Weapon );
			data:SetAttachment( self.m_nGunBarrelAttachment );
			data:SetScale( 1.0 );
			util.Effect( "AirboatMuzzleFlash", data );
		end
	end

end

function SWEP:DoImpactEffect( tr )

	if ( self.m_flLastImpactEffectTime == CurTime() ) then
		return;
	end

	if ( tobool( math.random( 0, 5 ) ) ) then
		return;
	end

	self.m_flLastImpactEffectTime = CurTime();
	local data = EffectData();

	data:SetOrigin( tr.HitPos + ( tr.HitNormal * 1.0 ) );
	data:SetNormal( tr.HitNormal );

	util.Effect( "AR2Impact", data );
	util.Effect( "MetalSpark", data );

end


AIRBOAT_GUN_HEAVY_SHOT_INTERVAL	= 0.2

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	local pHL2MPPlayer = pPlayer;

	local info = {};
	info.Src = pHL2MPPlayer:GetShootPos();
	info.Dir = pPlayer:GetAimVector();
	info.Damage = damage;
	info.Tracer = self.Primary.Tracer;
	info.TracerName = self:GetTracerType();

	info.Owner = self.Owner
	info.Weapon = self.Weapon

	info.ShootCallback = self.ShootCallback;

	info.Callback = function( attacker, trace, dmginfo )
		self:DoImpactEffect( trace );
		return info:ShootCallback( attacker, trace, dmginfo );
	end

	if ( CurTime() >= self.m_flNextHeavyShotTime ) then
		info.NumShots = num_bullets;
		info.Spread = VECTOR_CONE_PRECALCULATED;
		info.Force = 1000.0;
	else
		info.NumShots = num_bullets * 2;
		info.Spread = VECTOR_CONE_5DEGREES;
	end

	pPlayer:gFireBullets( info );

	self:DoMuzzleFlash();

	if ( CurTime() >= self.m_flNextHeavyShotTime ) then
		self.m_flNextHeavyShotTime = CurTime() + AIRBOAT_GUN_HEAVY_SHOT_INTERVAL;
	end

end

function SWEP:ShootCallback( attacker, trace, dmginfo )

	dmginfo:SetDamageType( DMG_AIRBOAT )

end

function SWEP:TakePrimaryAmmo( flAmmoAmount )
	self.m_flDrainRemainder = self.m_flDrainRemainder + flAmmoAmount;
	local nAmmoToRemove = self.m_flDrainRemainder;
	self.m_flDrainRemainder = self.m_flDrainRemainder - nAmmoToRemove;
	self.Weapon:SetClip1( self.Weapon:Clip1() - flAmmoAmount );
	if ( self:Ammo1() < 0 ) then
		self.Weapon:SetClip1( 0 );
		self.m_flDrainRemainder = 0.0;
	end
end


function SWEP:RechargeAmmo()
	local nMaxAmmo = self.Primary.DefaultClip;
	if ( self.Weapon:Clip1() == nMaxAmmo ) then
		return;
	end

	local flRechargeRate = GetConVarNumber( "sk_airboat_recharge_rate" );
	local flChargeAmount = flRechargeRate * FrameTime();
	if ( self.m_flDrainRemainder != 0.0 ) then
		if ( self.m_flDrainRemainder >= flChargeAmount ) then
			self.m_flDrainRemainder = self.m_flDrainRemainder - flChargeAmount;
			return;
		else
			flChargeAmount = flChargeAmount - self.m_flDrainRemainder;
			self.m_flDrainRemainder = 0.0;
		end
	end

	self.m_flChargeRemainder = self.m_flChargeRemainder + flChargeAmount;
	local nAmmoToAdd = math.floor( self.m_flChargeRemainder );
	self.m_flChargeRemainder = self.m_flChargeRemainder - nAmmoToAdd;
	self.Weapon:SetClip1( self.Weapon:Clip1() + nAmmoToAdd );
	if ( self:Ammo1() > nMaxAmmo ) then
		self.Weapon:SetClip1( nMaxAmmo );
		self.m_flChargeRemainder = 0.0;
	end
end

function SWEP:CanPrimaryAttack()

	if ( self.Weapon:Clip1() <= 0 ) then
		return false;
	end

	return true;

end

function SWEP:CanSecondaryAttack()

	return false

end
