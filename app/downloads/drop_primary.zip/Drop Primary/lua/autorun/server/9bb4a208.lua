
local meta = FindMetaTable( "Player" )
if (!meta) then return end

if ( !meta.DropPrimary ) then

	function meta:DropPrimary()

		if ( self:GetActiveWeapon() == NULL ) then return end

		self:DropWeapon( self:GetActiveWeapon() )

	end

end

concommand.Add( "drop", meta.DropPrimary )
