

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_thruster.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_thruster.vtf" )

	AddCSLuaFile( "shared.lua" )

	SWEP.HoldType			= "rpg"

	function SWEP:OnRemove()

		self:OnDrop()

	end

	function SWEP:OnDrop()

		if ( ValidEntity( self.Weapon ) ) then
			if (self.Sound) then
				self.Sound:Stop()
			end
		end

	end

end

if ( CLIENT ) then

	language.Add( "HL2_Thruster", "THRUSTER" )

	SWEP.PrintName			= "#HL2_Thruster"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.DrawAmmo			= true
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "9"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:DrawWorldModel()

		local pPlayer = self.Owner;

		if ( !ValidEntity( pPlayer ) ) then
			self.Weapon:DrawModel();
			return;
		end

		if ( !self.m_hHands ) then
			self.m_hHands = pPlayer:LookupAttachment( "anim_attachment_rh" );
		end

		local hand = pPlayer:GetAttachment( self.m_hHands );

		local offset = hand.Ang:Right() * self.HoldPos.x + hand.Ang:Forward() * self.HoldPos.y + hand.Ang:Up() * self.HoldPos.z;

		hand.Ang:RotateAroundAxis( hand.Ang:Right(),	self.HoldAng.x );
		hand.Ang:RotateAroundAxis( hand.Ang:Forward(),	self.HoldAng.y );
		hand.Ang:RotateAroundAxis( hand.Ang:Up(),		self.HoldAng.z );

		self.Weapon:SetRenderOrigin( hand.Pos + offset )
		self.Weapon:SetRenderAngles( hand.Ang )

		self.Weapon:DrawModel()

	end

end


SWEP.Base				= "swep_crowbar"
SWEP.Category			= SWEP.Author
SWEP.m_iAmmo1			= 100
SWEP.m_iNumShots		= 5

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.ViewModel			= ""
SWEP.WorldModel			= "models/props_c17/canister01a.mdl"

SWEP.Primary.Sound			= Sound( "PhysicsCannister.ThrusterLoop" )
SWEP.Primary.Range			= 100
SWEP.Primary.Damage			= 100
SWEP.Primary.Force			= 0.4
SWEP.Primary.Delay			= 0.0
SWEP.Primary.Automatic		= true

SWEP.HoldPos 			= Vector( 2, 0, 6 )
SWEP.HoldAng			= Vector( -73, -5, 60 )

PrecacheParticleSystem( "Advisor_Pod_Steam_01" )

function SWEP:PrimaryAttack()

	local pPlayer		= self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( !self:CanPrimaryAttack() ) then return end

	local vecSrc		= pPlayer:GetShootPos();
	local vecDirection	= pPlayer:GetAimVector();

	local trace			= {}
		trace.start		= vecSrc
		trace.endpos	= vecSrc + ( vecDirection * self:GetRange() )
		trace.filter	= pPlayer

	local traceHit		= util.TraceLine( trace )

	self.m_iAmmo1 = math.Clamp( self.m_iAmmo1 - 1, 0, 100 )

	if ( traceHit.Hit ) then

		if ( !self.Sound ) then
			self.Sound = CreateSound( self.Weapon, self.Primary.Sound )
		end

		self.m_bOn = true

		self.Weapon:SendWeaponAnim( ACT_VM_HITCENTER );
		pPlayer:LagCompensation( true );
		pPlayer:SetAnimation( PLAYER_ATTACK1 );

		self.Weapon:SetNextPrimaryFire( CurTime() + self:GetFireRate() );
		self.Weapon:SetNextSecondaryFire( CurTime() + self.Weapon:SequenceDuration() );

		self:Hit( traceHit, pPlayer );

		return

	end

	if ( !self.Sound ) then
		self.Sound = CreateSound( self.Weapon, self.Primary.Sound )
	end

	self.m_bOn = true

	self.Weapon:SendWeaponAnim( ACT_VM_MISSCENTER );
	pPlayer:LagCompensation( false );
	pPlayer:SetAnimation( PLAYER_ATTACK1 );

	self.Weapon:SetNextPrimaryFire( CurTime() + self:GetFireRate() );
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Weapon:SequenceDuration() );

	self:Swing( traceHit, pPlayer );

	return

end

local NumShots = SWEP.m_iNumShots

function SWEP:Hit( traceHit, pOwner )

	local vecSrc = pOwner:GetShootPos();

	local	vForward, vRight, vUp;

	vForward = pOwner:GetForward();
	vRight = pOwner:GetRight();
	vUp = pOwner:GetUp();

	local	muzzlePoint = pOwner:GetShootPos() + vForward * 52.0 + vRight * 6.0 + vUp * -3.0;

	if ( SERVER ) then
		pOwner:TraceHullAttack( vecSrc, traceHit.HitPos, Vector( -16, -16, -16 ), Vector( 36, 36, 36 ), self:GetDamageForActivity(), self.Primary.DamageType, self.Primary.Force );
		pOwner:SetVelocity( pOwner:GetAimVector() * ( -self.Primary.Force / 5 ) * ( self.Primary.Damage * 2 ) );

		if ( self.m_iNumShots >= NumShots ) then

			self.m_iNumShots = math.Clamp( self.m_iNumShots - 1, 0, NumShots )

		return end

		self.m_iNumShots = NumShots

		local PrimaryDelay = FrameTime() * 5

		local pParticle = ents.Create( "info_particle_system" )
		pParticle:SetKeyValue( "effect_name", "Advisor_Pod_Steam_01" )
		pParticle:SetKeyValue( "start_active", tostring( 1 ) )
		pParticle:SetAngles( pOwner:GetAimVector():Angle() )
		pParticle:SetPos( muzzlePoint )
		pParticle:Spawn()
		pParticle:Activate()
		pParticle:Fire( "Kill", nil, PrimaryDelay )
	end

end

function SWEP:Swing( traceHit, pOwner )

	local	vForward, vRight, vUp;

	vForward = pOwner:GetForward();
	vRight = pOwner:GetRight();
	vUp = pOwner:GetUp();

	local	muzzlePoint = pOwner:GetShootPos() + vForward * 52.0 + vRight * 6.0 + vUp * -3.0;

	if ( SERVER ) then
		pOwner:SetVelocity( pOwner:GetAimVector() * ( -self.Primary.Force / 5 ) * self.Primary.Damage );

		if ( self.m_iNumShots >= NumShots ) then

			self.m_iNumShots = math.Clamp( self.m_iNumShots - 1, 0, NumShots )

		return end

		self.m_iNumShots = NumShots

		local PrimaryDelay = FrameTime() * 5

		local pParticle = ents.Create( "info_particle_system" )
		pParticle:SetKeyValue( "effect_name", "Advisor_Pod_Steam_01" )
		pParticle:SetKeyValue( "start_active", tostring( 1 ) )
		pParticle:SetAngles( pOwner:GetAimVector():Angle() )
		pParticle:SetPos( muzzlePoint )
		pParticle:Spawn()
		pParticle:Activate()
		pParticle:Fire( "Kill", nil, PrimaryDelay )
	end

end

function SWEP:Think()

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( !self.m_bSwitch && self.m_bOn ) then
		self.Sound:PlayEx( 0.5, 100 )
		self.m_bSwitch = true
	end

	if ( !pPlayer:KeyDown( IN_ATTACK ) ) then
		self.m_iAmmo1 = math.Clamp( self.m_iAmmo1 + 1, 0, 100 )
		self.m_iNumShots = 0

		if (self.Sound) then
			self.Sound:Stop()
		end
		self.m_bSwitch = false
		self.m_bOn = false
	end

end

function SWEP:CanPrimaryAttack()

	if ( self.m_iAmmo1 <= 0 ) then
		if (self.Sound) then
			self.Sound:Stop()
		end
		return false;
	end

	return true;

end
