Steam Web Lua API
=================

_This project is no longer maintained._

The Steam Web Lua API is a small library originally designed to provide the web interfaces utilized in Steam Mobile. These interfaces were reverse engineered before Steam Mobile had been officially released, during the application's beta. Inside you will find wrappers to the individual interface methods and some explanation of their usage. The library is not fully documented, however there is more than enough information provided to replicate a Steam chat client.

For more information, please contact Andrew McWatters at me@andrewmcwatters.com or see the VDC.

Thanks,
The Steam Web Lua SDK Team
