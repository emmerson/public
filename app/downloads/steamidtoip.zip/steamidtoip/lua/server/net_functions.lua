
local meta = FindMetaTable( "Player" )
if (!meta) then return end

// In this file we're adding functions to the player meta table.
// This means you'll be able to call functions here straight from the player object
// You can even override already existing functions.

meta.g_IPAddress		= meta.IPAddress
meta.g_SteamID			= meta.SteamID
meta.g_UniqueID			= meta.UniqueID

local net_validation	= CreateConVar( "net_validation", 0, { FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED } )
local net_generateid	= CreateConVar( "net_generateid", 1, { FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED } )

function meta:SteamID()

	if ( net_validation:GetBool() ) then return self:g_SteamID() end

	if ( net_generateid:GetBool() ) then

		if ( self:g_IPAddress() == "loopback" ) then

			return "STEAM_ID_LOOPBACK"

		end

		local SteamID	= string.Replace( self:g_IPAddress(), ":", "" )
		SteamID			= string.Replace( SteamID, ".", "" )
		return "STEAM_0:1:" .. SteamID

	end

	return self:g_IPAddress()

end

function meta:UniqueID()

	if ( net_validation:GetBool() ) then return self:g_UniqueID() end

	if ( net_generateid:GetBool() ) then

		if ( self:g_IPAddress() == "loopback" ) then

			return "127001"

		end

		local UniqueID = string.Replace( self:g_IPAddress(), ":", "" )
		return UniqueID

	end

	if ( !SinglePlayer() ) then

		return self:g_IPAddress()

	else

		return self:UserID()

	end

end

