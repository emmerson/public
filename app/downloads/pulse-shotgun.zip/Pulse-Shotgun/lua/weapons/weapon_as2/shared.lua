

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_as2.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_as2.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	language.Add( "HL2_Pulse_Shotgun", "PULSE-SHOTGUN" )

	SWEP.PrintName			= "#HL2_Pulse_Shotgun"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "0"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_shotgun"
SWEP.Category			= SWEP.Author

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.Damage			= 11
SWEP.Primary.TracerName		= "AR2Tracer"

SWEP.Secondary.Damage		= 11

function SWEP:ShootCallback( attacker, trace, dmginfo )

	local data = EffectData();

	data:SetOrigin( trace.HitPos + ( trace.HitNormal * 1.0 ) );
	data:SetNormal( trace.HitNormal );

	util.Effect( "AR2Impact", data );

end
