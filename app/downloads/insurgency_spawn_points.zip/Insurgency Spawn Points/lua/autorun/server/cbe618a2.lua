
local function PlayerSelectInsSpawn( pl )

	if ( !GAMEMODE.IsSandboxDerived ) then
		hook.Remove( "PlayerSelectSpawn", "PlayerSelectInsSpawn" )
		return;
	end

	// Save information about all of the spawn points
	// in a team based game you'd split up the spawns
	if ( IsTableOfEntitiesValid( GAMEMODE.SpawnPoints ) ) then

		hook.Remove( "PlayerSelectSpawn", "PlayerSelectInsSpawn" )

		// Ins Maps
		GAMEMODE.SpawnPoints = table.Add( GAMEMODE.SpawnPoints, ents.FindByClass( "ins_spawnpoint" ) )

	end

end

hook.Add( "PlayerSelectSpawn", "PlayerSelectInsSpawn", PlayerSelectInsSpawn )





