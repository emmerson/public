
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

local Collide_Sounds	= {

	Sound( "physics/flesh/flesh_squishy_impact_hard1.wav" ),
	Sound( "physics/flesh/flesh_squishy_impact_hard2.wav" ),
	Sound( "physics/flesh/flesh_squishy_impact_hard3.wav" ),
	Sound( "physics/flesh/flesh_squishy_impact_hard4.wav" )

}

local Die_Sounds		= {

	Sound( "vo/npc/male01/ow01.wav" ),
	Sound( "vo/npc/male01/ow02.wav" ),
	Sound( "vo/npc/male01/pain01.wav" ),
	Sound( "vo/npc/male01/pain02.wav" ),
	Sound( "vo/npc/male01/pain03.wav" ),
	Sound( "vo/npc/male01/pain04.wav" ),
	Sound( "vo/npc/male01/pain05.wav" ),
	Sound( "vo/npc/male01/pain06.wav" ),
	Sound( "vo/npc/male01/pain07.wav" ),
	Sound( "vo/npc/male01/pain08.wav" ),
	Sound( "vo/npc/male01/pain09.wav" )

}

local Gib_Models		= {

	Model( "models/props/cs_italy/orangegib1.mdl" ),
	Model( "models/props/cs_italy/orangegib2.mdl" ),

}

/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	// Use the orange model's browken wittle hawrt (because it's still partially intact)
	self.Entity:SetModel( table.Random( Gib_Models ) )

	// Use the model's physics
	self.Entity:PhysicsInit( SOLID_VPHYSICS, "flesh" )

	// Wake the physics object up. It's time to have fun!
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:SetMaterial( "watermelon" )
		phys:Wake()
	end

	self.m_flInitializeTime = CurTime() + 3.0;

end


/*---------------------------------------------------------
   Name: PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide( data, physobj )

	// Play sound on bounce
	if (data.DeltaTime > 0.2 ) then
		self.Entity:EmitSound( table.Random( Collide_Sounds ), data.Speed )
	end

end

function ENT:Think()

	if ( self.m_flInitializeTime < CurTime() ) then

		local Data		= {}
		Data.Model		= Model( "models/props/cs_italy/orange.mdl" )
		Data.Pos		= self.Entity:GetPos() + RandomVector( self.Entity:OBBMins(), self.Entity:OBBMaxs() )
		Data.Angle		= self.Entity:GetAngles()

		local player	= self:GetPlayer()
		local vel		= self.Entity:GetVelocity()

		local entity = ents.Create( "sent_motivational_orange" )
		duplicator.DoGeneric( entity, Data )
		entity:Spawn()

        if ( ValidEntity( entity ) ) then

			undo.ReplaceEntity(	self.Entity, entity )
			cleanup.ReplaceEntity( self.Entity, entity )

			player:AddCleanup( "sents", entity )
			entity:SetVar( "Player", player )

        end

		self.Entity:Remove()

		local phys = entity:GetPhysicsObject()
		if (phys:IsValid()) then
			phys:SetVelocity( vel )
		end

		return

	end

	self.Entity:NextThink( CurTime() );

end

/*---------------------------------------------------------
   Name: OnTakeDamage
---------------------------------------------------------*/
function ENT:OnTakeDamage( dmginfo )

	// Remove when shot/getting blown
	self.Entity:Remove()

end


/*---------------------------------------------------------
   Name: Use
---------------------------------------------------------*/
function ENT:Use( activator, caller )

	// This makes the interaction a semi-automatic thing rather than a continuous thing
	if ( !activator:KeyPressed( IN_USE ) ) then return end

	self.Entity:EmitSound( table.Random( Die_Sounds ), 90, 100 + math.Rand( 50, 100 ) )

	self.Entity:Remove()

	if ( activator:IsPlayer() ) then

		// Give the collecting player some free health
		local health = activator:Health()
		local int = 3
		if ( health >= 100 ) then
			return;
		elseif ( health + int > 100 ) then
			int = 100 - health
		end
		activator:AddHealth( int )

	end

end



