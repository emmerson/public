
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

local Collide_Sounds = {

	Sound( "physics/flesh/flesh_squishy_impact_hard1.wav" ),
	Sound( "physics/flesh/flesh_squishy_impact_hard2.wav" ),
	Sound( "physics/flesh/flesh_squishy_impact_hard3.wav" ),
	Sound( "physics/flesh/flesh_squishy_impact_hard4.wav" )

}

local Die_Sounds	= {

	Sound( "vo/npc/male01/ow01.wav" ),
	Sound( "vo/npc/male01/ow02.wav" ),
	Sound( "vo/npc/male01/pain01.wav" ),
	Sound( "vo/npc/male01/pain02.wav" ),
	Sound( "vo/npc/male01/pain03.wav" ),
	Sound( "vo/npc/male01/pain04.wav" ),
	Sound( "vo/npc/male01/pain05.wav" ),
	Sound( "vo/npc/male01/pain06.wav" ),
	Sound( "vo/npc/male01/pain07.wav" ),
	Sound( "vo/npc/male01/pain08.wav" ),
	Sound( "vo/npc/male01/pain09.wav" )

}

local Gib_Models = {

	Model( "models/props/cs_italy/orangegib1.mdl" ),
	Model( "models/props/cs_italy/orangegib2.mdl" )

}

local Orange_Sounds = {

	Sound( "vo/npc/male01/leadon01.wav" ),
	Sound( "vo/npc/male01/leadon02.wav" ),
	Sound( "vo/npc/male01/leadtheway01.wav" ),
	Sound( "vo/npc/male01/leadtheway02.wav" ),
	Sound( "vo/npc/male01/letsgo01.wav" ),
	Sound( "vo/npc/male01/letsgo02.wav" ),
	Sound( "vo/npc/male01/yeah02.wav" )

}

// This is the spawn function. It's called when a client calls the entity to be spawned.
// If you want to make your SENT spawnable you need one of these functions to properly create the entity
//
// ply is the name of the player that is spawning it
// tr is the trace from the player's eyes
//
function ENT:SpawnFunction( ply, tr )

	if ( !tr.Hit ) then return end

	local SpawnPos = tr.HitPos + tr.HitNormal * 16

	local ent = ents.Create( "sent_motivational_orange" )
		ent:SetPos( SpawnPos )
	ent:Spawn()
	ent:Activate()

	return ent

end


/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	// Use the orange model just for the love of God (because it's about as sweet)
	self.Entity:SetModel( "models/props/cs_italy/orange.mdl" )

	// Use the model's physics
	self.Entity:PhysicsInit( SOLID_VPHYSICS, "flesh" )

	// Wake the physics object up. It's time to have fun!
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:SetMaterial( "watermelon" )
		phys:Wake()
	end

end


/*---------------------------------------------------------
   Name: PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide( data, physobj )

	// Play sound on bounce
	if (data.Speed > 160 && data.DeltaTime > 0.4 ) then
		self.Entity:EmitSound( table.Random( Collide_Sounds ), data.Speed )
	end

end

function ENT:Think()

	local Pos1				= self.Entity:GetPos()
	local Players			= player.FindInSphere( Pos1, math.Rand( 100, 750.0 ) )

	self.TargetPlayer		= nil

	if ( #Players >= 1 ) then
		self.TargetPlayer	= Players[ 1 ]
	end

	if ( !self.TargetPlayer ) then
		self.Entity:NextThink( CurTime() + 1.0 );
		return;
	end

	if ( math.random( 1, 100 ) == 50 ) then
		self.Entity:EmitSound( table.Random( Orange_Sounds ), 80, 100 + math.Rand( 50, 100 ) )
	end

	local center	= self.Entity:OBBCenter()
	local maxs		= self.Entity:OBBMaxs()
	local height	= maxs.z * 2 - center.z
	local Pos2		= self.TargetPlayer:GetPos()
	local rad		= self.Entity:BoundingRadius()
	local trace		= util.QuickTrace( Pos1, Pos1 - Vector( 0, 0, height ), self.Entity )

	if ( !(trace.Hit || trace.HitWorld) ) then
		self.Entity:NextThink( CurTime() + 0.1 );
		return;
	end

	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		local force = Pos2 - Pos1
		phys:ApplyForceOffset( force + ( Vector( 0, 0, 187.5 ) * math.random() ), self.Entity:NearestPoint( Pos2 ) )
	end

	self.Entity:NextThink( CurTime() + 1.0 );

end

/*---------------------------------------------------------
   Name: OnTakeDamage
---------------------------------------------------------*/
function ENT:OnTakeDamage( dmginfo )

	self.Entity:EmitSound( table.Random( Die_Sounds ), 90, ( 100 + math.Rand( 50, 100 ) ) )

	if ( !dmginfo:IsBulletDamage() ) then
		self.Entity:TakePhysicsDamage( dmginfo );
		return;
	end

	local Data			= {}
	Data.Model			= table.Random( Gib_Models )
	Data.Pos			= self.Entity:LocalToWorld( self.Entity:OBBCenter() )
	Data.Angle			= self.Entity:GetAngles()

	local player		= self:GetPlayer()
	local PrintName		= self.PrintName
	local EntityName	= self.Entity:GetClass()

	// React physically when shot/getting blown
	self.Entity:Remove()
	for i = 1, math.random( 2, 3 ) do

		local entity = ents.Create( "sent_motivational_orange_gib" )
		duplicator.DoGeneric( entity, Data )
		entity:Spawn()

        if ( ValidEntity( entity ) ) then

			gamemode.Call( "PlayerSpawnedSENT", player, entity )

			undo.Create("SENT")
				undo.SetPlayer(player)
				undo.AddEntity(entity)
				if ( PrintName ) then
					undo.SetCustomUndoText( "Undone "..PrintName )
				end
			undo.Finish( "Scripted Entity ("..tostring( EntityName )..")" )

			player:AddCleanup( "sents", entity )
			entity:SetVar( "Player", player )

        end

		local phys = entity:GetPhysicsObject()
		if (phys:IsValid()) then
			local force = dmginfo:GetDamageForce()
			force = force * phys:GetMass()
			phys:AddVelocity( RandomVector( -force, force ) * dmginfo:GetDamage() )
		end

	end

end


/*---------------------------------------------------------
   Name: Use
---------------------------------------------------------*/
function ENT:Use( activator, caller )

	// This makes the interaction a semi-automatic thing rather than a continuous thing
	if ( !activator:KeyPressed( IN_USE ) ) then return end

	self.Entity:EmitSound( table.Random( Die_Sounds ), 90, 100 + math.Rand( 50, 100 ) )

	self.Entity:Remove()

	if ( activator:IsPlayer() ) then

		// Give the collecting player some free health
		local health = activator:Health()
		local int = 5
		if ( health >= 100 ) then
			return;
		elseif ( health + int > 100 ) then
			int = 100 - health
		end
		activator:AddHealth( int )

	end

end



