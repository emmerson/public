

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Motivational Orange"
ENT.Author			= "Andrew McWatters"
ENT.Information		= "A pumped up fruit"
ENT.Category		= "Facepunch"

ENT.Spawnable			= false
ENT.AdminSpawnable		= true
