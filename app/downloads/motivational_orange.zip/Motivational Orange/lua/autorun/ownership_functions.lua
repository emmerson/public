
local meta = FindMetaTable( "Player" )
if (!meta) then return end

// In this file we're adding functions to the player meta table.
// This means you'll be able to call functions here straight from the player object
// You can even override already existing functions.

meta.g_AddCleanup				= meta.AddCleanup
meta.g_AddCount					= meta.AddCount
cleanup.g_Add					= cleanup.Add

local function PlayerSpawnEntity( ply, ent )

	if ( !ply ) then return end
	if ( !ply:IsValid() ) then return end
	if ( !ent ) then return end
	if ( !ent:IsValid() ) then return end

	ent:SetPlayer( ply )

end

hook.Add( "PlayerSpawnedSENT",		"PlayerSpawnEntity", PlayerSpawnEntity )
hook.Add( "PlayerSpawnedSWEP",		"PlayerSpawnEntity", PlayerSpawnEntity )
hook.Add( "PlayerSpawnedNPC",		"PlayerSpawnEntity", PlayerSpawnEntity )
hook.Add( "PlayerSpawnedVehicle",	"PlayerSpawnEntity", PlayerSpawnEntity )

function cleanup.Add( ply, type, ent )

	cleanup.g_Add( ply, type, ent )

	PlayerSpawnEntity( ply, ent )

end

function meta:AddCleanup( type, ent )

	self:g_AddCleanup( type, ent )

	PlayerSpawnEntity( self, ent )

end

function meta:AddCount( type, ent )

	self:g_AddCount( type, ent )

	PlayerSpawnEntity( self, ent )

end

local meta = FindMetaTable( "Entity" )
if (!meta) then return end

function meta:GetPlayer()

	return self:GetVar( "Founder", NULL )

end

function meta:GetPlayerIndex()

	return self:GetVar( "FounderIndex", 0 )

end

function meta:GetPlayerName()

	local ply = self:GetPlayer()
	if ( ply && ply:IsValid() ) then
		return ply:Nick()
	end

	return self:GetNetworkedString( "FounderName" )

end

function meta:SetPlayer( ply )

	self:SetVar( "Founder", ply )
	self:SetVar( "FounderIndex", ply:UniqueID() )

	self:SetNetworkedString( "FounderName", ply:Nick() )

end

