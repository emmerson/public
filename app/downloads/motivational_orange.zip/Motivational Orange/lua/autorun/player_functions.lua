
local player = player
if (!player) then return end

// In this file we're adding functions to the player table.
// This means you'll be able to call functions here straight from the player library
// You can even override already existing functions.

function player.FindInSphere( center, radius )

	local t = {}

	for k, v in pairs( ents.FindInSphere( center, radius ) ) do

		if ( v:IsPlayer() ) then

			table.insert( t, v )

		end

	end

	return t

end

