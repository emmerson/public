-- groupchatlog.lua
-- a C++ to Lua transliteration of
-- http://www.facepunch.com/threads/824685?p=19688064&viewfull=1#post19688064

require( "opensteamworks" )

local clientEngine = IClientEngine;

local pipe = clientEngine.CreateSteamPipe();
local user = clientEngine.ConnectToGlobalUser( pipe );

local clientFriends = clientEngine.GetIClientFriends( user, pipe );

local b;
local callbackMsg;

while ( true ) do
	b, callbackMsg = Steam_BGetCallback( pipe )
	if ( b ) then
		if ( callbackMsg.m_iCallback == 810 ) then
			local groupChat = callbackMsg.m_pubParam;
			
			local get, data, type, sender = clientFriends:GetChatRoomEntry( groupChat.m_ulSteamIDChat, groupChat.m_iChatID );
			
			print( "Sender: " .. sender:Render() .. ", Type: " .. type .. ", Get: " .. get );
			print( "   Msg: " .. data );

			if ( data == "/spam" ) then
				clientFriends:SendChatMsg( groupChat.m_ulSteamIDChat, 1, "test.");
			end

		end

		Steam_FreeLastCallback( pipe );
	end
end
