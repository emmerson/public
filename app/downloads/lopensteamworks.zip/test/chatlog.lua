-- chatlog.lua
-- a C++ to Lua transliteration of
-- http://www.facepunch.com/threads/824685?p=17668850&viewfull=1#post17668850

local bit = bit
if ( bit == nil ) then bit = require( "bit" ) end
local band = bit.band

require( "opensteamworks" )

local hSteamPipe = ISteamClient012.CreateSteamPipe();
local hSteamUser = ISteamClient012.ConnectToGlobalUser(hSteamPipe);

local steamFriends = ISteamClient012.GetISteamFriends( hSteamUser, hSteamPipe, "SteamFriends011" );

local b;
local CallbackMsg;

while (true) do
	b, CallbackMsg = Steam_BGetCallback(hSteamPipe)
	if (b) then
		if (CallbackMsg.m_iCallback == 805) then
			local chatMsg = CallbackMsg.m_pubParam;

			local friendName = steamFriends:GetFriendPersonaName(chatMsg.m_ulSenderID);
			local _, pvData, msgType;
			if ( chatMsg.m_ulSenderID == chatMsg.m_ulFriendID ) then
				_, pvData, msgType = steamFriends:GetFriendMessage(chatMsg.m_ulSenderID, chatMsg.m_iChatID);
			else
				_, pvData, msgType = steamFriends:GetFriendMessage(chatMsg.m_ulFriendID, chatMsg.m_iChatID);
			end

			if (band(msgType, 2) ~= 0) then
				print( "* " .. friendName .. " is typing a message..." );
			else
				print( "* Message from " .. friendName .. ": " .. pvData );
			end

		end

		Steam_FreeLastCallback( hSteamPipe );
	end

end
