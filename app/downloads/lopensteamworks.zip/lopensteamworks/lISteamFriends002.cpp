/*
* listeamfriends002.cpp
* ISteamFriends002 bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Jan 2012 11:20:00
* This code is hereby placed in the public domain.
*/

#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lauxlibex.h"
}
#include "lCSteamID.h"
#include "lSteamTypes.h"

/*
** access functions (stack -> C)
*/


LUA_API ISteamFriends002 *lua_tosteamfriends002 (lua_State *L, int idx) {
  ISteamFriends002 *pSteamFriends = (ISteamFriends002 *)lua_touserdata(L, idx);
  return pSteamFriends;
}



/*
** push functions (C -> stack)
*/


LUA_API void lua_pushsteamfriends002 (lua_State *L, ISteamFriends002 *pSteamFriends) {
  lua_pushlightuserdata(L, pSteamFriends);
  luaL_getmetatable(L, "ISteamFriends002");
  lua_setmetatable(L, -2);
}


LUALIB_API ISteamFriends002 *luaL_checksteamfriends002 (lua_State *L, int narg) {
  ISteamFriends002 *d = (ISteamFriends002 *)luaL_checkudata(L, narg, "ISteamFriends002");
  return d;
}


static int ISteamFriends002_AcknowledgeInviteToClan(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends002(L, 1)->AcknowledgeInviteToClan(*luaL_checksteamid(L, 2), luaL_checkboolean(L, 3)));
  return 1;
}

static int ISteamFriends002_AddFriend(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends002(L, 1)->AddFriend(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends002_ClearChatHistory(lua_State *L) {
  luaL_checksteamfriends002(L, 1)->ClearChatHistory(*luaL_checksteamid(L, 2));
  return 0;
}

#ifdef STEAMWORKS_OBSOLETE_FUNCTIONS
static int ISteamFriends002_GetChatIDOfChatHistoryStart(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends002(L, 1)->GetChatIDOfChatHistoryStart(*luaL_checksteamid(L, 2)));
  return 1;
}
#endif

static int ISteamFriends002_GetClanByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends002(L, 1)->GetClanByIndex(luaL_checkinteger(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends002_GetClanCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends002(L, 1)->GetClanCount());
  return 1;
}

static int ISteamFriends002_GetClanName(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends002(L, 1)->GetClanName(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends002_GetFriendByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends002(L, 1)->GetFriendByIndex(luaL_checkinteger(L, 2), (EFriendFlags)luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends002_GetFriendCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends002(L, 1)->GetFriendCount((EFriendFlags)luaL_checkinteger(L, 2)));
  return 1;
}

static int ISteamFriends002_GetFriendCountFromSource(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends002(L, 1)->GetFriendCountFromSource(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends002_GetFriendFromSourceByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends002(L, 1)->GetFriendFromSourceByIndex(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends002_GetFriendPersonaName(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends002(L, 1)->GetFriendPersonaName(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends002_GetFriendPersonaNameHistory(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends002(L, 1)->GetFriendPersonaNameHistory(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3)));
  return 1;
}

static int ISteamFriends002_GetFriendPersonaState(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends002(L, 1)->GetFriendPersonaState(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends002_GetFriendRegValue(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends002(L, 1)->GetFriendRegValue(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int ISteamFriends002_GetFriendRelationship(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends002(L, 1)->GetFriendRelationship(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends002_GetPersonaName(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends002(L, 1)->GetPersonaName());
  return 1;
}

static int ISteamFriends002_GetPersonaState(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends002(L, 1)->GetPersonaState());
  return 1;
}

static int ISteamFriends002_HasFriend(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends002(L, 1)->HasFriend(*luaL_checksteamid(L, 2), (EFriendFlags)luaL_checkinteger(L, 3)));
  return 1;
}

static int ISteamFriends002_InviteFriendByEmail(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends002(L, 1)->InviteFriendByEmail(luaL_checkstring(L, 2)));
  return 1;
}

static int ISteamFriends002_InviteFriendToClan(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends002(L, 1)->InviteFriendToClan(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3)));
  return 1;
}

static int ISteamFriends002_RemoveFriend(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends002(L, 1)->RemoveFriend(*luaL_checksteamid(L, 2)));
  return 1;
}

#ifdef STEAMWORKS_OBSOLETE_FUNCTIONS
static int ISteamFriends002_SetChatHistoryStart(lua_State *L) {
  luaL_checksteamfriends002(L, 1)->SetChatHistoryStart(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  return 0;
}
#endif

static int ISteamFriends002_SetFriendRegValue(lua_State *L) {
  luaL_checksteamfriends002(L, 1)->SetFriendRegValue(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3), luaL_checkstring(L, 4));
  return 0;
}

static int ISteamFriends002_SetPersonaName(lua_State *L) {
  luaL_checksteamfriends002(L, 1)->SetPersonaName(luaL_checkstring(L, 2));
  return 0;
}

static int ISteamFriends002_SetPersonaState(lua_State *L) {
  luaL_checksteamfriends002(L, 1)->SetPersonaState((EPersonaState)luaL_checkinteger(L, 2));
  return 0;
}

static int ISteamFriends002___tostring (lua_State *L) {
  lua_pushfstring(L, "ISteamFriends002: %p", luaL_checksteamfriends002(L, 1));
  return 1;
}

static const luaL_Reg ISteamFriends002meta[] = {
  {"AcknowledgeInviteToClan", ISteamFriends002_AcknowledgeInviteToClan},
  {"AddFriend", ISteamFriends002_AddFriend},
  {"ClearChatHistory", ISteamFriends002_ClearChatHistory},
#ifdef STEAMWORKS_OBSOLETE_FUNCTIONS
  {"GetChatIDOfChatHistoryStart", ISteamFriends002_GetChatIDOfChatHistoryStart},
#endif
  {"GetClanByIndex", ISteamFriends002_GetClanByIndex},
  {"GetClanCount", ISteamFriends002_GetClanCount},
  {"GetClanName", ISteamFriends002_GetClanName},
  {"GetFriendByIndex", ISteamFriends002_GetFriendByIndex},
  {"GetFriendCount", ISteamFriends002_GetFriendCount},
  {"GetFriendCountFromSource", ISteamFriends002_GetFriendCountFromSource},
  {"GetFriendFromSourceByIndex", ISteamFriends002_GetFriendFromSourceByIndex},
  {"GetFriendPersonaName", ISteamFriends002_GetFriendPersonaName},
  {"GetFriendPersonaNameHistory", ISteamFriends002_GetFriendPersonaNameHistory},
  {"GetFriendPersonaState", ISteamFriends002_GetFriendPersonaState},
  {"GetFriendRegValue", ISteamFriends002_GetFriendRegValue},
  {"GetFriendRelationship", ISteamFriends002_GetFriendRelationship},
  {"GetPersonaName", ISteamFriends002_GetPersonaName},
  {"GetPersonaState", ISteamFriends002_GetPersonaState},
  {"HasFriend", ISteamFriends002_HasFriend},
  {"InviteFriendByEmail", ISteamFriends002_InviteFriendByEmail},
  {"InviteFriendToClan", ISteamFriends002_InviteFriendToClan},
  {"RemoveFriend", ISteamFriends002_RemoveFriend},
#ifdef STEAMWORKS_OBSOLETE_FUNCTIONS
  {"SetChatHistoryStart", ISteamFriends002_SetChatHistoryStart},
#endif
  {"SetFriendRegValue", ISteamFriends002_SetFriendRegValue},
  {"SetPersonaName", ISteamFriends002_SetPersonaName},
  {"SetPersonaState", ISteamFriends002_SetPersonaState},
  {"__tostring", ISteamFriends002___tostring},
  {NULL, NULL}
};


/*
** Open ISteamFriends002 object
*/
LUALIB_API int luaopen_ISteamFriends002(lua_State *L) {
  luaL_newmetatable(L, "ISteamFriends002");
  luaL_register(L, NULL, ISteamFriends002meta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "steamfriends002");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "steamfriends002" */
  lua_pop(L, 1);
  return 1;
}

