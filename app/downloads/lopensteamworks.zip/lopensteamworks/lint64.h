/*
* lint64.h
* Addition of int64/toint64() for Lua 5.1
* Andrew McWatters <me@andrewmcwatters.com>
* 2 Jan 2012 21:33:00
* This code is hereby placed in the public domain.
*/


#ifndef lint64_h
#define lint64_h

#if defined( _WIN32 ) && !defined(CLANG)

typedef __int64 int64;
typedef unsigned __int64 uint64;

#endif // _WIN32

#include "lua.h"


LUA_API int64     (lua_toint64) (lua_State *L, int idx);


LUA_API void  (lua_pushint64) (lua_State *L, int64 n);



LUALIB_API int64 (luaL_checkint64) (lua_State *L, int narg);


int luaopen_int64(lua_State *L);



#endif


