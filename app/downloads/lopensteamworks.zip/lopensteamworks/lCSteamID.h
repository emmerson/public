/*
* lcsteamid.h
* CSteamID bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 25 Dec 2011 13:30:00
* This code is hereby placed in the public domain.
*/

LUA_API CSteamID     *(lua_tosteamid) (lua_State *L, int idx);


LUA_API void  (lua_pushsteamid) (lua_State *L, CSteamID *pSteamID);



LUALIB_API CSteamID *(luaL_checksteamid) (lua_State *L, int narg);


int luaopen_CSteamID(lua_State *L);


