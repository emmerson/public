/*
* lint64.c
* Addition of int64/toint64() for Lua 5.1
* Andrew McWatters <me@andrewmcwatters.com>
* 2 Jan 2012 21:33:00
* This code is hereby placed in the public domain.
*/


#include <stdlib.h>
#include <string.h>

#define lint64_c

#include "lua.h"

#include "lauxlib.h"
#include "lint64.h"


/*
** access functions (stack -> C)
*/


LUA_API int64 lua_toint64 (lua_State *L, int idx) {
  int64 n = *(int64 *)lua_touserdata(L, idx);
  return n;
}



/*
** push functions (C -> stack)
*/


LUA_API void lua_pushint64 (lua_State *L, int64 n) {
  int64 *pn = (int64 *)lua_newuserdata(L, sizeof(int64));
  *pn = n;
  luaL_getmetatable(L, "int64");
  lua_setmetatable(L, -2);
}


LUALIB_API int64 luaL_checkint64 (lua_State *L, int narg) {
  int64 *d = (int64 *)luaL_checkudata(L, narg, "int64");
  return *d;
}


static int int64___eq (lua_State *L) {
  lua_pushboolean(L, lua_toint64(L, 1) == lua_toint64(L, 2));
  return 1;
}

static int int64___tostring (lua_State *L) {
  char d[21];
  sprintf_s(d, 21, "%lld", luaL_checkint64(L, 1));
  lua_pushfstring(L, "%s", d);
  return 1;
}


static const luaL_Reg int64meta[] = {
  {"__eq", int64___eq},
  {"__tostring", int64___tostring},
  {NULL, NULL}
};


static int toint64 (lua_State *L) {
  // Andrew; ew.
  lua_pushint64(L, _atoi64(luaL_checkstring(L, 1)));
  return 1;
}


static const luaL_Reg int64_funcs[] = {
  {"toint64", toint64},
  {NULL, NULL}
};


/*
** Open int64 object
*/
int luaopen_int64 (lua_State *L) {
  luaL_newmetatable(L, "int64");
  luaL_register(L, NULL, int64meta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "int64");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "int64" */
  luaL_register(L, "_G", int64_funcs);
  lua_pop(L, 2);
  return 1;
}

