/*
* liclientengine.h
* IClientEngine bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Dec 2011 20:10:00
* This code is hereby placed in the public domain.
*/

LUALIB_API int luaopen_IClientEngine(lua_State *L, CreateInterfaceFn factory);
