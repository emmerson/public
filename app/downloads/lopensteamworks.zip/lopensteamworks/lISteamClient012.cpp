/*
* listeamclient012.cpp
* ISteamClient012 bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Dec 2011 20:10:00
* This code is hereby placed in the public domain.
*/

#include "Steamworks.h"

#include "lua.hpp"
#include "lSteamTypes.h"
#include "lISteamFriends002.h"
#include "lISteamFriends011.h"

ISteamClient012 *pSteamClient;

static int ISteamClient012_BReleaseSteamPipe(lua_State *L) {
  lua_pushboolean(L, pSteamClient->BReleaseSteamPipe(*luaL_checksteampipe(L, 1)));
  return 1;
}

static int ISteamClient012_BShutdownIfAllPipesClosed(lua_State *L) {
  lua_pushboolean(L, pSteamClient->BShutdownIfAllPipesClosed());
  return 1;
}

static int ISteamClient012_ConnectToGlobalUser(lua_State *L) {
  HSteamUser hUser = pSteamClient->ConnectToGlobalUser(*luaL_checksteampipe(L, 1));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int ISteamClient012_CreateLocalUser(lua_State *L) {
  HSteamUser hUser = pSteamClient->CreateLocalUser(luaL_checksteampipe(L, 1), (EAccountType)luaL_checkinteger(L, 2));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int ISteamClient012_CreateSteamPipe(lua_State *L) {
  HSteamPipe hPipe = pSteamClient->CreateSteamPipe();
  lua_pushsteampipe(L, &hPipe);
  return 1;
}

static int ISteamClient012_GetIPCCallCount(lua_State *L) {
  lua_pushinteger(L, pSteamClient->GetIPCCallCount());
  return 1;
}

static int ISteamClient012_GetISteamFriends(lua_State *L) {
  const char *pchVersion = luaL_checkstring(L, 3);
  if (strcmp(pchVersion, STEAMFRIENDS_INTERFACE_VERSION_002) == 0)
    lua_pushsteamfriends002(L, (ISteamFriends002 *)pSteamClient->GetISteamFriends(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2), STEAMFRIENDS_INTERFACE_VERSION_002));
  else if (strcmp(pchVersion, STEAMFRIENDS_INTERFACE_VERSION_011) == 0)
    lua_pushsteamfriends011(L, (ISteamFriends011 *)pSteamClient->GetISteamFriends(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2), STEAMFRIENDS_INTERFACE_VERSION_011));
  else
    lua_pushnil(L);
  return 1;
}

static int ISteamClient012_ReleaseUser(lua_State *L) {
  pSteamClient->ReleaseUser(*luaL_checksteampipe(L, 1), *luaL_checksteamuser(L, 2));
  return 0;
}

static int ISteamClient012_RunFrame(lua_State *L) {
  pSteamClient->RunFrame();
  return 0;
}

static int ISteamClient012_SetLocalIPBinding(lua_State *L) {
  pSteamClient->SetLocalIPBinding((uint32)luaL_checkinteger(L, 1), (uint16)luaL_checkinteger(L, 2));
  return 0;
}

static const luaL_Reg ISteamClient012lib[] = {
  {"BReleaseSteamPipe", ISteamClient012_BReleaseSteamPipe},
  {"BShutdownIfAllPipesClosed", ISteamClient012_BShutdownIfAllPipesClosed},
  {"ConnectToGlobalUser", ISteamClient012_ConnectToGlobalUser},
  {"CreateLocalUser", ISteamClient012_CreateLocalUser},
  {"CreateSteamPipe", ISteamClient012_CreateSteamPipe},
  {"GetIPCCallCount", ISteamClient012_GetIPCCallCount},
  {"GetISteamFriends", ISteamClient012_GetISteamFriends},
  {"ReleaseUser", ISteamClient012_ReleaseUser},
  {"RunFrame", ISteamClient012_RunFrame},
  {"SetLocalIPBinding", ISteamClient012_SetLocalIPBinding},
  {NULL, NULL}
};


/*
** Open ISteamClient012 library
*/
LUALIB_API int luaopen_ISteamClient012(lua_State *L, CreateInterfaceFn factory) {
  pSteamClient = (ISteamClient012 *)factory( STEAMCLIENT_INTERFACE_VERSION_012, NULL );
  if ( !pSteamClient )
  {
	  printf("Unable to get the steam client.\n");
	  return 0;
  }
  luaL_register(L, "ISteamClient012", ISteamClient012lib);
  lua_pop(L, 1);
  return 1;
}

