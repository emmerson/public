/*
* lsteamclient.cpp
* Steamclient bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 25 Dec 2011 11:03:00
* This code is hereby placed in the public domain.
*/

#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lint64.h"
}
#include "lSteamTypes.h"

/*
static int LBreakpad_SetSteamID(lua_State *L) {
  lua_pushinteger(L, Breakpad_SetSteamID((uint64)luaL_checkint64(L, 1)));
  return 1;
}

static int LBreakpad_SteamSetSteamID(lua_State *L) {
  lua_pushinteger(L, Breakpad_SteamSetSteamID((uint64)luaL_checkint64(L, 1)));
  return 1;
}

static int LBreakpad_SteamMiniDumpInit(lua_State *L) {
  Breakpad_SteamMiniDumpInit(luaL_checkinteger(L, 1), luaL_checkstring(L, 2), luaL_checkstring(L, 3));
  return 0;
}

static int LBreakpad_SteamWriteMiniDumpSetComment(lua_State *L) {
  lua_pushinteger(L, Breakpad_SteamWriteMiniDumpSetComment(luaL_checkstring(L, 1)));
  return 1;
}

static int LBreakpad_SteamWriteMiniDumpUsingExceptionInfoWithBuildId(lua_State *L) {
  Breakpad_SteamWriteMiniDumpUsingExceptionInfoWithBuildId(luaL_checkinteger(L, 1), luaL_checkinteger(L, 2));
  return 0;
}
*/

static int LSteam_BConnected(lua_State *L) {
  lua_pushboolean(L, Steam_BConnected(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2)));
  return 1;
}

static int LSteam_BLoggedOn(lua_State *L) {
  lua_pushboolean(L, Steam_BLoggedOn(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2)));
  return 1;
}

static int LSteam_LogOn(lua_State *L) {
  Steam_LogOn(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2), (uint64)luaL_checkint64(L, 3));
  return 0;
}

static int LSteam_LogOff(lua_State *L) {
  Steam_LogOff(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2));
  return 0;
}

static int LSteam_TerminateGameConnection(lua_State *L) {
  Steam_TerminateGameConnection(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2), (uint32)luaL_checkinteger(L, 3), (uint16)luaL_checkinteger(L, 4));
  return 0;
}

static int LSteam_BGetCallback(lua_State *L) {
  CallbackMsg_t callBack;
  lua_pushboolean(L, Steam_BGetCallback(*luaL_checksteampipe(L, 1), &callBack));
  lua_newtable(L);
  lua_setcallbackmsg(L, -1, &callBack);
  return 2;
}

static int LSteam_FreeLastCallback(lua_State *L) {
  Steam_FreeLastCallback(*luaL_checksteampipe(L, 1));
  return 0;
}

static int LSteam_CreateSteamPipe(lua_State *L) {
  HSteamPipe hPipe = Steam_CreateSteamPipe();
  lua_pushsteampipe(L, &hPipe);
  return 1;
}

static int LSteam_BReleaseSteamPipe(lua_State *L) {
  lua_pushboolean(L, Steam_BReleaseSteamPipe(*luaL_checksteampipe(L, 1)));
  return 1;
}

static int LSteam_CreateLocalUser(lua_State *L) {
  HSteamUser hUser = Steam_CreateLocalUser(luaL_checksteampipe(L, 1), (EAccountType)luaL_checkinteger(L, 2));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int LSteam_CreateGlobalUser(lua_State *L) {
  HSteamUser hUser = Steam_CreateGlobalUser(luaL_checksteampipe(L, 1));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int LSteam_ConnectToGlobalUser(lua_State *L) {
  HSteamUser hUser = Steam_ConnectToGlobalUser(*luaL_checksteampipe(L, 1));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int LSteam_ReleaseUser(lua_State *L) {
  Steam_ReleaseUser(*luaL_checksteampipe(L, 1), *luaL_checksteamuser(L, 2));
  return 0;
}

static int LSteam_SetLocalIPBinding(lua_State *L) {
  Steam_SetLocalIPBinding((uint32)luaL_checkinteger(L, 1), (uint16)luaL_checkinteger(L, 2));
  return 0;
}

static const luaL_Reg Steamclientlib[] = {
/*
  {"Breakpad_SetSteamID", LBreakpad_SetSteamID},
  {"Breakpad_SteamSetSteamID", LBreakpad_SteamSetSteamID},
  {"Breakpad_SteamMiniDumpInit", LBreakpad_SteamMiniDumpInit},
  {"Breakpad_SteamWriteMiniDumpSetComment", LBreakpad_SteamWriteMiniDumpSetComment},
  {"Breakpad_SteamWriteMiniDumpUsingExceptionInfoWithBuildId", LBreakpad_SteamWriteMiniDumpUsingExceptionInfoWithBuildId},
*/
  {"Steam_BConnected", LSteam_BConnected},
  {"Steam_BLoggedOn", LSteam_BLoggedOn},
  {"Steam_LogOn", LSteam_LogOn},
  {"Steam_LogOff", LSteam_LogOff},
  {"Steam_TerminateGameConnection", LSteam_TerminateGameConnection},
  {"Steam_BGetCallback", LSteam_BGetCallback},
  {"Steam_FreeLastCallback", LSteam_FreeLastCallback},
  {"Steam_CreateSteamPipe", LSteam_CreateSteamPipe},
  {"Steam_BReleaseSteamPipe", LSteam_BReleaseSteamPipe},
  {"Steam_CreateLocalUser", LSteam_CreateLocalUser},
  {"Steam_CreateGlobalUser", LSteam_CreateGlobalUser},
  {"Steam_ConnectToGlobalUser", LSteam_ConnectToGlobalUser},
  {"Steam_ReleaseUser", LSteam_ReleaseUser},
  {"Steam_SetLocalIPBinding", LSteam_SetLocalIPBinding},
  {NULL, NULL}
};


/*
** Open Steamclient library
*/
LUALIB_API int luaopen_Steamclient(lua_State *L) {
  luaL_register(L, "_G", Steamclientlib);
  lua_pop(L, 1);
  return 1;
}

