/*
* lopensteamworks.cpp
* Open Steamworks for Lua 5.1
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Dec 2011 20:10:00
* This code is hereby placed in the public domain.
*/

#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lint64.h"
}
#include "lsteamclient.h"
#include "lsteamtypes.h"
#include "lcsteamid.h"
#ifdef STEAMWORKS_CLIENT_INTERFACES
#include "liclientengine.h"
#include "liclientfriends.h"
#endif
#include "listeamclient012.h"
#include "listeamfriends002.h"
#include "listeamfriends011.h"

extern "C" {
	LUALIB_API int luaopen_opensteamworks(lua_State *L);
}

LUALIB_API int luaopen_opensteamworks(lua_State *L) {
  static CSteamAPILoader loader;
  static CreateInterfaceFn factory = loader.GetSteam3Factory();

  if ( !factory )
  {
	  luaL_error(L, "unable to load steamclient factory");
	  return 0;
  }

  // internal types
  luaopen_int64(L);

  // steam types
  luaopen_HSteamPipe(L);
  luaopen_HSteamUser(L);
  luaopen_CSteamID(L);

  // interfaces
  //
  // Andrew; luaopen_* functions which pass factory are singleton libraries.
  // Considering we initalize them once, and they're not dependent on
  // HSteamPipe or HSteamUser, there is no need to provide object orientation
  // for such interfaces.
#ifdef STEAMWORKS_CLIENT_INTERFACES
  luaopen_IClientEngine(L, factory);
  luaopen_IClientFriends(L);
#endif
  luaopen_ISteamClient012(L, factory);
  luaopen_Steamclient(L);
  luaopen_ISteamFriends002(L);
  luaopen_ISteamFriends011(L);
  return 1;
}

