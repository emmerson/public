/*
* lsteamtypes.h
* SteamTypes bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Dec 2011 20:10:00
* This code is hereby placed in the public domain.
*/

LUA_API SteamAPICall_t *(lua_tosteamapicall) (lua_State *L, int idx);
LUA_API HSteamPipe     *(lua_tosteampipe) (lua_State *L, int idx);
LUA_API HSteamUser     *(lua_tosteamuser) (lua_State *L, int idx);


LUA_API void  (lua_pushsteamapicall) (lua_State *L, SteamAPICall_t *pSteamAPICall_t);
LUA_API void  (lua_pushsteampipe) (lua_State *L, HSteamPipe *phPipe);
LUA_API void  (lua_pushsteamuser) (lua_State *L, HSteamUser *phUser);



LUALIB_API SteamAPICall_t *(luaL_checksteamapicall) (lua_State *L, int narg);
LUALIB_API HSteamPipe *(luaL_checksteampipe) (lua_State *L, int narg);
LUALIB_API HSteamUser *(luaL_checksteamuser) (lua_State *L, int narg);


LUA_API void  (lua_setcallbackmsg) (lua_State *L, int idx, CallbackMsg_t *pcallBack);


int luaopen_HSteamPipe(lua_State *L);
int luaopen_HSteamUser(lua_State *L);


