/*
* liclientfriends.h
* IClientFriends bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 7 Jan 2012 18:28:00
* This code is hereby placed in the public domain.
*/

LUA_API IClientFriends     *(lua_toclientfriends) (lua_State *L, int idx);


LUA_API void  (lua_pushclientfriends) (lua_State *L, IClientFriends *pClientFriends);



LUALIB_API IClientFriends *(luaL_checkclientfriends) (lua_State *L, int narg);


int luaopen_IClientFriends(lua_State *L);


