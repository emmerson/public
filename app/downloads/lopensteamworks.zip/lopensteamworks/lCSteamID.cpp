/*
* lcsteamid.cpp
* CSteamID bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 25 Dec 2011 13:30:00
* This code is hereby placed in the public domain.
*/

#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lint64.h"
}

/*
** access functions (stack -> C)
*/


LUA_API CSteamID *lua_tosteamid (lua_State *L, int idx) {
  CSteamID *pSteamID = (CSteamID *)lua_touserdata(L, idx);
  return pSteamID;
}



/*
** push functions (C -> stack)
*/


LUA_API void lua_pushsteamid (lua_State *L, CSteamID *pSteamID) {
  CSteamID *pudSteamID = (CSteamID *)lua_newuserdata(L, sizeof(CSteamID));
  *pudSteamID = *pSteamID;
  luaL_getmetatable(L, "CSteamID");
  lua_setmetatable(L, -2);
}


LUALIB_API CSteamID *luaL_checksteamid (lua_State *L, int narg) {
  CSteamID *d = (CSteamID *)luaL_checkudata(L, narg, "CSteamID");
  return d;
}


static int CSteamID_BAnonAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BAnonAccount());
  return 1;
}

static int CSteamID_BAnonUserAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BAnonUserAccount());
  return 1;
}

static int CSteamID_BBlankAnonAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BBlankAnonAccount());
  return 1;
}

static int CSteamID_BChatAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BChatAccount());
  return 1;
}

static int CSteamID_BClanAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BClanAccount());
  return 1;
}

static int CSteamID_BConsoleUserAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BConsoleUserAccount());
  return 1;
}

static int CSteamID_BContentServerAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BContentServerAccount());
  return 1;
}

static int CSteamID_BGameServerAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BGameServerAccount());
  return 1;
}

static int CSteamID_BIndividualAccount (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BIndividualAccount());
  return 1;
}

// DEBUG function
/*
static int CSteamID_BValidExternalSteamID (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->BValidExternalSteamID());
  return 1;
}
*/

static int CSteamID_ClearIndividualInstance (lua_State *L) {
  luaL_checksteamid(L, 1)->ClearIndividualInstance();
  return 0;
}

static int CSteamID_ConvertToUint64 (lua_State *L) {
  lua_pushint64(L, luaL_checksteamid(L, 1)->ConvertToUint64());
  return 1;
}

static int CSteamID_CreateBlankAnonLogon (lua_State *L) {
  luaL_checksteamid(L, 1)->CreateBlankAnonLogon((EUniverse)luaL_checkinteger(L, 2));
  return 0;
}

static int CSteamID_CreateBlankAnonUserLogon (lua_State *L) {
  luaL_checksteamid(L, 1)->CreateBlankAnonUserLogon((EUniverse)luaL_checkinteger(L, 2));
  return 0;
}

static int CSteamID_FullSet (lua_State *L) {
  luaL_checksteamid(L, 1)->FullSet((uint64)luaL_checkint64(L, 2), (EUniverse)luaL_checkinteger(L, 3), (EAccountType)luaL_checkinteger(L, 4));
  return 0;
}

static int CSteamID_GetAccountID (lua_State *L) {
  lua_pushinteger(L, luaL_checksteamid(L, 1)->GetAccountID());
  return 1;
}

static int CSteamID_GetEAccountType (lua_State *L) {
  lua_pushinteger(L, luaL_checksteamid(L, 1)->GetEAccountType());
  return 1;
}

static int CSteamID_GetEUniverse (lua_State *L) {
  lua_pushinteger(L, luaL_checksteamid(L, 1)->GetEUniverse());
  return 1;
}

static int CSteamID_GetStaticAccountKey (lua_State *L) {
  lua_pushinteger(L, (lua_Integer)luaL_checksteamid(L, 1)->GetStaticAccountKey());
  return 1;
}

static int CSteamID_GetUnAccountInstance (lua_State *L) {
  lua_pushinteger(L, luaL_checksteamid(L, 1)->GetUnAccountInstance());
  return 1;
}

static int CSteamID_HasNoIndividualInstance (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->HasNoIndividualInstance());
  return 1;
}

static int CSteamID_InstancedSet (lua_State *L) {
  luaL_checksteamid(L, 1)->InstancedSet((uint32)luaL_checkinteger(L, 2), (uint32)luaL_checkinteger(L, 3), (EUniverse)luaL_checkinteger(L, 4), (EAccountType)luaL_checkinteger(L, 5));
  return 0;
}

static int CSteamID_IsLobby (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->IsLobby());
  return 1;
}

static int CSteamID_IsValid (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->IsValid());
  return 1;
}

static int CSteamID_Render (lua_State *L) {
  lua_pushstring(L, luaL_checksteamid(L, 1)->Render());
  return 1;
}

static int CSteamID_Set (lua_State *L) {
  luaL_checksteamid(L, 1)->Set((uint32)luaL_checkinteger(L, 2), (EUniverse)luaL_checkinteger(L, 3), (EAccountType)luaL_checkinteger(L, 4));
  return 0;
}

static int CSteamID_SetAccountID (lua_State *L) {
  luaL_checksteamid(L, 1)->SetAccountID((uint32)luaL_checkinteger(L, 2));
  return 0;
}

static int CSteamID_SetAccountInstance (lua_State *L) {
  luaL_checksteamid(L, 1)->SetAccountInstance((uint32)luaL_checkinteger(L, 2));
  return 0;
}

static int CSteamID_SetEUniverse (lua_State *L) {
  luaL_checksteamid(L, 1)->SetEUniverse((EUniverse)luaL_checkinteger(L, 2));
  return 0;
}

#if 0
static int CSteamID_SetFromSteam2String (lua_State *L) {
  lua_pushboolean(L, luaL_checksteamid(L, 1)->SetFromSteam2String(luaL_checkstring(L, 2), (EUniverse)luaL_checkinteger(L, 3)));
  return 1;
}

static int CSteamID_SetFromString (lua_State *L) {
  luaL_checksteamid(L, 1)->SetFromString(luaL_checkstring(L, 2), (EUniverse)luaL_checkinteger(L, 3));
  return 0;
}
#endif

static int CSteamID_SetFromUint64 (lua_State *L) {
  luaL_checksteamid(L, 1)->SetFromUint64((uint64)luaL_checkint64(L, 2));
  return 0;
}

static int CSteamID_SteamRender (lua_State *L) {
  lua_pushstring(L, luaL_checksteamid(L, 1)->SteamRender());
  return 1;
}

static int CSteamID___eq (lua_State *L) {
  lua_pushboolean(L, *(CSteamID *)lua_tosteamid(L, 1) == *(CSteamID *)lua_tosteamid(L, 2));
  return 1;
}

static int CSteamID___tostring (lua_State *L) {
  char szSteamID[21];
  sprintf_s(szSteamID, 21, "CSteamID: %lld", lua_tosteamid(L, 1)->ConvertToUint64());
  lua_pushfstring(L, "%s", szSteamID);
  return 1;
}


static const luaL_Reg CSteamIDmeta[] = {
  {"BAnonAccount", CSteamID_BAnonAccount},
  {"BAnonUserAccount", CSteamID_BAnonUserAccount},
  {"BBlankAnonAccount", CSteamID_BBlankAnonAccount},
  {"BChatAccount", CSteamID_BChatAccount},
  {"BClanAccount", CSteamID_BClanAccount},
  {"BConsoleUserAccount", CSteamID_BConsoleUserAccount},
  {"BContentServerAccount", CSteamID_BContentServerAccount},
  {"BGameServerAccount", CSteamID_BGameServerAccount},
  {"BIndividualAccount", CSteamID_BIndividualAccount},
//{"BValidExternalSteamID", CSteamID_BValidExternalSteamID},
  {"ClearIndividualInstance", CSteamID_ClearIndividualInstance},
  {"ConvertToUint64", CSteamID_ConvertToUint64},
  {"CreateBlankAnonLogon", CSteamID_CreateBlankAnonLogon},
  {"CreateBlankAnonUserLogon", CSteamID_CreateBlankAnonUserLogon},
  {"FullSet", CSteamID_FullSet},
  {"GetAccountID", CSteamID_GetAccountID},
  {"GetEAccountType", CSteamID_GetEAccountType},
  {"GetEUniverse", CSteamID_GetEUniverse},
  {"GetStaticAccountKey", CSteamID_GetStaticAccountKey},
  {"GetUnAccountInstance", CSteamID_GetUnAccountInstance},
  {"HasNoIndividualInstance", CSteamID_HasNoIndividualInstance},
  {"InstancedSet", CSteamID_InstancedSet},
  {"IsLobby", CSteamID_IsLobby},
  {"IsValid", CSteamID_IsValid},
  {"Render", CSteamID_Render},
  {"Set", CSteamID_Set},
  {"SetAccountID", CSteamID_SetAccountID},
  {"SetAccountInstance", CSteamID_SetAccountInstance},
  {"SetEUniverse", CSteamID_SetEUniverse},
#if 0
  {"SetFromSteam2String", CSteamID_SetFromSteam2String},
  {"SetFromString", CSteamID_SetFromString},
#endif
  {"SetFromUint64", CSteamID_SetFromUint64},
  {"SteamRender", CSteamID_SteamRender},
  {"__eq", CSteamID___eq},
  {"__tostring", CSteamID___tostring},
  {NULL, NULL}
};


static int LCSteamID (lua_State *L) {
  CSteamID steamID;
  lua_pushsteamid(L, &steamID);
  return 1;
}


static const luaL_Reg CSteamID_funcs[] = {
  {"CSteamID", LCSteamID},
  {NULL, NULL}
};


/*
** Open CSteamID object
*/
int luaopen_CSteamID(lua_State *L) {
  luaL_newmetatable(L, "CSteamID");
  luaL_register(L, NULL, CSteamIDmeta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "steamid");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "steamid" */
  luaL_register(L, "_G", CSteamID_funcs);
  lua_pop(L, 2);
  return 1;
}

