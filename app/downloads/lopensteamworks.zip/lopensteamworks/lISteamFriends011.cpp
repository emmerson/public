/*
* listeamfriends011.cpp
* ISteamFriends011 bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 25 Dec 2011 21:31:00
* This code is hereby placed in the public domain.
*/

#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lauxlibex.h"
}
#include "lCSteamID.h"
#include "lSteamTypes.h"

/*
** access functions (stack -> C)
*/


LUA_API ISteamFriends011 *lua_tosteamfriends011 (lua_State *L, int idx) {
  ISteamFriends011 *pSteamFriends = (ISteamFriends011 *)lua_touserdata(L, idx);
  return pSteamFriends;
}



/*
** push functions (C -> stack)
*/


LUA_API void lua_pushsteamfriends011 (lua_State *L, ISteamFriends011 *pSteamFriends) {
  lua_pushlightuserdata(L, pSteamFriends);
  luaL_getmetatable(L, "ISteamFriends011");
  lua_setmetatable(L, -2);
}


LUALIB_API ISteamFriends011 *luaL_checksteamfriends011 (lua_State *L, int narg) {
  ISteamFriends011 *d = (ISteamFriends011 *)luaL_checkudata(L, narg, "ISteamFriends011");
  return d;
}


static int ISteamFriends011_ActivateGameOverlay(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->ActivateGameOverlay(luaL_checkstring(L, 2));
  return 0;
}

static int ISteamFriends011_ActivateGameOverlayInviteDialog(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->ActivateGameOverlayInviteDialog(*luaL_checksteamid(L, 2));
  return 0;
}

static int ISteamFriends011_ActivateGameOverlayToStore(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->ActivateGameOverlayToStore((AppId_t)luaL_checkinteger(L, 2));
  return 0;
}

static int ISteamFriends011_ActivateGameOverlayToUser(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->ActivateGameOverlayToUser(luaL_checkstring(L, 2), *luaL_checksteamid(L, 2));
  return 0;
}

static int ISteamFriends011_ActivateGameOverlayToWebPage(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->ActivateGameOverlayToWebPage(luaL_checkstring(L, 2));
  return 0;
}

static int ISteamFriends011_ClearRichPresence(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->ClearRichPresence();
  return 0;
}

static int ISteamFriends011_CloseClanChatWindowInSteam(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->CloseClanChatWindowInSteam(*luaL_checksteamid(L, 2)));
  return 0;
}

static int ISteamFriends011_GetChatMemberByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends011(L, 1)->GetChatMemberByIndex(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends011_GetClanActivityCounts(lua_State *L) {
  int nOnline, nInGame, nChatting;
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->GetClanActivityCounts(*luaL_checksteamid(L, 2), &nOnline, &nInGame, &nChatting));
  lua_pushinteger(L, nOnline);
  lua_pushinteger(L, nInGame);
  lua_pushinteger(L, nChatting);
  return 4;
}

static int ISteamFriends011_GetClanByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends011(L, 1)->GetClanByIndex(luaL_checkinteger(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends011_GetClanChatMemberCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetClanChatMemberCount(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetClanChatMessage(lua_State *L) {
  char vData[2049] = {0};
  EChatEntryType msgType;
  CSteamID SteamIDChatter;
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetClanChatMessage(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3), &vData, 2049, &msgType, &SteamIDChatter));
  lua_pushstring(L, vData);
  lua_pushinteger(L, msgType);
  lua_pushsteamid(L, &SteamIDChatter);
  return 4;
}

static int ISteamFriends011_GetClanCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetClanCount());
  return 1;
}

static int ISteamFriends011_GetClanName(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends011(L, 1)->GetClanName(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetClanOfficerByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends011(L, 1)->GetClanOfficerByIndex(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends011_GetClanOfficerCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetClanOfficerCount(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetClanOwner(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends011(L, 1)->GetClanOwner(*luaL_checksteamid(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends011_GetClanTag(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends011(L, 1)->GetClanTag(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetCoplayFriend(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends011(L, 1)->GetCoplayFriend(luaL_checkinteger(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends011_GetCoplayFriendCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetCoplayFriendCount());
  return 1;
}

static int ISteamFriends011_GetFriendByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends011(L, 1)->GetFriendByIndex(luaL_checkinteger(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int ISteamFriends011_GetFriendCoplayGame(lua_State *L) {
  lua_pushinteger(L, (lua_Integer)luaL_checksteamfriends011(L, 1)->GetFriendCoplayGame(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetFriendCoplayTime(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetFriendCoplayTime(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetFriendCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetFriendCount(luaL_checkinteger(L, 2)));
  return 1;
}

static int ISteamFriends011_GetFriendCountFromSource(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetFriendCountFromSource(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetFriendFromSourceByIndex(lua_State *L) {
  CSteamID steamID = luaL_checksteamfriends011(L, 1)->GetFriendFromSourceByIndex(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

/*
static int ISteamFriends011_GetFriendGamePlayed(lua_State *L) {
  FriendGameInfo_t FriendGameInfo;
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->GetFriendGamePlayed(*luaL_checksteamid(L, 2), &FriendGameInfo);
  lua_newtable(L);
  lua_setfriendgameinfo(L, -1);
  return 1;
}
*/

static int ISteamFriends011_GetFriendMessage(lua_State *L) {
  char vData[2049] = {0};
  EChatEntryType msgType;
  CSteamID SteamIDChatter;
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetFriendMessage(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3), &vData, 2049, &msgType));
  lua_pushstring(L, vData);
  lua_pushinteger(L, msgType);
  return 3;
}

static int ISteamFriends011_GetFriendPersonaName(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends011(L, 1)->GetFriendPersonaName(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetFriendPersonaNameHistory(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends011(L, 1)->GetFriendPersonaNameHistory(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3)));
  return 1;
}

static int ISteamFriends011_GetFriendPersonaState(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetFriendPersonaState(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetFriendRelationship(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetFriendRelationship(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetFriendRichPresence(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends011(L, 1)->GetFriendRichPresence(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int ISteamFriends011_GetFriendRichPresenceKeyByIndex(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends011(L, 1)->GetFriendRichPresenceKeyByIndex(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3)));
  return 1;
}

static int ISteamFriends011_GetFriendRichPresenceKeyCount(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetFriendRichPresenceKeyCount(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetLargeFriendAvatar(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetLargeFriendAvatar(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetMediumFriendAvatar(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetMediumFriendAvatar(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetPersonaName(lua_State *L) {
  lua_pushstring(L, luaL_checksteamfriends011(L, 1)->GetPersonaName());
  return 1;
}

static int ISteamFriends011_GetPersonaState(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetPersonaState());
  return 1;
}

static int ISteamFriends011_GetSmallFriendAvatar(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetSmallFriendAvatar(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_GetUserRestrictions(lua_State *L) {
  lua_pushinteger(L, luaL_checksteamfriends011(L, 1)->GetUserRestrictions());
  return 1;
}

static int ISteamFriends011_HasFriend(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->HasFriend(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3)));
  return 1;
}

static int ISteamFriends011_InviteUserToGame(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->InviteUserToGame(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int ISteamFriends011_IsClanChatAdmin(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->IsClanChatAdmin(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3)));
  return 1;
}

static int ISteamFriends011_IsClanChatWindowOpenInSteam(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->IsClanChatWindowOpenInSteam(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_IsUserInSource(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->IsUserInSource(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3)));
  return 1;
}

static int ISteamFriends011_JoinClanChatRoom(lua_State *L) {
  SteamAPICall_t SteamAPICall = luaL_checksteamfriends011(L, 1)->JoinClanChatRoom(*luaL_checksteamid(L, 2));
  lua_pushsteamapicall(L, &SteamAPICall);
  return 1;
}

static int ISteamFriends011_LeaveClanChatRoom(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->LeaveClanChatRoom(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_OpenClanChatWindowInSteam(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->OpenClanChatWindowInSteam(*luaL_checksteamid(L, 2)));
  return 1;
}

static int ISteamFriends011_ReplyToFriendMessage(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->ReplyToFriendMessage(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int ISteamFriends011_RequestFriendRichPresence(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->RequestFriendRichPresence(*luaL_checksteamid(L, 2));
  return 0;
}

static int ISteamFriends011_RequestUserInformation(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->RequestUserInformation(*luaL_checksteamid(L, 2), luaL_checkboolean(L, 3)));
  return 1;
}

static int ISteamFriends011_SendClanChatMessage(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->SendClanChatMessage(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int ISteamFriends011_SetInGameVoiceSpeaking(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->SetInGameVoiceSpeaking(*luaL_checksteamid(L, 2), (bool)luaL_checkboolean(L, 3));
  return 0;
}

static int ISteamFriends011_SetListenForFriendsMessages(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->SetListenForFriendsMessages(luaL_checkboolean(L, 2)));
  return 1;
}

static int ISteamFriends011_SetPersonaName(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->SetPersonaName(luaL_checkstring(L, 2));
  return 0;
}

static int ISteamFriends011_SetPlayedWith(lua_State *L) {
  luaL_checksteamfriends011(L, 1)->SetPlayedWith(*luaL_checksteamid(L, 2));
  return 0;
}

static int ISteamFriends011_SetRichPresence(lua_State *L) {
  lua_pushboolean(L, luaL_checksteamfriends011(L, 1)->SetRichPresence(luaL_checkstring(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int ISteamFriends011___tostring (lua_State *L) {
  lua_pushfstring(L, "ISteamFriends011: %p", luaL_checksteamfriends011(L, 1));
  return 1;
}

static const luaL_Reg ISteamFriends011meta[] = {
  {"ActivateGameOverlay", ISteamFriends011_ActivateGameOverlay},
  {"ActivateGameOverlayInviteDialog", ISteamFriends011_ActivateGameOverlayInviteDialog},
  {"ActivateGameOverlayToStore", ISteamFriends011_ActivateGameOverlayToStore},
  {"ActivateGameOverlayToUser", ISteamFriends011_ActivateGameOverlayToUser},
  {"ActivateGameOverlayToWebPage", ISteamFriends011_ActivateGameOverlayToWebPage},
  {"ClearRichPresence", ISteamFriends011_ClearRichPresence},
  {"CloseClanChatWindowInSteam", ISteamFriends011_CloseClanChatWindowInSteam},
  {"GetChatMemberByIndex", ISteamFriends011_GetChatMemberByIndex},
  {"GetClanActivityCounts", ISteamFriends011_GetClanActivityCounts},
  {"GetClanByIndex", ISteamFriends011_GetClanByIndex},
  {"GetClanChatMemberCount", ISteamFriends011_GetClanChatMemberCount},
  {"GetClanChatMessage", ISteamFriends011_GetClanChatMessage},
  {"GetClanCount", ISteamFriends011_GetClanCount},
  {"GetClanName", ISteamFriends011_GetClanName},
  {"GetClanOfficerByIndex", ISteamFriends011_GetClanOfficerByIndex},
  {"GetClanOfficerCount", ISteamFriends011_GetClanOfficerCount},
  {"GetClanOwner", ISteamFriends011_GetClanOwner},
  {"GetClanTag", ISteamFriends011_GetClanTag},
  {"GetCoplayFriend", ISteamFriends011_GetCoplayFriend},
  {"GetCoplayFriendCount", ISteamFriends011_GetCoplayFriendCount},
  {"GetFriendByIndex", ISteamFriends011_GetFriendByIndex},
  {"GetFriendCoplayGame", ISteamFriends011_GetFriendCoplayGame},
  {"GetFriendCoplayTime", ISteamFriends011_GetFriendCoplayTime},
  {"GetFriendCount", ISteamFriends011_GetFriendCount},
  {"GetFriendCountFromSource", ISteamFriends011_GetFriendCountFromSource},
  {"GetFriendFromSourceByIndex", ISteamFriends011_GetFriendFromSourceByIndex},
//{"GetFriendGamePlayed", ISteamFriends011_GetFriendGamePlayed},
  {"GetFriendMessage", ISteamFriends011_GetFriendMessage},
  {"GetFriendPersonaName", ISteamFriends011_GetFriendPersonaName},
  {"GetFriendPersonaNameHistory", ISteamFriends011_GetFriendPersonaNameHistory},
  {"GetFriendPersonaState", ISteamFriends011_GetFriendPersonaState},
  {"GetFriendRelationship", ISteamFriends011_GetFriendRelationship},
  {"GetFriendRichPresence", ISteamFriends011_GetFriendRichPresence},
  {"GetFriendRichPresenceKeyByIndex", ISteamFriends011_GetFriendRichPresenceKeyByIndex},
  {"GetFriendRichPresenceKeyCount", ISteamFriends011_GetFriendRichPresenceKeyCount},
  {"GetLargeFriendAvatar", ISteamFriends011_GetLargeFriendAvatar},
  {"GetMediumFriendAvatar", ISteamFriends011_GetMediumFriendAvatar},
  {"GetPersonaName", ISteamFriends011_GetPersonaName},
  {"GetPersonaState", ISteamFriends011_GetPersonaState},
  {"GetSmallFriendAvatar", ISteamFriends011_GetSmallFriendAvatar},
  {"GetUserRestrictions", ISteamFriends011_GetUserRestrictions},
  {"HasFriend", ISteamFriends011_HasFriend},
  {"InviteUserToGame", ISteamFriends011_InviteUserToGame},
  {"IsClanChatAdmin", ISteamFriends011_IsClanChatAdmin},
  {"IsClanChatWindowOpenInSteam", ISteamFriends011_IsClanChatWindowOpenInSteam},
  {"IsUserInSource", ISteamFriends011_IsUserInSource},
  {"JoinClanChatRoom", ISteamFriends011_JoinClanChatRoom},
  {"LeaveClanChatRoom", ISteamFriends011_LeaveClanChatRoom},
  {"OpenClanChatWindowInSteam", ISteamFriends011_OpenClanChatWindowInSteam},
  {"ReplyToFriendMessage", ISteamFriends011_ReplyToFriendMessage},
  {"RequestFriendRichPresence", ISteamFriends011_RequestFriendRichPresence},
  {"RequestUserInformation", ISteamFriends011_RequestUserInformation},
  {"SendClanChatMessage", ISteamFriends011_SendClanChatMessage},
  {"SetInGameVoiceSpeaking", ISteamFriends011_SetInGameVoiceSpeaking},
  {"SetListenForFriendsMessages", ISteamFriends011_SetListenForFriendsMessages},
  {"SetPersonaName", ISteamFriends011_SetPersonaName},
  {"SetPlayedWith", ISteamFriends011_SetPlayedWith},
  {"SetRichPresence", ISteamFriends011_SetRichPresence},
  {"__tostring", ISteamFriends011___tostring},
  {NULL, NULL}
};


/*
** Open ISteamFriends011 object
*/
LUALIB_API int luaopen_ISteamFriends011(lua_State *L) {
  luaL_newmetatable(L, "ISteamFriends011");
  luaL_register(L, NULL, ISteamFriends011meta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "steamfriends011");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "steamfriends011" */
  lua_pop(L, 1);
  return 1;
}

