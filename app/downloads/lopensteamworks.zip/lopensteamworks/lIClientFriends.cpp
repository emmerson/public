/*
* liclientfriends.cpp
* IClientFriends bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 7 Jan 2012 18:28:00
* This code is hereby placed in the public domain.
*/

#ifdef STEAMWORKS_CLIENT_INTERFACES
#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lauxlibex.h"
	#include "lint64.h"
}
#include "lCSteamID.h"
#include "lSteamTypes.h"

/*
** access functions (stack -> C)
*/


LUA_API IClientFriends *lua_toclientfriends (lua_State *L, int idx) {
  IClientFriends *pClientFriends = (IClientFriends *)lua_touserdata(L, idx);
  return pClientFriends;
}



/*
** push functions (C -> stack)
*/


LUA_API void lua_pushclientfriends (lua_State *L, IClientFriends *pClientFriends) {
  lua_pushlightuserdata(L, pClientFriends);
  luaL_getmetatable(L, "IClientFriends");
  lua_setmetatable(L, -2);
}


LUALIB_API IClientFriends *luaL_checkclientfriends (lua_State *L, int narg) {
  IClientFriends *d = (IClientFriends *)luaL_checkudata(L, narg, "IClientFriends");
  return d;
}


static int IClientFriends_AcknowledgeInviteToClan(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->AcknowledgeInviteToClan(*luaL_checksteamid(L, 2), luaL_checkboolean(L, 3)));
  return 1;
}

static int IClientFriends_ActivateGameOverlay(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ActivateGameOverlay(luaL_checkstring(L, 2));
  return 0;
}

static int IClientFriends_ActivateGameOverlayInviteDialog(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ActivateGameOverlayInviteDialog(*luaL_checksteamid(L, 2));
  return 0;
}

static int IClientFriends_ActivateGameOverlayToStore(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ActivateGameOverlayToStore((AppId_t)luaL_checkinteger(L, 2));
  return 0;
}

static int IClientFriends_ActivateGameOverlayToUser(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ActivateGameOverlayToUser(luaL_checkstring(L, 2), *luaL_checksteamid(L, 3));
  return 0;
}

static int IClientFriends_ActivateGameOverlayToWebPage(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ActivateGameOverlayToWebPage(luaL_checkstring(L, 2));
  return 0;
}

static int IClientFriends_AddFriend(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->AddFriend(*luaL_checksteamid(L, 2)));
  return 1;
}

// TODO: Add HSteamCall
/*
static int IClientFriends_AddFriendByName(lua_State *L) {
  lua_pushsteamcall(L, luaL_checkclientfriends(L, 1)->AddFriendByName(luaL_checkstring(L, 2)));
  return 1;
}
*/

static int IClientFriends_AddFriendToGroup(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->AddFriendToGroup(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3)));
  return 1;
}

static int IClientFriends_BanChatMember(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BanChatMember(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3)));
  return 1;
}

// TODO: Add HVoiceCall
/*
static int IClientFriends_BCanReceive(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BCanReceive(*luaL_checkvoicecall(L, 2)));
  return 1;
}

static int IClientFriends_BCanSend(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BCanSend(*luaL_checkvoicecall(L, 2)));
  return 1;
}
*/

static int IClientFriends_BChatRoomHasAvailableVoiceSlots(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BChatRoomHasAvailableVoiceSlots(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_BChatRoomModerated(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BChatRoomModerated(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_BIsChatRoomVoiceSpeaking(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BIsChatRoomVoiceSpeaking(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3)));
  return 1;
}

// TODO: Add HVoiceCall
/*
static int IClientFriends_BVoiceIsLocalOnHold(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BVoiceIsLocalOnHold(*luaL_checkvoicecall(L, 2)));
  return 1;
}

static int IClientFriends_BVoiceIsRemoteOnHold(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->BVoiceIsRemoteOnHold(*luaL_checkvoicecall(L, 2)));
  return 1;
}
*/

static int IClientFriends_CancelTradeRequest(lua_State *L) {
  luaL_checkclientfriends(L, 1)->CancelTradeRequest(*luaL_checksteamid(L, 2));
  return 0;
}

static int IClientFriends_ChatRoomVoiceRetryConnections(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ChatRoomVoiceRetryConnections(*luaL_checksteamid(L, 2));
  return 0;
}

static int IClientFriends_ClearChatHistory(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ClearChatHistory(*luaL_checksteamid(L, 2));
  return 0;
}

static int IClientFriends_ClearChatRoomHistory(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ClearChatRoomHistory(*luaL_checksteamid(L, 2));
  return 0;
}

static int IClientFriends_ClearRichPresence(lua_State *L) {
  luaL_checkclientfriends(L, 1)->ClearRichPresence((AppId_t)luaL_checkinteger(L, 2));
  return 0;
}

static int IClientFriends_ClearSerializedChatRoomDlg(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->ClearSerializedChatRoomDlg(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_CloseClanChatWindowInSteam(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->CloseClanChatWindowInSteam(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_CreateChatRoom(lua_State *L) {
  luaL_checkclientfriends(L, 1)->CreateChatRoom((EChatRoomType)luaL_checkinteger(L, 2), luaL_checkint64(L, 3), luaL_checkstring(L, 4), (ELobbyType)luaL_checkinteger(L, 5), *luaL_checksteamid(L, 6), *luaL_checksteamid(L, 7), *luaL_checksteamid(L, 8), (uint32)luaL_checkinteger(L, 9), (uint32)luaL_checkinteger(L, 10), (uint32)luaL_checkinteger(L, 11));
  return 0;
}

static int IClientFriends_CreateFriendsGroup(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->CreateFriendsGroup(luaL_checkstring(L, 2)));
  return 1;
}

static int IClientFriends_DeleteFriendRegValue(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->DeleteFriendRegValue(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int IClientFriends_DeleteFriendsGroup(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->DeleteFriendsGroup(luaL_checkinteger(L, 2)));
  return 1;
}

static int IClientFriends_EnableVoiceCalibration(lua_State *L) {
  luaL_checkclientfriends(L, 1)->EnableVoiceCalibration(luaL_checkboolean(L, 2));
  return 0;
}

static int IClientFriends_EnableVoiceNotificationSounds(lua_State *L) {
  luaL_checkclientfriends(L, 1)->EnableVoiceNotificationSounds(luaL_checkboolean(L, 2));
  return 0;
}

static int IClientFriends_EndChatRoomVoiceSpeaking(lua_State *L) {
  luaL_checkclientfriends(L, 1)->EndChatRoomVoiceSpeaking(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3));
  return 0;
}

// TODO: Add HVoiceCall
/*
static int IClientFriends_EndTalking(lua_State *L) {
  luaL_checkclientfriends(L, 1)->EndTalking(*luaL_checkvoicecall(L, 2));
  return 0;
}

static int IClientFriends_FindFriendVoiceChatHandle(lua_State *L) {
  HVoiceCall voicecall = luaL_checkclientfriends(L, 1)->FindFriendVoiceChatHandle(*luaL_checksteamid(L, 2));
  lua_pushvoicecall(L, &voicecall);
  return 1;
}

static int IClientFriends_GetCallState(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetCallState(*luaL_checkvoicecall(L, 2)));
  return 1;
}
*/

static int IClientFriends_GetChatMemberByIndex(lua_State *L) {
  CSteamID steamID = luaL_checkclientfriends(L, 1)->GetChatMemberByIndex(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int IClientFriends_GetChatMessage(lua_State *L) {
  char vData[2049] = {0};
  EChatEntryType msgType;
  CSteamID SteamIDChatter;
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetChatMessage(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3), &vData, 2049, &msgType, &SteamIDChatter));
  lua_pushstring(L, vData);
  lua_pushinteger(L, msgType);
  lua_pushsteamid(L, &SteamIDChatter);
  return 4;
}

static int IClientFriends_GetChatRoomByIndex(lua_State *L) {
  CSteamID steamID = luaL_checkclientfriends(L, 1)->GetChatRoomByIndex(luaL_checkinteger(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int IClientFriends_GetChatRoomCount(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetChatRoomCount());
  return 1;
}

static int IClientFriends_GetChatRoomEntry(lua_State *L) {
  char vData[2049] = {0};
  EChatEntryType msgType;
  CSteamID steamIDuser;
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetChatRoomEntry(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3), &steamIDuser, &vData, 2049, &msgType));
  lua_pushstring(L, vData);
  lua_pushinteger(L, msgType);
  lua_pushsteamid(L, &steamIDuser);
  return 4;
}

static int IClientFriends_GetChatRoomLockState(lua_State *L) {
  bool bLocked = false;
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->GetChatRoomLockState(*luaL_checksteamid(L, 2), &bLocked));
  lua_pushboolean(L, bLocked);
  return 2;
}

static int IClientFriends_GetChatRoomName(lua_State *L) {
  lua_pushstring(L, luaL_checkclientfriends(L, 1)->GetChatRoomName(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetChatRoomPeakSample(lua_State *L) {
  lua_pushnumber(L, luaL_checkclientfriends(L, 1)->GetChatRoomPeakSample(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3), luaL_checkboolean(L, 4)));
  return 1;
}

static int IClientFriends_GetChatRoomVoiceStatus(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetChatRoomVoiceStatus(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3)));
  return 1;
}

static int IClientFriends_GetChatRoomVoiceTotalSlotCount(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetChatRoomVoiceTotalSlotCount(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetChatRoomVoiceUsedSlot(lua_State *L) {
  CSteamID steamID = luaL_checkclientfriends(L, 1)->GetChatRoomVoiceUsedSlot(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int IClientFriends_GetChatRoomVoiceUsedSlotCount(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetChatRoomVoiceUsedSlotCount(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetClanActivityCounts(lua_State *L) {
  int nOnline, nInGame, nChatting = 0;
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->GetClanActivityCounts(*luaL_checksteamid(L, 2), &nOnline, &nInGame, &nChatting));
  lua_pushinteger(L, nOnline);
  lua_pushinteger(L, nInGame);
  lua_pushinteger(L, nChatting);
  return 4;
}

static int IClientFriends_GetClanByIndex(lua_State *L) {
  CSteamID steamID = luaL_checkclientfriends(L, 1)->GetClanByIndex(luaL_checkinteger(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int IClientFriends_GetClanChatMemberCount(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetClanChatMemberCount(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetClanChatMessage(lua_State *L) {
  char vData[2049] = {0};
  EChatEntryType msgType;
  CSteamID steamIDuser;
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetClanChatMessage(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3), &vData, 2049, &msgType, &steamIDuser));
  lua_pushstring(L, vData);
  lua_pushinteger(L, msgType);
  lua_pushsteamid(L, &steamIDuser);
  return 4;
}

static int IClientFriends_GetClanCount(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetClanCount());
  return 1;
}

static int IClientFriends_GetClanName(lua_State *L) {
  lua_pushstring(L, luaL_checkclientfriends(L, 1)->GetClanName(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetClanOfficerByIndex(lua_State *L) {
  CSteamID steamID = luaL_checkclientfriends(L, 1)->GetClanOfficerByIndex(*luaL_checksteamid(L, 2), luaL_checkinteger(L, 3));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int IClientFriends_GetClanOfficerCount(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetClanOfficerCount(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetClanOwner(lua_State *L) {
  CSteamID steamID = luaL_checkclientfriends(L, 1)->GetClanOwner(*luaL_checksteamid(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int IClientFriends_GetClanRelationship(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetClanRelationship(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetClanTag(lua_State *L) {
  lua_pushstring(L, luaL_checkclientfriends(L, 1)->GetClanTag(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_GetCoplayFriend(lua_State *L) {
  CSteamID steamID = luaL_checkclientfriends(L, 1)->GetCoplayFriend(luaL_checkinteger(L, 2));
  lua_pushsteamid(L, &steamID);
  return 1;
}

static int IClientFriends_GetCoplayFriendCount(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetCoplayFriendCount());
  return 1;
}

static int IClientFriends_GetFriendClanRank(lua_State *L) {
  lua_pushinteger(L, luaL_checkclientfriends(L, 1)->GetFriendClanRank(*luaL_checksteamid(L, 2), *luaL_checksteamid(L, 3)));
  return 1;
}

static int IClientFriends_GetFriendPersonaName(lua_State *L) {
  lua_pushstring(L, luaL_checkclientfriends(L, 1)->GetFriendPersonaName(*luaL_checksteamid(L, 2)));
  return 1;
}

static int IClientFriends_SendChatMsg(lua_State *L) {
  size_t l = 0;
  const char *vMsgBody = luaL_checklstring(L, 4, &l);
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->SendChatMsg(*luaL_checksteamid(L, 2), (EChatEntryType)luaL_checkinteger(L, 3), vMsgBody, l));
  return 1;
}

static int IClientFriends_SendClanChatMessage(lua_State *L) {
  lua_pushboolean(L, luaL_checkclientfriends(L, 1)->SendClanChatMessage(*luaL_checksteamid(L, 2), luaL_checkstring(L, 3)));
  return 1;
}

static int IClientFriends___tostring (lua_State *L) {
  lua_pushfstring(L, "IClientFriends: %p", luaL_checkclientfriends(L, 1));
  return 1;
}

static const luaL_Reg IClientFriendsmeta[] = {
  {"AcknowledgeInviteToClan", IClientFriends_AcknowledgeInviteToClan},
  {"ActivateGameOverlay", IClientFriends_ActivateGameOverlay},
  {"ActivateGameOverlayInviteDialog", IClientFriends_ActivateGameOverlayInviteDialog},
  {"ActivateGameOverlayToStore", IClientFriends_ActivateGameOverlayToStore},
  {"ActivateGameOverlayToUser", IClientFriends_ActivateGameOverlayToUser},
  {"ActivateGameOverlayToWebPage", IClientFriends_ActivateGameOverlayToWebPage},
  {"AddFriend", IClientFriends_AddFriend},
//{"AddFriendByName", IClientFriends_AddFriendByName},
  {"AddFriendToGroup", IClientFriends_AddFriendToGroup},
  {"BanChatMember", IClientFriends_BanChatMember},
//{"BCanReceive", IClientFriends_BCanReceive},
//{"BCanSend", IClientFriends_BCanSend},
  {"BChatRoomHasAvailableVoiceSlots", IClientFriends_BChatRoomHasAvailableVoiceSlots},
  {"BChatRoomModerated", IClientFriends_BChatRoomModerated},
  {"BIsChatRoomVoiceSpeaking", IClientFriends_BIsChatRoomVoiceSpeaking},
//{"BVoiceIsLocalOnHold", IClientFriends_BVoiceIsLocalOnHold},
//{"BVoiceIsRemoteOnHold", IClientFriends_BVoiceIsRemoteOnHold},
  {"CancelTradeRequest", IClientFriends_CancelTradeRequest},
  {"ChatRoomVoiceRetryConnections", IClientFriends_ChatRoomVoiceRetryConnections},
  {"ClearChatHistory", IClientFriends_ClearChatHistory},
  {"ClearChatRoomHistory", IClientFriends_ClearChatRoomHistory},
  {"ClearRichPresence", IClientFriends_ClearRichPresence},
  {"ClearSerializedChatRoomDlg", IClientFriends_ClearSerializedChatRoomDlg},
  {"CloseClanChatWindowInSteam", IClientFriends_CloseClanChatWindowInSteam},
  {"CreateChatRoom", IClientFriends_CreateChatRoom},
  {"CreateFriendsGroup", IClientFriends_CreateFriendsGroup},
  {"DeleteFriendRegValue", IClientFriends_DeleteFriendRegValue},
  {"DeleteFriendsGroup", IClientFriends_DeleteFriendsGroup},
  {"EnableVoiceCalibration", IClientFriends_EnableVoiceCalibration},
  {"EnableVoiceNotificationSounds", IClientFriends_EnableVoiceNotificationSounds},
  {"EndChatRoomVoiceSpeaking", IClientFriends_EndChatRoomVoiceSpeaking},
//{"EndTalking", IClientFriends_EndTalking},
//{"FindFriendVoiceChatHandle", IClientFriends_FindFriendVoiceChatHandle},
//{"GetCallState", IClientFriends_GetCallState},
  {"GetChatMemberByIndex", IClientFriends_GetChatMemberByIndex},
  {"GetChatMessage", IClientFriends_GetChatMessage},
  {"GetChatRoomByIndex", IClientFriends_GetChatRoomByIndex},
  {"GetChatRoomCount", IClientFriends_GetChatRoomCount},
  {"GetChatRoomEntry", IClientFriends_GetChatRoomEntry},
  {"GetChatRoomLockState", IClientFriends_GetChatRoomLockState},
  {"GetChatRoomName", IClientFriends_GetChatRoomName},
  {"GetChatRoomPeakSample", IClientFriends_GetChatRoomPeakSample},
  {"GetChatRoomVoiceStatus", IClientFriends_GetChatRoomVoiceStatus},
  {"GetChatRoomVoiceTotalSlotCount", IClientFriends_GetChatRoomVoiceTotalSlotCount},
  {"GetChatRoomVoiceUsedSlot", IClientFriends_GetChatRoomVoiceUsedSlot},
  {"GetChatRoomVoiceUsedSlotCount", IClientFriends_GetChatRoomVoiceUsedSlotCount},
  {"GetClanActivityCounts", IClientFriends_GetClanActivityCounts},
  {"GetClanByIndex", IClientFriends_GetClanByIndex},
  {"GetClanChatMemberCount", IClientFriends_GetClanChatMemberCount},
  {"GetClanChatMessage", IClientFriends_GetClanChatMessage},
  {"GetClanCount", IClientFriends_GetClanCount},
  {"GetClanName", IClientFriends_GetClanName},
  {"GetClanOfficerByIndex", IClientFriends_GetClanOfficerByIndex},
  {"GetClanOfficerCount", IClientFriends_GetClanOfficerCount},
  {"GetClanOwner", IClientFriends_GetClanOwner},
  {"GetClanRelationship", IClientFriends_GetClanRelationship},
  {"GetClanTag", IClientFriends_GetClanTag},
  {"GetCoplayFriend", IClientFriends_GetCoplayFriend},
  {"GetCoplayFriendCount", IClientFriends_GetCoplayFriendCount},
  {"GetFriendClanRank", IClientFriends_GetFriendClanRank},
  {"GetFriendPersonaName", IClientFriends_GetFriendPersonaName},
  {"SendChatMsg", IClientFriends_SendChatMsg},
  {"SendClanChatMessage", IClientFriends_SendClanChatMessage},
  {"__tostring", IClientFriends___tostring},
  {NULL, NULL}
};


/*
** Open IClientFriends object
*/
LUALIB_API int luaopen_IClientFriends(lua_State *L) {
  luaL_newmetatable(L, "IClientFriends");
  luaL_register(L, NULL, IClientFriendsmeta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "clientfriends");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "clientfriends" */
  lua_pop(L, 1);
  return 1;
}
#endif

