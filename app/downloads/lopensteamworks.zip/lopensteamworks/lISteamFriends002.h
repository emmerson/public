/*
* listeamfriends002.h
* ISteamFriends002 bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Jan 2012 11:20:00
* This code is hereby placed in the public domain.
*/

LUA_API ISteamFriends011     *(lua_tosteamfriends002) (lua_State *L, int idx);


LUA_API void  (lua_pushsteamfriends002) (lua_State *L, ISteamFriends002 *pSteamFriends);



LUALIB_API ISteamFriends011 *(luaL_checksteamfriends002) (lua_State *L, int narg);


int luaopen_ISteamFriends002(lua_State *L);


