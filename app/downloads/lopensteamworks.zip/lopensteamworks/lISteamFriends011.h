/*
* listeamfriends011.h
* ISteamFriends011 bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 25 Dec 2011 21:31:00
* This code is hereby placed in the public domain.
*/

LUA_API ISteamFriends011     *(lua_tosteamfriends011) (lua_State *L, int idx);


LUA_API void  (lua_pushsteamfriends011) (lua_State *L, ISteamFriends011 *pSteamFriends);



LUALIB_API ISteamFriends011 *(luaL_checksteamfriends011) (lua_State *L, int narg);


int luaopen_ISteamFriends011(lua_State *L);


