/*
* lsteamtypes.cpp
* SteamTypes bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Dec 2011 20:10:00
* This code is hereby placed in the public domain.
*/

#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lint64.h"
}
#include "lCSteamID.h"

/*
** access functions (stack -> C)
*/


LUA_API SteamAPICall_t *lua_tosteamapicall (lua_State *L, int idx) {
  SteamAPICall_t *pSteamAPICall_t = (SteamAPICall_t *)lua_touserdata(L, idx);
  return pSteamAPICall_t;
}


LUA_API HSteamPipe *lua_tosteampipe (lua_State *L, int idx) {
  HSteamPipe *phPipe = (HSteamPipe *)lua_touserdata(L, idx);
  return phPipe;
}


LUA_API HSteamUser *lua_tosteamuser (lua_State *L, int idx) {
  HSteamUser *phUser = (HSteamUser *)lua_touserdata(L, idx);
  return phUser;
}



/*
** push functions (C -> stack)
*/


LUA_API void lua_pushsteamapicall (lua_State *L, SteamAPICall_t *pSteamAPICall_t) {
  SteamAPICall_t *puSteamAPICall_t = (SteamAPICall_t *)lua_newuserdata(L, sizeof(SteamAPICall_t));
  *puSteamAPICall_t = *pSteamAPICall_t;
  luaL_getmetatable(L, "SteamAPICall_t");
  lua_setmetatable(L, -2);
}


LUA_API void lua_pushsteampipe (lua_State *L, HSteamPipe *phPipe) {
  HSteamPipe *pHandle = (HSteamPipe *)lua_newuserdata(L, sizeof(HSteamPipe));
  *pHandle = *phPipe;
  luaL_getmetatable(L, "HSteamPipe");
  lua_setmetatable(L, -2);
}


LUA_API void lua_pushsteamuser (lua_State *L, HSteamUser *phUser) {
  HSteamUser *pHandle = (HSteamUser *)lua_newuserdata(L, sizeof(HSteamUser));
  *pHandle = *phUser;
  luaL_getmetatable(L, "HSteamUser");
  lua_setmetatable(L, -2);
}


LUALIB_API HSteamPipe *luaL_checksteampipe (lua_State *L, int narg) {
  HSteamPipe *d = (HSteamPipe *)luaL_checkudata(L, narg, "HSteamPipe");
  return d;
}


LUALIB_API HSteamUser *luaL_checksteamuser (lua_State *L, int narg) {
  HSteamUser *d = (HSteamUser *)luaL_checkudata(L, narg, "HSteamUser");
  return d;
}


LUA_API void lua_setcallbackmsg (lua_State *L, int idx, CallbackMsg_t *pcallBack) {
  idx = idx - 1;
  lua_pushsteamuser(L, &pcallBack->m_hSteamUser);
  lua_setfield(L, idx, "m_hSteamUser");
  lua_pushinteger(L, pcallBack->m_iCallback);
  lua_setfield(L, idx, "m_iCallback");
  lua_newtable(L);
  switch (pcallBack->m_iCallback) {
  case SteamServersConnected_t::k_iCallback:
  case SteamServerConnectFailure_t::k_iCallback:
	{
	  SteamServerConnectFailure_t *pConnectFailureInfo = (SteamServerConnectFailure_t *)pcallBack->m_pubParam;
	  lua_pushinteger(L, pConnectFailureInfo->m_eResult);
	  lua_setfield(L, -2, "m_eResult");
	  break;
	}
  case PersonaStateChange_t::k_iCallback:
	{
	  PersonaStateChange_t *pPersonaStateChange = (PersonaStateChange_t *)pcallBack->m_pubParam;

	  CSteamID ulSteamID = pPersonaStateChange->m_ulSteamID;
	  lua_pushsteamid(L, &ulSteamID);
	  lua_setfield(L, -2, "m_ulSteamID");
	  lua_pushinteger(L, pPersonaStateChange->m_nChangeFlags);
	  lua_setfield(L, -2, "m_nChangeFlags");
	  break;
	}
  case FriendChatMsg_t::k_iCallback:
	{
	  FriendChatMsg_t *pFriendMessageInfo = (FriendChatMsg_t *)pcallBack->m_pubParam;

	  CSteamID ulFriendID = pFriendMessageInfo->m_ulFriendID;
	  lua_pushsteamid(L, &ulFriendID);
	  lua_setfield(L, -2, "m_ulFriendID");
	  CSteamID ulSenderID = pFriendMessageInfo->m_ulSenderID;
	  lua_pushsteamid(L, &ulSenderID);
	  lua_setfield(L, -2, "m_ulSenderID");
	  lua_pushinteger(L, pFriendMessageInfo->m_eChatEntryType);
	  lua_setfield(L, -2, "m_eChatEntryType");
	  lua_pushinteger(L, pFriendMessageInfo->m_bLimitedAccount);
	  lua_setfield(L, -2, "m_bLimitedAccount");
	  lua_pushinteger(L, pFriendMessageInfo->m_iChatID);
	  lua_setfield(L, -2, "m_iChatID");
	  break;
	}
  case ChatRoomEnter_t::k_iCallback:
	{
	  ChatRoomEnter_t *pChatRoomEnter = (ChatRoomEnter_t *)pcallBack->m_pubParam;

	  // Andrew; this seems to crash. Does the structure need to be reverse
	  // engineered again?
	  /*
	  CSteamID ulSteamIDChat = pChatRoomEnter->m_ulSteamIDChat;
	  lua_pushsteamid(L, &ulSteamIDChat);
	  lua_setfield(L, -2, "m_ulSteamIDChat");
	  */

	  lua_pushinteger(L, pChatRoomEnter->m_EChatRoomType);
	  lua_setfield(L, -2, "m_EChatRoomType");

	  lua_pushint64(L, pChatRoomEnter->m_ulSteamIDOwner);
	  lua_setfield(L, -2, "m_ulSteamIDOwner");
	  // Andrew; this too
	  /*
	  CSteamID ulSteamIDClan = pChatRoomEnter->m_ulSteamIDClan;
	  lua_pushsteamid(L, &ulSteamIDClan);
	  lua_setfield(L, -2, "m_ulSteamIDClan");
	  */
	  CSteamID ulSteamIDFriendChat = pChatRoomEnter->m_ulSteamIDFriendChat;
	  lua_pushsteamid(L, &ulSteamIDFriendChat);
	  lua_setfield(L, -2, "m_ulSteamIDFriendChat");

	  lua_pushboolean(L, pChatRoomEnter->m_bLocked);
	  lua_setfield(L, -2, "m_bLocked");
	  lua_pushinteger(L, pChatRoomEnter->m_rgfChatPermissions);
	  lua_setfield(L, -2, "m_rgfChatPermissions");
	  lua_pushinteger(L, pChatRoomEnter->m_EChatRoomEnterResponse);
	  lua_setfield(L, -2, "m_EChatRoomEnterResponse");

	  lua_pushstring(L, pChatRoomEnter->m_rgchChatRoomName);
	  lua_setfield(L, -2, "m_rgchChatRoomName");
	  break;
	}
  case ChatRoomMsg_t::k_iCallback:
	{
	  ChatRoomMsg_t *pChatRoomMsg = (ChatRoomMsg_t *)pcallBack->m_pubParam;

	  CSteamID ulSteamIDChat = pChatRoomMsg->m_ulSteamIDChat;
	  lua_pushsteamid(L, &ulSteamIDChat);
	  lua_setfield(L, -2, "m_ulSteamIDChat");
	  CSteamID ulSteamIDUser = pChatRoomMsg->m_ulSteamIDUser;
	  lua_pushsteamid(L, &ulSteamIDUser);
	  lua_setfield(L, -2, "m_ulSteamIDUser");
	  lua_pushinteger(L, pChatRoomMsg->m_eChatEntryType);
	  lua_setfield(L, -2, "m_eChatEntryType");
	  lua_pushinteger(L, pChatRoomMsg->m_iChatID);
	  lua_setfield(L, -2, "m_iChatID");
	  break;
	}
  case ClanInfoChanged_t::k_iCallback:
	{
	  ClanInfoChanged_t *pClanInfoChanged = (ClanInfoChanged_t *)pcallBack->m_pubParam;
	  CSteamID ulSteamID = pClanInfoChanged->m_ulSteamID;
	  lua_pushsteamid(L, &ulSteamID);
	  lua_setfield(L, -2, "m_ulSteamID");

	  lua_pushboolean(L, pClanInfoChanged->m_bNameChanged);
	  lua_setfield(L, -2, "m_bNameChanged");
	  lua_pushboolean(L, pClanInfoChanged->m_bAvatarChanged);
	  lua_setfield(L, -2, "m_bAvatarChanged");
	  lua_pushboolean(L, pClanInfoChanged->m_bAccountInfoChanged);
	  lua_setfield(L, -2, "m_bAccountInfoChanged");
	  break;
	}
  }
  lua_setfield(L, idx, "m_pubParam");
  lua_pushinteger(L, pcallBack->m_cubParam);
  lua_setfield(L, idx, "m_cubParam");
}


static int HSteamPipe___eq (lua_State *L) {
  HSteamPipe a = *lua_tosteampipe(L, 1);
  HSteamPipe b = *lua_tosteampipe(L, 2);
  lua_pushboolean(L, (int)(a == b) );
  return 1;
}

static int HSteamPipe___tostring (lua_State *L) {
  lua_pushfstring(L, "HSteamPipe: %d", *lua_tosteampipe(L, 1));
  return 1;
}


static const luaL_Reg HSteamPipemeta[] = {
  {"__eq", HSteamPipe___eq},
  {"__tostring", HSteamPipe___tostring},
  {NULL, NULL}
};


static int lopensteamworks_HSteamPipe (lua_State *L) {
  HSteamPipe hPipe = (HSteamPipe)NULL;
  lua_pushsteampipe(L, &hPipe);
  return 1;
}


static const luaL_Reg HSteamPipe_funcs[] = {
  {"HSteamPipe", lopensteamworks_HSteamPipe},
  {NULL, NULL}
};


/*
** Open HSteamPipe object
*/
int luaopen_HSteamPipe(lua_State *L) {
  luaL_newmetatable(L, "HSteamPipe");
  luaL_register(L, NULL, HSteamPipemeta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "steampipe");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "steampipe" */
  luaL_register(L, "_G", HSteamPipe_funcs);
  lua_pop(L, 2);
  return 1;
}


static int HSteamUser___eq (lua_State *L) {
  HSteamUser a = *lua_tosteamuser(L, 1);
  HSteamUser b = *lua_tosteamuser(L, 2);
  lua_pushboolean(L, (int)(a == b) );
  return 1;
}

static int HSteamUser___tostring (lua_State *L) {
  lua_pushfstring(L, "HSteamUser: %d", *(HSteamUser *)lua_tosteamuser(L, 1));
  return 1;
}


static const luaL_Reg HSteamUsermeta[] = {
  {"__eq", HSteamUser___eq},
  {"__tostring", HSteamUser___tostring},
  {NULL, NULL}
};


static int lopensteamworks_HSteamUser (lua_State *L) {
  HSteamUser hUser = (HSteamUser)NULL;
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static const luaL_Reg HSteamUser_funcs[] = {
  {"HSteamUser", lopensteamworks_HSteamUser},
  {NULL, NULL}
};


/*
** Open HSteamUser object
*/
int luaopen_HSteamUser(lua_State *L) {
  luaL_newmetatable(L, "HSteamUser");
  luaL_register(L, NULL, HSteamUsermeta);
  lua_pushvalue(L, -1);  /* push metatable */
  lua_setfield(L, -2, "__index");  /* metatable.__index = metatable */
  lua_pushstring(L, "steamuser");
  lua_setfield(L, -2, "__type");  /* metatable.__type = "steamuser" */
  luaL_register(L, "_G", HSteamUser_funcs);
  lua_pop(L, 2);
  return 1;
}

