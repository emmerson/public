/*
* liclientengine.cpp
* IClientEngine bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Dec 2011 20:10:00
* This code is hereby placed in the public domain.
*/

#ifdef STEAMWORKS_CLIENT_INTERFACES
#include "Steamworks.h"

#include "lua.hpp"
extern "C" {
	#include "lauxlibex.h"
}
#include "lSteamTypes.h"
#include "lIClientFriends.h"

IClientEngine *pClientEngine;

static int IClientEngine_BOverlayNeedsPresent(lua_State *L) {
  lua_pushboolean(L, pClientEngine->BOverlayNeedsPresent());
  return 1;
}

static int IClientEngine_BReleaseSteamPipe(lua_State *L) {
  lua_pushboolean(L, pClientEngine->BReleaseSteamPipe(*luaL_checksteampipe(L, 1)));
  return 1;
}

static int IClientEngine_BShutdownIfAllPipesClosed(lua_State *L) {
  lua_pushboolean(L, pClientEngine->BShutdownIfAllPipesClosed());
  return 1;
}

static int IClientEngine_ConnectToGlobalUser(lua_State *L) {
  HSteamUser hUser = pClientEngine->ConnectToGlobalUser(*luaL_checksteampipe(L, 1));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int IClientEngine_CreateGlobalUser(lua_State *L) {
  HSteamUser hUser = pClientEngine->CreateGlobalUser(luaL_checksteampipe(L, 1));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int IClientEngine_CreateLocalUser(lua_State *L) {
  HSteamUser hUser = pClientEngine->CreateLocalUser(luaL_checksteampipe(L, 1), (EAccountType)luaL_checkinteger(L, 2));
  lua_pushsteamuser(L, &hUser);
  return 1;
}

static int IClientEngine_CreateSteamPipe(lua_State *L) {
  HSteamPipe hPipe = pClientEngine->CreateSteamPipe();
  lua_pushsteampipe(L, &hPipe);
  return 1;
}

static int IClientEngine_GetIClientFriends(lua_State *L) {
  lua_pushclientfriends(L, pClientEngine->GetIClientFriends(*luaL_checksteamuser(L, 1), *luaL_checksteampipe(L, 2), CLIENTFRIENDS_INTERFACE_VERSION));
  return 1;
}

static int IClientEngine_GetIPCCallCount(lua_State *L) {
  lua_pushinteger(L, pClientEngine->GetIPCCallCount());
  return 1;
}

static int IClientEngine_GetUniverseName(lua_State *L) {
  lua_pushstring(L, pClientEngine->GetUniverseName((EUniverse)luaL_checkinteger(L, 1)));
  return 1;
}

static int IClientEngine_HookScreenshots(lua_State *L) {
  lua_pushboolean(L, pClientEngine->HookScreenshots(luaL_checkboolean(L, 1)));
  return 1;
}

static int IClientEngine_IsOverlayEnabled(lua_State *L) {
  lua_pushboolean(L, pClientEngine->IsOverlayEnabled());
  return 1;
}

static int IClientEngine_IsValidHSteamUserPipe(lua_State *L) {
  lua_pushboolean(L, pClientEngine->IsValidHSteamUserPipe(*luaL_checksteampipe(L, 1), *luaL_checksteamuser(L, 2)));
  return 1;
}

static int IClientEngine_ReleaseUser(lua_State *L) {
  pClientEngine->ReleaseUser(*luaL_checksteampipe(L, 1), *luaL_checksteamuser(L, 2));
  return 0;
}

static int IClientEngine_RunFrame(lua_State *L) {
  pClientEngine->RunFrame();
  return 0;
}

static int IClientEngine_SetLocalIPBinding(lua_State *L) {
  pClientEngine->SetLocalIPBinding((uint32)luaL_checkinteger(L, 1), (uint16)luaL_checkinteger(L, 2));
  return 0;
}

static int IClientEngine_SetOverlayNotificationPosition(lua_State *L) {
  pClientEngine->SetOverlayNotificationPosition((ENotificationPosition)luaL_checkinteger(L, 1));
  return 0;
}

static const luaL_Reg IClientEnginelib[] = {
  {"BOverlayNeedsPresent", IClientEngine_BOverlayNeedsPresent},
  {"BReleaseSteamPipe", IClientEngine_BReleaseSteamPipe},
  {"BShutdownIfAllPipesClosed", IClientEngine_BShutdownIfAllPipesClosed},
  {"ConnectToGlobalUser", IClientEngine_ConnectToGlobalUser},
  {"CreateGlobalUser", IClientEngine_CreateGlobalUser},
  {"CreateLocalUser", IClientEngine_CreateLocalUser},
  {"CreateSteamPipe", IClientEngine_CreateSteamPipe},
  {"GetIClientFriends", IClientEngine_GetIClientFriends},
  {"GetIPCCallCount", IClientEngine_GetIPCCallCount},
  {"GetUniverseName", IClientEngine_GetUniverseName},
  {"HookScreenshots", IClientEngine_HookScreenshots},
  {"IsOverlayEnabled", IClientEngine_IsOverlayEnabled},
  {"IsValidHSteamUserPipe", IClientEngine_IsValidHSteamUserPipe},
  {"ReleaseUser", IClientEngine_ReleaseUser},
  {"RunFrame", IClientEngine_RunFrame},
  {"SetLocalIPBinding", IClientEngine_SetLocalIPBinding},
  {"SetOverlayNotificationPosition", IClientEngine_SetOverlayNotificationPosition},
  {NULL, NULL}
};


/*
** Open IClientEngine library
*/
LUALIB_API int luaopen_IClientEngine(lua_State *L, CreateInterfaceFn factory) {
  pClientEngine = (IClientEngine *)factory( CLIENTENGINE_INTERFACE_VERSION, NULL );
  if ( !pClientEngine )
  {
	  printf("Unable to get the client engine.\n");
	  return 0;
  }
  luaL_register(L, "IClientEngine", IClientEnginelib);
  lua_pop(L, 1);
  return 1;
}
#endif

