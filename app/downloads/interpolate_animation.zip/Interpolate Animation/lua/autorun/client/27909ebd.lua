
local vecPosition = vec3_origin

hook.Add( "CalcView", "InterpolateAnimation", function( player, origin, angles, fov )

	if ( GetViewEntity() == player ) then
		return;
	end

	vecPosition = vecPosition + ( ( player:GetPos() - vecPosition ) / 2 )

	player:SetPos( vecPosition )

end )

hook.Add( "Move", "InterpolateMovement", function( ply )

	vecPosition = ply:GetPos()

end )

