

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_watermelon.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_watermelon.vtf" )

	AddCSLuaFile( "shared.lua" )

	SWEP.HoldType			= "grenade"

end

if ( CLIENT ) then

	language.Add( "HL2_Watermelon", "WATERMELON" )

	SWEP.PrintName			= "#HL2_Watermelon"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "9"

	killicon.AddFont( "prop_physics_multiplayer", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:DrawWorldModel()

		local pPlayer = self.Owner;

		if ( !ValidEntity( pPlayer ) ) then
			self.Weapon:DrawModel();
			return;
		end

		if ( !self.m_hHands ) then
			self.m_hHands = pPlayer:LookupAttachment( "anim_attachment_rh" );
		end

		local hand = pPlayer:GetAttachment( self.m_hHands );

		local offset = hand.Ang:Right() * self.HoldPos.x + hand.Ang:Forward() * self.HoldPos.y + hand.Ang:Up() * self.HoldPos.z;

		hand.Ang:RotateAroundAxis( hand.Ang:Right(),	self.HoldAng.x );
		hand.Ang:RotateAroundAxis( hand.Ang:Forward(),	self.HoldAng.y );
		hand.Ang:RotateAroundAxis( hand.Ang:Up(),		self.HoldAng.z );

		self.Weapon:SetRenderOrigin( hand.Pos + offset )
		self.Weapon:SetRenderAngles( hand.Ang )

		self.Weapon:DrawModel()

	end

end


SWEP.Base				= "swep_frag"
SWEP.Category			= SWEP.Author

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.ViewModel			= ""
SWEP.WorldModel			= "models/props_junk/watermelon01.mdl"

SWEP.Primary.AmmoType		= "prop_physics_multiplayer"
SWEP.Primary.AmmoModel		= SWEP.WorldModel

SWEP.HoldPos 			= Vector( -7, 0, 1 )
SWEP.HoldAng			= Vector( 0, 73, 0 )

function SWEP:ThrowGrenade( pPlayer )

	if ( self.m_bRedraw ) then
		return;
	end

if ( !CLIENT ) then
	if ( GAMEMODE.IsSandboxDerived ) then

		if ( !pPlayer:CheckLimit( "props" ) ) then return false end

	end

	local	vecEye = pPlayer:EyePos();
	local	vForward, vRight;

	vForward = pPlayer:GetForward();
	vRight = pPlayer:GetRight();
	local vecSrc = vecEye + vForward * 18.0 + vRight * 8.0;
	self:CheckThrowPosition( pPlayer, vecEye, vecSrc );

	local vecThrow;
	vecThrow = pPlayer:GetVelocity();
	vecThrow = vecThrow + vForward * 1200;
	local pGrenade = ents.Create( self.Primary.AmmoType );
	pGrenade:SetPos( vecSrc );
	pGrenade:SetModel( self.Primary.AmmoModel );
	pGrenade:SetAngles( vec3_angle );
	pGrenade:SetPhysicsAttacker( pPlayer );
	pGrenade:SetOwner( pPlayer );
	pGrenade:Fire( "SetTimer", GRENADE_TIMER );
	pGrenade:Spawn()
	pGrenade:GetPhysicsObject():SetVelocity( vecThrow );
	pGrenade:GetPhysicsObject():SetMass( self.Primary.Damage );
	pGrenade:GetPhysicsObject():AddAngleVelocity( Angle(600,math.random(-1200,1200),0) );

	if ( pGrenade ) then
		if ( pPlayer && !pPlayer:Alive() ) then
			vecThrow = pPlayer:GetVelocity();

			local pPhysicsObject = pGrenade:GetPhysicsObject();
			if ( pPhysicsObject ) then
				vecThrow = pPhysicsObject:SetVelocity();
			end
		end

		pGrenade.m_flDamage = self.Primary.Damage;
		pGrenade.m_DmgRadius = GRENADE_DAMAGE_RADIUS;
	end

	if ( GAMEMODE.IsSandboxDerived ) then

		undo.Create("Prop")
			undo.AddEntity( pGrenade )
			undo.SetPlayer( pPlayer )
		undo.Finish()

		pPlayer:AddCleanup( "props", pGrenade )
		pPlayer:AddCount( "props", pGrenade )

	end
end

	self.m_bRedraw = true;

	self.Weapon:EmitSound( self.Primary.Sound );

	pPlayer:SetAnimation( PLAYER_ATTACK1 );

end

function SWEP:CanSecondaryAttack()
	return false
end
