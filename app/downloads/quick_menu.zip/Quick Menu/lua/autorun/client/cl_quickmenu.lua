
include( "hud_functions.lua" )

local function CHudQuickMenu()

	local player	= LocalPlayer()

	if ( !player:Alive() ) then return end

	// Ask the gamemode if it's ok to do this
	if ( !gamemode.Call( "HUDShouldDraw", "CHudQuickMenu" ) ) then return end

	local text_font	= "HudHintTextSmall"

	surface.SetFont( text_font )

	local SELECTION	= 1

	local xpos		= ScrW() / 2
	local ypos		= ScrH() / 2
	local wide		= surface.SScale( 32 )
	xpos			= xpos - wide / 2
	local tall		= wide
	ypos			= ypos - tall / 2 - tall
	ypos			= ypos - surface.SScale( 4 )

	draw.RoundedBox( 8, xpos, ypos, wide, tall, Panel.BgColor )

	local text_xpos	= xpos + surface.SScale( 4 )
	local text_ypos	= ypos + surface.SScale( 4 )

	draw.DrawText( SELECTION, text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )
	SELECTION		= SELECTION + 1

	xpos			= xpos + surface.SScale( 32 ) + surface.SScale( 8 )
	ypos			= ypos + surface.SScale( 32 ) + surface.SScale( 4 )

	draw.RoundedBox( 8, xpos, ypos, wide, tall, Panel.BgColor )

	text_xpos		= xpos + surface.SScale( 4 )
	text_ypos		= ypos + surface.SScale( 4 )

	draw.DrawText( SELECTION, text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )
	SELECTION		= SELECTION + 1

	xpos			= xpos - surface.SScale( 32 ) + surface.SScale( 12 )
	ypos			= ypos + surface.SScale( 32 ) + surface.SScale( 8 )

	draw.RoundedBox( 8, xpos, ypos, wide, tall, Panel.BgColor )

	text_xpos		= xpos + surface.SScale( 4 )
	text_ypos		= ypos + surface.SScale( 4 )

	draw.DrawText( SELECTION, text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )
	SELECTION		= SELECTION + 1

	xpos			= xpos - surface.SScale( 32 ) - surface.SScale( 8 )

	draw.RoundedBox( 8, xpos, ypos, wide, tall, Panel.BgColor )

	text_xpos		= xpos + surface.SScale( 4 )
	text_ypos		= ypos + surface.SScale( 4 )

	draw.DrawText( SELECTION, text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )
	SELECTION		= SELECTION + 1

	xpos			= xpos - surface.SScale( 16 ) - surface.SScale( 4 )
	ypos			= ypos - surface.SScale( 32 ) - surface.SScale( 8 )

	draw.RoundedBox( 8, xpos, ypos, wide, tall, Panel.BgColor )

	text_xpos		= xpos + surface.SScale( 4 )
	text_ypos		= ypos + surface.SScale( 4 )

	draw.DrawText( SELECTION, text_font, text_xpos, text_ypos, Panel.FgColor, TEXT_ALIGN_LEFT )

end

hook.Add( "HUDPaint", "CHudQuickMenu", CHudQuickMenu )

