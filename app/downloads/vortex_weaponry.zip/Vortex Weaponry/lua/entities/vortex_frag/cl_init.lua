
include('shared.lua')

/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	self.CanConstrain		= false
	self.CanTool			= false
	self.GravGunPunt		= false
	self.PhysgunDisabled	= true

	self.Entity:DrawShadow( false )

end

/*---------------------------------------------------------
   Name: DrawPre
---------------------------------------------------------*/
function ENT:Draw()

	self.EaseInOutProgress		= self.EaseInOutProgress || 0

	if ( !self.Entity:GetNetworkedBool( "m_bTriggered" ) ) then
		self.EaseInOutProgress	= math.Clamp( self.EaseInOutProgress + FrameTime() * 4.0, 0, 1.0 )
	else
		self.EaseInOutProgress	= math.Clamp( self.EaseInOutProgress - FrameTime() * 4.0, 0, 1.0 )
	end

	self.EaseInOutScale			= math.EaseInOut( self.EaseInOutProgress, 1.01, 16.001 )
	self.EaseInOutScale			= self.EaseInOutScale / 10

	self.Entity:SetModelScale( Vector( self.EaseInOutScale, self.EaseInOutScale, self.EaseInOutScale ) )
	self.Entity:DrawModel()

end

/*---------------------------------------------------------
   Name: Think
---------------------------------------------------------*/
function ENT:Think()

	local r, g, b, a = self:GetColor()

	local dlight = DynamicLight( self:EntIndex() )
	if ( dlight ) then
		dlight.Pos = self:GetPos()
		dlight.r = r
		dlight.g = g
		dlight.b = b
		dlight.Brightness = 2
		dlight.Decay = 128 * 5
		dlight.Size = 128
		dlight.DieTime = CurTime() + 1
	end

	if ( self.Entity:GetNetworkedBool( "m_bTriggered" ) ) then

		local dlight = DynamicLight( self:EntIndex() )
		if ( dlight ) then
			dlight.Pos = self.Entity:LocalToWorld( self.Entity:OBBCenter() )
			dlight.r = r
			dlight.g = g
			dlight.b = b
			dlight.Brightness = 1
			dlight.Decay = 128 * 5
			dlight.Size = 128
			dlight.DieTime = CurTime() + 0.33
		end

	end

end

