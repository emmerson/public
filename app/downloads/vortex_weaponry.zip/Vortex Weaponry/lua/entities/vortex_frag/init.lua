
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

local Postblast_Sound = Sound( "ambient/levels/citadel/portal_beam_shoot4.wav" )


/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	self.m_tEffectedEntities	= {}
	self.m_flNextSpawnTime		= CurTime() + 0.33;

	// Use the portal rift model just for the plane (because it's about the right look)
	self.Entity:SetModel( "models/Effects/portalrift.mdl" )

	// Don't use the model's physics - create a sphere instead
	self.Entity:PhysicsInitSphere( 32, "gmod_silent" )

	self.CanConstrain		= false
	self.CanTool			= false
	self.GravGunPunt		= false
	self.PhysgunDisabled	= true

	self.Entity:DrawShadow( false )

	// Put the physics object to sleep. It's time to rest.
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:EnableMotion( false )
		phys:Sleep()
	end

	// Set collision bounds exactly
	self.Entity:SetCollisionBounds( Vector( -32, -32, -32 ), Vector( 32, 32, 32 ) )
	self.Entity:SetCollisionGroup( COLLISION_GROUP_WEAPON )

	self.RenderTargetCamera = ents.Create( "point_camera" )
	self.RenderTargetCamera:SetKeyValue( "GlobalOverride", 1 )
	self.RenderTargetCamera:Spawn()
	self.RenderTargetCamera:Activate()
	self.RenderTargetCamera:Fire( "SetOn", "", 0.0 )

	local Pos = self.Entity:LocalToWorld( self.Entity:OBBCenter() )
	self.RenderTargetCamera:SetPos(Pos)
	self.RenderTargetCamera:SetAngles(self.Entity:GetAngles() + Angle( 90, 0, 0 ) )
	self.RenderTargetCamera:SetParent(self.Entity)

end

/*---------------------------------------------------------
   Name: StartTouch
---------------------------------------------------------*/
function ENT:StartTouch( entity )
end

/*---------------------------------------------------------
   Name: EndTouch
---------------------------------------------------------*/
function ENT:EndTouch( entity )
end

/*---------------------------------------------------------
   Name: Touch
---------------------------------------------------------*/
function ENT:Touch( entity )
end

/*---------------------------------------------------------
   Name: Think
---------------------------------------------------------*/
function ENT:Think()

	hook.Add( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")", function()

		local pPlayer = self:GetOwner();

		if ( !pPlayer ) then
			return;
		end

		if ( pPlayer.m_tVortexEntities ) then

			if ( #pPlayer.m_tVortexEntities <= 0 ) then

				if ( !self.m_bTriggered ) then

					self.m_bTriggered		= true;
					self.m_flVortexDuration	= CurTime() + SoundDuration( Postblast_Sound )

				end

			else

				for k, v in pairs( pPlayer.m_tVortexEntities ) do

					if ( CurTime() > self.m_flNextSpawnTime ) then

						table.remove( pPlayer.m_tVortexEntities, k )

						local phys = duplicator.GenericDuplicatorFunction( pPlayer, v )

						phys:SetPos( self.Entity:LocalToWorld( self.Entity:OBBCenter() ) + ( self.Entity:GetUp() * -8.0 ) )

						if ( GAMEMODE.IsSandboxDerived ) then

							undo.Create("Duplicator")
								undo.AddEntity( phys )
								undo.SetPlayer( pPlayer )
							undo.Finish()

						end

						self.m_flNextSpawnTime = CurTime() + 0.01

					end

				end

			end

		else

			if ( !self.m_bTriggered ) then

				self.m_bTriggered		= true;
				self.m_flVortexDuration	= CurTime() + SoundDuration( Postblast_Sound )

			end

		end

		if ( self.m_bTriggered ) then

			if ( CurTime() > self.m_flVortexDuration ) then

				self.m_bTriggered = nil

				self.Entity:SetNetworkedBool( "m_bTriggered", true )
				self.m_flSequenceDuration = CurTime() + 0.33

			end

		end

		if ( self.Entity:GetNetworkedBool( "m_bTriggered" ) ) then

			if ( CurTime() > self.m_flSequenceDuration ) then

				for k, v in pairs( self.m_tEffectedEntities ) do

					if ( v && v:IsValid() ) then

						if ( v:GetClass() == "prop_ragdoll" ) then

							for i = 1, v:GetPhysicsObjectCount() do

								local phys = v:GetPhysicsObjectNum( i )
								if (phys && phys:IsValid()) then
									phys:EnableGravity( true )
								end

							end

						else

							local phys = v:GetPhysicsObject()
							if (phys:IsValid()) then
								phys:EnableGravity( true )
							end

						end

					else

						table.remove( self.m_tEffectedEntities, k )

					end

				end

				hook.Remove( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")" )

				self.Entity:Remove()

				return

			end

		else

			local Pos1 = self.Entity:LocalToWorld( self.Entity:OBBCenter() )
			local Pos2

			local Distance

			for k, v in pairs( ents.FindInSphere( Pos1, 128 ) ) do

				if ( ( v != self.Entity ) && ( v:GetClass() != self.Entity:GetClass() ) ) then

					if ( v:GetClass() != "sent_grenade_vortex" ) then

						Pos2 = v:LocalToWorld( v:OBBCenter() )

						Distance = Pos1:Distance( Pos2 )

						if ( v:GetClass() == "prop_ragdoll" ) then

							for i = 1, v:GetPhysicsObjectCount() do

								local phys = v:GetPhysicsObjectNum( i )
								if (phys && phys:IsValid()) then
									phys:EnableGravity( false )
									phys:ApplyForceCenter( ( Pos2 - Pos1 ) * Distance )
									phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
								end

							end

						else

							local phys = v:GetPhysicsObject()
							if (phys:IsValid()) then
								phys:EnableGravity( false )
								phys:ApplyForceCenter( ( Pos2 - Pos1 ) * Distance )
								phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
							end

						end

						v:SetPhysicsAttacker( self:GetOwner() )

					end

				end

			end

		end

		for k, v in pairs( ents.FindInSphere( self.Entity:LocalToWorld( self.Entity:OBBCenter() ), 512 ) ) do

			if ( ( v != self.Entity ) && ( v:GetClass() != self.Entity:GetClass() ) ) then

				if ( v:GetClass() != "sent_grenade_vortex" ) then

					if ( v:GetClass() == "prop_ragdoll" ) then

						for i = 1, v:GetPhysicsObjectCount() do

							local phys = v:GetPhysicsObjectNum( i )
							if (phys && phys:IsValid()) then
								phys:EnableGravity( false )
								phys:SetVelocity( phys:GetVelocity() - phys:GetVelocity() / 14 )
								phys:SetAngleVelocity( phys:GetAngleVelocity() - phys:GetAngleVelocity() / 14 )
							end

						end

					else

						local phys = v:GetPhysicsObject()
						if (phys:IsValid()) then
							phys:EnableGravity( false )
							phys:SetVelocity( phys:GetVelocity() - phys:GetVelocity() / 14 )
							phys:SetAngleVelocity( phys:GetAngleVelocity() - phys:GetAngleVelocity() / 14 )
						end

					end

					table.insert( self.m_tEffectedEntities, v )

				end

			end

		end

	end )

end



