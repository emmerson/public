
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

local Preblast_Sound = Sound( "ambient/levels/labs/teleport_preblast_suckin1.wav" )


/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	self.m_tEffectedEntities = {};

	// Use the portal rift model just for the plane (because it's about the right look)
	self.Entity:SetModel( "models/Effects/portalrift.mdl" )

	// Don't use the model's physics - create a sphere instead
	self.Entity:PhysicsInitSphere( 32, "gmod_silent" )

	self.CanConstrain		= false
	self.CanTool			= false
	self.GravGunPunt		= false
	self.PhysgunDisabled	= true

	self.Entity:DrawShadow( false )

	// Put the physics object to sleep. It's time to rest.
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:EnableMotion( false )
		phys:Sleep()
	end

	// Set collision bounds exactly
	self.Entity:SetCollisionBounds( Vector( -32, -32, -32 ), Vector( 32, 32, 32 ) )
	self.Entity:SetCollisionGroup( COLLISION_GROUP_WEAPON )

	self.RenderTargetCamera = ents.Create( "point_camera" )
	self.RenderTargetCamera:SetKeyValue( "GlobalOverride", 1 )
	self.RenderTargetCamera:Spawn()
	self.RenderTargetCamera:Activate()
	self.RenderTargetCamera:Fire( "SetOn", "", 0.0 )

	local Pos = self.Entity:LocalToWorld( self.Entity:OBBCenter() )
	self.RenderTargetCamera:SetPos(Pos)
	self.RenderTargetCamera:SetAngles(self.Entity:GetAngles() + Angle( 90, 0, 0 ) )
	self.RenderTargetCamera:SetParent(self.Entity)

end

/*---------------------------------------------------------
   Name: StartTouch
---------------------------------------------------------*/
function ENT:StartTouch( entity )

	constraint.NoCollide( entity, self.Entity, 0, 0 )

	local mins = entity:LocalToWorld( entity:OBBMins() * 3.3 )
	local maxs = entity:LocalToWorld( entity:OBBMaxs() * 3.3 )
	mins:Rotate( entity:GetAngles() )
	maxs:Rotate( entity:GetAngles() )

	for k, v in pairs( ents.FindInBox( mins, maxs ) ) do

		constraint.NoCollide( v, entity, 0, 0 )

	end

end

/*---------------------------------------------------------
   Name: EndTouch
---------------------------------------------------------*/
function ENT:EndTouch( entity )
end

/*---------------------------------------------------------
   Name: Touch
---------------------------------------------------------*/
function ENT:Touch( entity )

	local pPlayer = self:GetOwner();

	if ( !pPlayer ) then
		return;
	end

	if ( entity:IsPlayer() ) then return end
	if ( entity:GetClass() == "sent_grenade_vortex" ) then return end

	if ( !entity.m_bTriggered && entity:BoundingRadius() < 72 ) then

		entity.m_bTriggered = true

		local Data = duplicator.CopyEntTable( entity )
		constraint.NoCollide( entity, GetWorldEntity(), 0, 0 )
		SafeRemoveEntity( entity )

		if ( !pPlayer.m_tVortexEntities ) then
			pPlayer.m_tVortexEntities = {}
		end

		table.insert( pPlayer.m_tVortexEntities, Data )

	end

	if ( !self.m_bTriggered ) then

		self.Entity:EmitSound( Preblast_Sound )
		self.m_bTriggered		= true
		self.m_flVortexDuration	= CurTime() + SoundDuration( Preblast_Sound )

	end

end

/*---------------------------------------------------------
   Name: Think
---------------------------------------------------------*/
function ENT:Think()

	hook.Add( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")", function()

		if ( self.m_bTriggered ) then

			if ( CurTime() > self.m_flVortexDuration ) then

				self.m_bTriggered = nil

				self.Entity:SetNetworkedBool( "m_bTriggered", true )
				self.m_flSequenceDuration = CurTime() + 0.33

			end

		end

		if ( self.Entity:GetNetworkedBool( "m_bTriggered" ) ) then

			if ( CurTime() > self.m_flSequenceDuration ) then

				for k, v in pairs( self.m_tEffectedEntities ) do

					if ( v && v:IsValid() ) then

						if ( v:GetClass() == "prop_ragdoll" ) then

							for i = 1, v:GetPhysicsObjectCount() do

								local phys = v:GetPhysicsObjectNum( i )
								if (phys && phys:IsValid()) then
									phys:EnableGravity( true )
								end

							end

						else

							local phys = v:GetPhysicsObject()
							if (phys:IsValid()) then
								phys:EnableGravity( true )
							end

						end

						v.m_bIsEffectedByVortex = nil

					else

						table.remove( self.m_tEffectedEntities, k )

					end

				end

				hook.Remove( "Think", self:GetClass() .. " (" .. self:EntIndex() .. ")" )
				self.Entity:Remove()

				return

			end

		end

		local Pos1 = self.Entity:LocalToWorld( self.Entity:OBBCenter() )
		local Pos2

		local Distance

		for k, v in pairs( ents.FindInSphere( Pos1, 500.0 ) ) do

			if ( v != self.Entity && v:GetClass() != "sent_grenade_vortex" ) then

				if ( !v.m_bIsEffectedByVortex ) then

					v.m_bIsEffectedByVortex	= true
					v.m_hVortexIndex		= self.Entity:EntIndex()

				elseif ( v.m_hVortexIndex == self.Entity:EntIndex() ) then

					if ( ( v != self.Entity ) && ( v:GetClass() != self.Entity:GetClass() ) ) then

						Pos2 = v:LocalToWorld( v:OBBCenter() )

						Distance = Pos1:Distance( Pos2 )

						if ( v:GetClass() == "prop_ragdoll" ) then

							for i = 1, v:GetPhysicsObjectCount() do

								local phys = v:GetPhysicsObjectNum( i )
								if (phys && phys:IsValid()) then
									phys:EnableGravity( false )
									phys:ApplyForceCenter( ( Pos1 - Pos2 ) * ( Distance / 2 ) )
									phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
								end

							end

						else

							local phys = v:GetPhysicsObject()
							if (phys:IsValid()) then
								phys:EnableGravity( false )
								phys:ApplyForceCenter( ( Pos1 - Pos2 ) * ( Distance / 2 ) )
								phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
							end

						end

						v:SetPhysicsAttacker( self:GetOwner() )
						table.insert( self.m_tEffectedEntities, v )

					end

				end

			end

		end

	end )

end



