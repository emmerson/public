

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_vexnade.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_vexnade.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "Vexnade"
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "4"

	killicon.AddFont( "sent_grenade_vortex", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_grenade"
SWEP.Category			= "Vortex Weaponry"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.AmmoType		= "sent_grenade_vortex"
