

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_357vortex.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_357vortex.vtf" )

	AddCSLuaFile( "shared.lua" )

	function SWEP:OnRemove()

		if ( self.m_hVortex && self.m_hVortex:IsValid() ) then

			self.m_hVortex.m_bTriggered			= true
			self.m_hVortex.m_flVortexDuration	= CurTime() + 0.33

		end

	end

end

if ( CLIENT ) then

	SWEP.PrintName			= ".357 Vortex"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "."

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end

local Preblast_Sound = Sound( "ambient/levels/labs/teleport_preblast_suckin1.wav" )


SWEP.Base				= "swep_357"
SWEP.Category			= "Vortex Weaponry"
SWEP.m_hVortex			= nil

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= true

SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Ammo			= "None"

function SWEP:SecondaryAttack()

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	self.Weapon:EmitSound( self.Primary.Empty );

	pPlayer.m_tVortexEntities = {}

	pPlayer:PrintMessage( HUD_PRINTCENTER, "Vortial space cleared" )

end

local Entity = SWEP.m_hVortex

function SWEP:ShootCallback( attacker, trace, dmginfo )

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( Entity && Entity:IsValid() ) then

		Entity.m_bTriggered			= true
		Entity.m_flVortexDuration	= CurTime() + 0.33

	end

	if ( CLIENT ) then return end
	if ( trace.HitSky ) then return end

	Entity = ents.Create( "vortex_357" )

	if ( !( trace.Entity && trace.Entity:IsValid() ) ) then

		Entity:SetPos( trace.HitPos + ( trace.HitNormal * 1.0 ) )
		Entity:SetAngles( trace.HitNormal:Angle() + Angle( 270, 0, 0 ) )

		Entity:SetOwner( pPlayer )

		Entity:Spawn()

	else

		local		tr;
		local		vecSpot;// trace starts here!

		vecSpot = trace.Entity:LocalToWorld( trace.Entity:OBBCenter() );
		tr = {};
		tr.startpos = vecSpot;
		tr.endpos = vecSpot + Vector ( 0, 0, -64);
		tr.mask = MASK_SOLID_BRUSHONLY;
		tr.filter = trace.Entity;
		tr.collision = COLLISION_GROUP_NONE;
		tr = util.TraceLine ( tr);

		Entity:SetPos( Vector( vecSpot.x, vecSpot.y, tr.HitPos.z ) + ( tr.HitNormal * 1.0 ) )
		Entity:SetAngles( tr.HitNormal:Angle() + Angle( 270, 0, 0 ) )

		Entity:SetOwner( pPlayer )

		Entity:Spawn()

		Entity.m_bTriggered 		= true
		Entity.m_flVortexDuration	= CurTime() + SoundDuration( Preblast_Sound )

	end

	Entity:EmitSound( "k_lab.teleport_spark" )

	return {

		damage	= false,
		effects	= false

	}

end
