

if ( SERVER ) then

	resource.AddFile( "materials\VGUI\entities\weapon_ar3.vmt" )
	resource.AddFile( "materials\VGUI\entities\weapon_ar3.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	language.Add( "HL2_Dark_Energy_Rifle", "DARK-ENERGY RIFLE" )

	SWEP.PrintName			= "#HL2_Dark_Energy_Rifle"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "2"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_ar2"
SWEP.Category			= "Andrew McWatters"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= true

SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "None"

function SWEP:SecondaryAttack()
end

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	local pOwner = self.Owner;

	if ( pOwner == NULL ) then
		return;
	end

	local vecSrc	 = pOwner:GetShootPos();
	local vecAiming = pOwner:GetAimVector();

	local vecVelocity = vecAiming * 1000.0;

if ( !CLIENT ) then
	local pBall = ents.Create( "prop_combine_ball" )
						pBall:SetOwner( pOwner );
						pBall:SetPhysicsAttacker( pOwner );
						pBall:SetPos( vecSrc );

						pBall:SetVelocity( vecVelocity );
						pBall:Spawn();

						pBall:GetPhysicsObject():AddGameFlag( FVPHYSICS_DMG_DISSOLVE );
						pBall:GetPhysicsObject():AddGameFlag( FVPHYSICS_WAS_THROWN );
						pBall:GetPhysicsObject():SetVelocity( vecVelocity );
						pBall:EmitSound( "NPC_CombineBall.Launch" );
						pBall:SetModel( "models/Effects/combineball.mdl" );

	local white = Color(255, 255, 255, 64);
	//UTIL_ScreenFade( pOwner, white, 0.1, 0, FFADE_IN  );
end

end
