

// Variables that are used on both client and server

SWEP.Author			= "Andrew McWatters"
SWEP.Contact		= ""
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModelFOV	= 54
SWEP.ViewModelFlip	= false
SWEP.ViewModel		= "models/weapons/V_hands.mdl"
SWEP.WorldModel		= ""
SWEP.HoldType		= "normal"

SWEP.Category				= SWEP.Author

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.Sound			= Sound( "vo/npc/Barney/ba_ohshit03.wav" )		// Sound of a single shot
SWEP.Primary.Damage         = 1000.0
SWEP.Primary.ClipSize		= -1											// Size of a clip
SWEP.Primary.DefaultClip	= -1											// Default number of bullets in a clip
SWEP.Primary.Automatic		= false											// Automatic/Semi Auto
SWEP.Primary.Ammo			= "None"

SWEP.Secondary.ClipSize		= -1											// Size of a clip
SWEP.Secondary.DefaultClip	= -1											// Default number of bullets in a clip
SWEP.Secondary.Automatic	= false											// Automatic/Semi Auto
SWEP.Secondary.Ammo			= "None"



/*---------------------------------------------------------
   Name: SWEP:Initialize( )
   Desc: Called when the weapon is first loaded
---------------------------------------------------------*/
function SWEP:Initialize()

	if ( SERVER ) then
		self:SetWeaponHoldType( self.HoldType )
		self:SetNPCMinBurst( 0 )
		self:SetNPCMaxBurst( 0 )
		self:SetNPCFireRate( self.Primary.Delay )
	end

end


/*---------------------------------------------------------
   Name: SWEP:PrimaryAttack( )
   Desc: +attack1 has been pressed
---------------------------------------------------------*/
function SWEP:PrimaryAttack()

	self.m_bTriggered = true;
	self.Weapon:SetNextPrimaryFire( CurTime() + SoundDuration( self.Primary.Sound ) );
	self.Weapon:EmitSound( self.Primary.Sound );

end


/*---------------------------------------------------------
   Name: SWEP:SecondaryAttack( )
   Desc: +attack2 has been pressed
---------------------------------------------------------*/
function SWEP:SecondaryAttack()
	return false
end

/*---------------------------------------------------------
   Name: SWEP:Reload( )
   Desc: Reload is being pressed
---------------------------------------------------------*/
function SWEP:Reload()
	self.Weapon:DefaultReload( ACT_VM_RELOAD );
end


/*---------------------------------------------------------
   Name: SWEP:Think( )
   Desc: Called every frame
---------------------------------------------------------*/
function SWEP:Think()

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( self.m_bTriggered && CurTime() > self.Weapon:GetNextPrimaryFire() ) then
		self.m_bTriggered = false;
		util.BlastDamage( self.Weapon, // don't apply cl_interp delay
			pPlayer,
			pPlayer:GetPos(),
			100,
			self.Primary.Damage );

        local info = EffectData();
        info:SetEntity( pPlayer );
        info:SetOrigin( pPlayer:GetPos() );

        util.Effect( "Explosion", info );

        local           tr;
        local           vecSpot;// trace starts here!

        vecSpot = pPlayer:GetPos() + Vector ( 0 , 0 , 8 );
        tr = {};
        tr.startpos = vecSpot;
        tr.endpos = vecSpot + Vector ( 0, 0, -32 );
        tr.mask = MASK_SHOT_HULL;
        tr.filter = pPlayer;
        tr.collision = COLLISION_GROUP_NONE;
        tr = util.TraceLine ( tr);

        if( tr.StartSolid ) then
                // Since we blindly moved the explosion origin vertically, we may have inadvertently moved the explosion into a solid,
                // in which case nothing is going to be harmed by the grenade's explosion because all subsequent traces will startsolid.
                // If this is the case, we do the downward trace again from the actual origin of the grenade. (sjb) 3/8/2007  (for ep2_outland_09)
                tr = {};
                tr.startpos = pPlayer:GetPos();
                tr.endpos = pPlayer:GetPos() + Vector( 0, 0, -32);
                tr.mask = MASK_SHOT_HULL;
                tr.filter = pPlayer;
                tr.collision = COLLISION_GROUP_NONE;
                tr = util.TraceLine( tr );
        end

		local Pos1 = Vector( pPlayer:GetPos().x, pPlayer:GetPos().y, tr.HitPos.z ) + tr.HitNormal
		local Pos2 = Vector( pPlayer:GetPos().x, pPlayer:GetPos().y, tr.HitPos.z ) - tr.HitNormal

		util.Decal( "Scorch", Pos1, Pos2 );

		util.ScreenShake( pPlayer:GetPos(), 25.0, 150.0, 1.0, 750.0 );
	end

end


/*---------------------------------------------------------
   Name: SWEP:Deploy( )
   Desc: Whip it out
---------------------------------------------------------*/
function SWEP:Deploy()

	self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
	self:SetDeploySpeed( self.Weapon:SequenceDuration() )

	return true

end


/*---------------------------------------------------------
   Name: SetDeploySpeed
   Desc: Sets the weapon deploy speed.
		 This value needs to match on client and server.
---------------------------------------------------------*/
function SWEP:SetDeploySpeed( speed )

	self.m_WeaponDeploySpeed = tonumber( speed / GetConVarNumber( "phys_timescale" ) )

	self.Weapon:SetNextPrimaryFire( CurTime() + speed )
	self.Weapon:SetNextSecondaryFire( CurTime() + speed )

end

