
/*---------------------------------------------------------
   GetConVarBoolean
---------------------------------------------------------*/
function GetConVarBoolean( command )

	return tobool( GetConVarNumber( command ) )

end

function GetConVarBool( command )

	return tobool( GetConVarNumber( command ) )

end
