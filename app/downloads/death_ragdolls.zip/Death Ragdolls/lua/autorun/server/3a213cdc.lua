
local meta = FindMetaTable( "Player" )
if (!meta) then return end
if (!meta.g_CreateRagdoll) then meta.g_CreateRagdoll = meta.CreateRagdoll end
if (!meta.g_GetRagdollEntity) then meta.g_GetRagdollEntity = meta.GetRagdollEntity end

// In this file we're adding functions to the player meta table.
// This means you'll be able to call functions here straight from the player object
// You can even override already existing functions.

local mp_keepragdolls = CreateConVar( "mp_keepragdolls", 1, { FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED } )

local function PlayerDeath( ply, attacker, dmginfo )

	if ( ply.m_hRagdollEntity && ply.m_hRagdollEntity:IsValid() ) then

		ply:SpectateEntity( ply.m_hRagdollEntity )
		ply:Spectate( OBS_MODE_CHASE )

	end

end

hook.Add( "PlayerDeath", "PlayerDeath", PlayerDeath )

local function RemoveRagdollEntity( ply )

	if ( ply.m_hRagdollEntity && ply.m_hRagdollEntity:IsValid() ) then

		ply.m_hRagdollEntity:Remove()
		ply.m_hRagdollEntity = nil

	end

end

hook.Add( "PlayerSpawn", "RemoveRagdollEntity", RemoveRagdollEntity )
hook.Add( "PlayerDisconnected", "RemoveRagdollEntity", RemoveRagdollEntity )

function meta:CreateRagdoll()

	if ( mp_keepragdolls:GetBool() ) then

		local Ent = self:GetRagdollEntity()
		if ( Ent && Ent:IsValid() ) then Ent:Remove() end

		RemoveRagdollEntity( self )

		local Data = duplicator.CopyEntTable( self )

		Ent = ents.Create( "prop_ragdoll" )
			duplicator.DoGeneric( Ent, Data )
		Ent:Spawn()

		Ent.CanConstrain	= false
		Ent.CanTool			= false
		Ent.GravGunPunt		= false
		Ent.PhysgunDisabled	= true

		local Vel = self:GetVelocity()

		local iNumPhysObjects = Ent:GetPhysicsObjectCount()
		for Bone = 0, iNumPhysObjects-1 do

			local PhysObj = Ent:GetPhysicsObjectNum( Bone )
			if ( PhysObj:IsValid() ) then

				local Pos, Ang = self:GetBonePosition( Ent:TranslatePhysBoneToBone( Bone ) )
				PhysObj:SetPos( Pos )
				PhysObj:SetAngle( Ang )
				PhysObj:AddVelocity( Vel )

			end

		end

		self:SetNetworkedEntity( "m_hRagdollEntity", Ent )
		self.m_hRagdollEntity = Ent

		return

	end

	self:g_CreateRagdoll()

end

function meta:GetRagdollEntity()

	if ( mp_keepragdolls:GetBool() ) then

		return self:GetNetworkedEntity( "m_hRagdollEntity" )

	end

	return self:g_GetRagdollEntity()

end
