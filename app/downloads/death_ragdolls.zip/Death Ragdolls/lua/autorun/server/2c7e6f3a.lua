
local meta = FindMetaTable( "NPC" )
if (!meta) then return end

// In this file we're adding functions to the NPC meta table.
// This means you'll be able to call functions here straight from the NPC object
// You can even override already existing functions.

local GetRagdollEntities = {}

local HasRagdollGibs = {

	"npc_antlion_worker",
	"npc_clawscanner",
	"npc_cscanner",
	"npc_rollermine",
	"npc_manhack",
	"npc_strider",
	"npc_turret_floor",
	"npc_zombie"

}

local function RemoveRagdollEntity()

	local maxnpcs = server_settings.Int( "sbox_maxnpcs", 1 )

	if ( GetRagdollEntities && #GetRagdollEntities >= maxnpcs ) then

		local Ent = GetRagdollEntities[ 1 ]

		if ( !ValidEntity( Ent ) ) then return end

		Ent:Remove()
		Ent = nil

		table.remove( GetRagdollEntities, 1 )

	end

end

local function CreateRagdoll( victim, killer, weapon )

	if ( !GetConVarBoolean( "ai_keepragdolls" ) ) then return end
	if ( SinglePlayer() ) then return end
	if ( !ValidEntity( victim ) ) then return end
	if ( table.HasValue( HasRagdollGibs, victim:GetClass() ) ) then return end

	RemoveRagdollEntity()

	local Data = duplicator.CopyEntTable( victim )

	Ent = ents.Create( "prop_ragdoll" )
		duplicator.DoGeneric( Ent, Data )
		victim:SetColor( color_transparent )
		victim:SetNoDraw( true )
	Ent:Spawn()

	GAMEMODE:CreateEntityRagdoll( victim, Ent )

	local Vel = victim:GetVelocity()

	local iNumPhysObjects = Ent:GetPhysicsObjectCount()
	for Bone = 0, iNumPhysObjects-1 do

		local PhysObj = Ent:GetPhysicsObjectNum( Bone )
		if ( PhysObj:IsValid() ) then

			local Pos, Ang = victim:GetBonePosition( Ent:TranslatePhysBoneToBone( Bone ) )
			PhysObj:SetPos( Pos )
			PhysObj:SetAngle( Ang )
			PhysObj:AddVelocity( Vel )

		end

	end

	table.insert( GetRagdollEntities, Ent )

	victim:Remove()

end

hook.Add( "OnNPCKilled", "NPC.CreateRagdoll", CreateRagdoll )