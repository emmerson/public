/*
* lwinuser.c
* Winuser.h bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 24 Jan 2012 09:24:00
* This code is hereby placed in the public domain.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "lua.h"
#include "lauxlib.h"

static int LGetAsyncKeyState(lua_State *L)
{
  lua_pushinteger(L, GetAsyncKeyState(luaL_checkinteger(L, 1)));
  return 1;
}

static const luaL_Reg R[] =
{
	{ "GetAsyncKeyState",	LGetAsyncKeyState	},
	{ NULL,					NULL				}
};

LUALIB_API int luaopen_Winuser(lua_State *L)
{
 luaL_register(L,"_G",R);
 lua_pop(L, 1);
 return 0;
}
