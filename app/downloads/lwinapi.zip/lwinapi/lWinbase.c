/*
* lwinbase.c
* Winbase.h bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 17 Jan 2012 11:09:00
* This code is hereby placed in the public domain.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "lua.h"
#include "lauxlib.h"

static int LSleep(lua_State *L)
{
  Sleep((DWORD)luaL_checkinteger(L, 1));
  return 0;
}

static const luaL_Reg R[] =
{
	{ "Sleep",	LSleep	},
	{ NULL,		NULL	}
};

LUALIB_API int luaopen_Winbase(lua_State *L)
{
 luaL_register(L,"_G",R);
 lua_pop(L, 1);
 return 0;
}
