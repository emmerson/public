/*
* lwinapi.c
* Windows API for Lua 5.1
* Andrew McWatters <me@andrewmcwatters.com>
* 12 Jan 2012 10:41:00
* This code is hereby placed in the public domain.
*/

#include "lua.h"
#include "lauxlib.h"

#include "lIphlpapi.h"
#include "lWinbase.h"
#include "lWinuser.h"

LUALIB_API int luaopen_winapi(lua_State *L)
{
 luaopen_Iphlpapi(L);
 luaopen_Winbase(L);
 luaopen_Winuser(L);
 return 0;
}
