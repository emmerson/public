/*
* liphlpapi.h
* Iphlpapi.h bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 17 Jan 2012 11:33:00
* This code is hereby placed in the public domain.
*/

LUALIB_API int luaopen_Iphlpapi(lua_State *L);
