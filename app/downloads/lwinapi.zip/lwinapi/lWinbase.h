/*
* lwinbase.h
* Winbase.h bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 17 Jan 2012 11:09:00
* This code is hereby placed in the public domain.
*/

LUALIB_API int luaopen_Winbase(lua_State *L);
