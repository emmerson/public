/*
** Extended auxiliary functions for building Lua libraries
*/


#ifndef lauxlibex_h
#define lauxlibex_h


#include "lua.h"


#pragma warning( disable: 4800 )	// forcing value to bool 'true' or 'false' (performance warning)


LUALIB_API int (luaL_checkboolean) (lua_State *L, int numArg);
LUALIB_API int (luaL_optboolean) (lua_State *L, int nArg,
                                                int def);

#endif


