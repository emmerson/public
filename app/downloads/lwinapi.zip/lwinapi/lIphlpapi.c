/*
* liphlpapi.c
* Iphlpapi.h bindings
* Andrew McWatters <me@andrewmcwatters.com>
* 17 Jan 2012 11:09:00
* This code is hereby placed in the public domain.
*/

#include <winsock2.h>
#include <iphlpapi.h>

#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")

#include "lua.h"
#include "lauxlib.h"
#include "lauxlibex.h"

#define MALLOC(x) HeapAlloc(GetProcessHeap(), 0, (x))
#define FREE(x) HeapFree(GetProcessHeap(), 0, (x))

static int LGetIfTable(lua_State *L)
{
  DWORD dwSize = 0;
  DWORD dwRetVal = 0;
  unsigned int i, j;
  MIB_IFTABLE *pIfTable;
  MIB_IFROW *pIfRow;
  BOOL bOrder = (BOOL)luaL_checkboolean(L, 1);
  size_t origsize;
  size_t convertedChars = 0;
  char nstring[MAX_INTERFACE_NAME_LEN];
  char *target = nstring;
  pIfTable = (MIB_IFTABLE *) MALLOC(sizeof (MIB_IFTABLE));
  if (pIfTable == NULL)
    luaL_error(L, "error allocating memory");
  dwSize = sizeof (MIB_IFTABLE);
  if (GetIfTable(pIfTable, &dwSize, bOrder) == ERROR_INSUFFICIENT_BUFFER) {
    FREE(pIfTable);
    pIfTable = (MIB_IFTABLE *) MALLOC(dwSize);
    if (pIfTable == NULL)
      luaL_error(L, "error allocating memory");
  }
  if ((dwRetVal = GetIfTable(pIfTable, &dwSize, bOrder)) == NO_ERROR) {
    lua_newtable(L);
    lua_pushinteger(L, (lua_Integer) pIfTable->dwNumEntries);
    lua_setfield(L, -2, "dwNumEntries");
    lua_newtable(L);
    for (i = 0; i < (int) pIfTable->dwNumEntries; i++) {
      lua_pushinteger(L, i+1);
      lua_newtable(L);
      pIfRow = (MIB_IFROW *) & pIfTable->table[i];
      origsize = wcslen(pIfRow->wszName) + 1;
      wcstombs_s(&convertedChars, nstring, origsize, pIfRow->wszName, _TRUNCATE);
      lua_pushstring(L, nstring);
      lua_setfield(L, -2, "wszName");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwIndex);
      lua_setfield(L, -2, "dwIndex");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwType);
      lua_setfield(L, -2, "dwType");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwMtu);
      lua_setfield(L, -2, "dwMtu");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwSpeed);
      lua_setfield(L, -2, "dwSpeed");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwPhysAddrLen);
      lua_setfield(L, -2, "dwPhysAddrLen");
      memset(&nstring, 0, sizeof(nstring));
      target = nstring;
      for (j = 0; j < pIfRow->dwPhysAddrLen; j++)
        if (j == (pIfRow->dwPhysAddrLen - 1))
          target += sprintf(target, "%.2X", (int) pIfRow->bPhysAddr[j]);
        else
          target += sprintf(target, "%.2X-", (int) pIfRow->bPhysAddr[j]);
      lua_pushstring(L, nstring);
      lua_setfield(L, -2, "bPhysAddr");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwAdminStatus);
      lua_setfield(L, -2, "dwAdminStatus");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwOperStatus);
      lua_setfield(L, -2, "dwOperStatus");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwLastChange);
      lua_setfield(L, -2, "dwLastChange");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwInOctets);
      lua_setfield(L, -2, "dwInOctets");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwInUcastPkts);
      lua_setfield(L, -2, "dwInUcastPkts");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwInNUcastPkts);
      lua_setfield(L, -2, "dwInNUcastPkts");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwInDiscards);
      lua_setfield(L, -2, "dwInDiscards");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwInErrors);
      lua_setfield(L, -2, "dwInErrors");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwInUnknownProtos);
      lua_setfield(L, -2, "dwInUnknownProtos");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwOutOctets);
      lua_setfield(L, -2, "dwOutOctets");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwOutUcastPkts);
      lua_setfield(L, -2, "dwOutUcastPkts");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwOutNUcastPkts);
      lua_setfield(L, -2, "dwOutNUcastPkts");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwOutDiscards);
      lua_setfield(L, -2, "dwOutDiscards");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwOutErrors);
      lua_setfield(L, -2, "dwOutErrors");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwOutQLen);
      lua_setfield(L, -2, "dwOutQLen");
      lua_pushinteger(L, (lua_Integer) pIfRow->dwDescrLen);
      lua_setfield(L, -2, "dwDescrLen");
      lua_pushstring(L, (const char *) pIfRow->bDescr);
      lua_setfield(L, -2, "bDescr");
      lua_settable(L, -3);
    }
    lua_setfield(L, -2, "table");
  } else {
    FREE(pIfTable);
    luaL_error(L, "GetIfTable failed with %d", dwRetVal);
  }
  if (pIfTable != NULL) {
    FREE(pIfTable);
    pIfTable = NULL;
  }  
  return 1;
}

static int LGetTcpTable(lua_State *L)
{
  PMIB_TCPTABLE pTcpTable;
  DWORD dwSize = 0;
  DWORD dwRetVal = 0;
  char szLocalAddr[128];
  char szRemoteAddr[128];
  struct in_addr IpAddr;
  int i;
  BOOL bOrder = (BOOL)luaL_checkboolean(L, 1);
  pTcpTable = (MIB_TCPTABLE *) MALLOC(sizeof (MIB_TCPTABLE));
  if (pTcpTable == NULL)
    luaL_error(L, "error allocating memory");
  dwSize = sizeof (MIB_TCPTABLE);
  if ((dwRetVal = GetTcpTable(pTcpTable, &dwSize, bOrder)) == ERROR_INSUFFICIENT_BUFFER) {
    FREE(pTcpTable);
    pTcpTable = (MIB_TCPTABLE *) MALLOC(dwSize);
    if (pTcpTable == NULL)
      luaL_error(L, "error allocating memory");
  }
  if ((dwRetVal = GetTcpTable(pTcpTable, &dwSize, bOrder)) == NO_ERROR) {
    lua_newtable(L);
    lua_pushinteger(L, (lua_Integer) pTcpTable->dwNumEntries);
    lua_setfield(L, -2, "dwNumEntries");
    lua_newtable(L);
    for (i = 0; i < (int) pTcpTable->dwNumEntries; i++) {
      lua_pushinteger(L, i+1);
      lua_newtable(L);
      IpAddr.S_un.S_addr = (u_long) pTcpTable->table[i].dwLocalAddr;
      strcpy_s(szLocalAddr, sizeof (szLocalAddr), inet_ntoa(IpAddr));
      lua_pushstring(L, szLocalAddr);
      lua_setfield(L, -2, "szLocalAddr");
      lua_pushinteger(L, (lua_Integer) ntohs((u_short)pTcpTable->table[i].dwLocalPort));
      lua_setfield(L, -2, "dwLocalPort");
      IpAddr.S_un.S_addr = (u_long) pTcpTable->table[i].dwRemoteAddr;
      strcpy_s(szRemoteAddr, sizeof (szRemoteAddr), inet_ntoa(IpAddr));
      lua_pushstring(L, szRemoteAddr);
      lua_setfield(L, -2, "szRemoteAddr");
      lua_pushinteger(L, (lua_Integer) ntohs((u_short)pTcpTable->table[i].dwRemotePort));
      lua_setfield(L, -2, "dwRemotePort");
      lua_pushinteger(L, (lua_Integer) pTcpTable->table[i].dwState);
      lua_setfield(L, -2, "dwState");
      lua_pushinteger(L, (lua_Integer) pTcpTable->table[i].State);
      lua_setfield(L, -2, "State");
      lua_settable(L, -3);
    }
    lua_setfield(L, -2, "table");
  } else {
    FREE(pTcpTable);
    luaL_error(L, "GetTcpTable failed with %d", dwRetVal);
  }
  if (pTcpTable != NULL) {
    FREE(pTcpTable);
    pTcpTable = NULL;
  }  
  return 1;
}

static int LGetUdpTable(lua_State *L)
{
  PMIB_UDPTABLE pUdpTable;
  DWORD dwSize = 0;
  DWORD dwRetVal = 0;
  char szLocalAddr[128];
  struct in_addr IpAddr;
  int i;
  BOOL bOrder = (BOOL)luaL_checkboolean(L, 1);
  pUdpTable = (MIB_UDPTABLE *) MALLOC(sizeof (MIB_UDPTABLE));
  if (pUdpTable == NULL)
    luaL_error(L, "error allocating memory");
  dwSize = sizeof (MIB_UDPTABLE);
  if ((dwRetVal = GetUdpTable(pUdpTable, &dwSize, bOrder)) == ERROR_INSUFFICIENT_BUFFER) {
    FREE(pUdpTable);
    pUdpTable = (MIB_UDPTABLE *) MALLOC(dwSize);
    if (pUdpTable == NULL)
      luaL_error(L, "error allocating memory");
  }
  if ((dwRetVal = GetUdpTable(pUdpTable, &dwSize, bOrder)) == NO_ERROR) {
    lua_newtable(L);
    lua_pushinteger(L, (lua_Integer) pUdpTable->dwNumEntries);
    lua_setfield(L, -2, "dwNumEntries");
    lua_newtable(L);
    for (i = 0; i < (int) pUdpTable->dwNumEntries; i++) {
      lua_pushinteger(L, i+1);
      lua_newtable(L);
      IpAddr.S_un.S_addr = (u_long) pUdpTable->table[i].dwLocalAddr;
      strcpy_s(szLocalAddr, sizeof (szLocalAddr), inet_ntoa(IpAddr));
      lua_pushstring(L, szLocalAddr);
      lua_setfield(L, -2, "szLocalAddr");
      lua_pushinteger(L, (lua_Integer) ntohs((u_short)pUdpTable->table[i].dwLocalPort));
      lua_setfield(L, -2, "dwLocalPort");
      lua_settable(L, -3);
    }
    lua_setfield(L, -2, "table");
  } else {
    FREE(pUdpTable);
    luaL_error(L, "GetUpdTable failed with %d", dwRetVal);
  }
  if (pUdpTable != NULL) {
    FREE(pUdpTable);
    pUdpTable = NULL;
  }  
  return 1;
}

static const luaL_Reg R[] =
{
	{ "GetIfTable",		LGetIfTable	},
	{ "GetTcpTable",	LGetTcpTable	},
	{ "GetUdpTable",	LGetUdpTable	},
	{ NULL,				NULL			}
};

LUALIB_API int luaopen_Iphlpapi(lua_State *L)
{
 luaL_register(L,"_G",R);
 lua_pop(L, 1);
 return 0;
}
