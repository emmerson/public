-- bytes.lua
-- displays bytes sent and recieved in real time

require( "winapi" )

local pIfTable		= nil
local pIfRow		= nil
local isDuplicate	= false
local data			= {
	adapters		= {},
	sent			= 0,
	received		= 0
}

local function formatBytes( bytes )
	local size = "B"
	if ( bytes >= 1024 ) then
		size = "KB"
		bytes = bytes / 1024
	end
	if ( bytes >= 1024 ) then
		size = "MB"
		bytes = bytes / 1024
	end
	if ( bytes >= 1024 ) then
		size = "MB"
		bytes = bytes / 1024
	end
	if ( bytes >= 1024 ) then
		size = "GB"
		bytes = bytes / 1024
	end
	return string.format( "%.2f " .. size, bytes )
end

while( true ) do
	os.execute( "cls" )
	pIfTable		= GetIfTable( true )
	data.adapters	= {}
	data.sent		= 0
	data.received	= 0
	for i = 1, pIfTable.dwNumEntries do
		pIfRow = pIfTable.table[ i ]
		if ( pIfRow.dwType ~= 24		--[[ IF_TYPE_SOFTWARE_LOOPBACK ]]		and
			 pIfRow.dwOperStatus == 5	--[[ MIB_IF_OPER_STATUS_OPERATIONAL ]]	and
			 pIfRow.dwPhysAddrLen ~= 0											and
			 pIfRow.bPhysAddr ~= "00-00-00-00-00-00-00-E0" ) then
			isDuplicate = false
			for k, v in ipairs( data.adapters ) do
				if ( v.addr == pIfRow.bPhysAddr ) then
					isDuplicate = true
				end
			end
			if ( not isDuplicate ) then
				table.insert( data.adapters, {
					name = pIfRow.bDescr,
					addr = pIfRow.bPhysAddr
				} )
				data.sent		= data.sent		+ pIfRow.dwOutOctets
				data.received	= data.received	+ pIfRow.dwInOctets
			end
		end
	end
	print( "Adapters:" )
	for k, v in ipairs( data.adapters ) do
		print( "  " .. v.name .. " (" .. v.addr .. ")" )
	end
	print( "Sent: " .. formatBytes( data.sent ) )
	print( "Received: " .. formatBytes( data.received ) )
	print( "" )
	print( "Press CTRL + C to interrupt . . . " )
	Sleep( 1000 )
end
