

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/weapon_assaultsmg.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_assaultsmg.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "Assault SMG"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "/"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_smg1"
SWEP.Category			= "Andrew McWatters"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.Sound			= Sound( "Weapon_Pistol.NPC_Single" )
SWEP.Primary.Delay			= 0.25

SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "None"

function SWEP:PrimaryAttack()

	local pPlayer = self.Owner;
	if (!pPlayer) then
		return;
	end

	if ( self.Weapon:Clip1() <= 0 && self.Primary.ClipSize > -1 ) then
		if ( self:Ammo1() > 0 ) then
			self.Weapon:EmitSound( self.Primary.Empty );
			self:Reload();
		else
			self.Weapon:EmitSound( self.Primary.Empty );
			self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay );
		end

		return;
	end

	if ( self.m_bIsUnderwater && !self.m_bFiresUnderwater ) then
		self.Weapon:EmitSound( self.Primary.Empty );
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 );

		return;
	end

	if ( (self.Primary.ClipSize > -1 && self.Weapon:Clip1() == 0) || ( self.Primary.ClipSize <= -1 && !pPlayer:GetAmmoCount(self.Primary.Ammo) ) ) then
		return;
	end

	pPlayer:MuzzleFlash();

	local iBulletsToFire = 0;
	local fireRate = self.Primary.Delay;

	self.Weapon:EmitSound(self.Primary.Sound);
	self.Weapon:SetNextPrimaryFire( CurTime() + fireRate );
	iBulletsToFire = iBulletsToFire + self.Primary.NumShots;

	if ( self.Primary.ClipSize > -1 ) then
		if ( iBulletsToFire > self.Weapon:Clip1() ) then
			iBulletsToFire = self.Weapon:Clip1();
		end
		self:TakePrimaryAmmo( self.Primary.NumAmmo );
	end

	self:ShootBullet( self.Primary.Damage, iBulletsToFire, self.Primary.Cone );

	if ( !pPlayer:IsNPC() ) then
		self:AddViewKick();
	end

	self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK );
	pPlayer:SetAnimation( PLAYER_ATTACK1 );

	self.Primary.Delay = self.Primary.Delay - 0.015;
	self.Primary.Delay = math.Clamp( self.Primary.Delay, 0.05, 0.25 );

end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()

	local fRet;
	local fCacheTime = self.Secondary.Delay;

	self.Primary.Delay = 0.25;
	self.m_fFireDuration = 0.0;

	fRet = self.Weapon:DefaultReload( ACT_VM_RELOAD );
	if ( fRet ) then
		self.Weapon:SetNextSecondaryFire( CurTime() + fCacheTime );

		self.Weapon:EmitSound( self.Primary.Reload );

	end

	return fRet;

end

function SWEP:UpdatePenaltyTime()

	local pOwner = self.Owner;

	if ( pOwner == NULL ) then
		return;
	end

	if ( ( !pOwner:KeyDown( IN_ATTACK ) ) ) then
		self.Primary.Delay = self.Primary.Delay + FrameTime();
		self.Primary.Delay = math.Clamp( self.Primary.Delay, 0.05, 0.25 );
	end

end

function SWEP:Think()

	self:UpdatePenaltyTime();

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( pPlayer:WaterLevel() >= 3 ) then
		self.m_bIsUnderwater = true;
	else
		self.m_bIsUnderwater = false;
	end

	if ( pPlayer:KeyDown( IN_ATTACK ) ) then
		self.m_fFireDuration = self.m_fFireDuration + FrameTime();
	elseif ( !pPlayer:KeyDown( IN_ATTACK ) ) then
		self.m_fFireDuration = 0.0;
	end

end
