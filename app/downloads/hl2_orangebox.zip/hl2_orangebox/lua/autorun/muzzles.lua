resource.AddFile( "particles/muzzles.pcf" )
resource.AddFile( "particles/particles_manifest.txt" )
