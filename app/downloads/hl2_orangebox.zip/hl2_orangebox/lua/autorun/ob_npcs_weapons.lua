
AddCSLuaFile( "ob_npcs_weapons.lua" )

//
// Don't try to edit this file if you're trying to add new NPCs.
// Just make a new file and copy the format below.
//

list.Set( "NPCWeapons", "ob_shotgun", "Shotgun (OB)" )
list.Set( "NPCWeapons", "ob_pistol", "Pistol (OB)" )
list.Set( "NPCWeapons", "ob_smg1", "SMG1 (OB)" )
list.Set( "NPCWeapons", "ob_ar2", "AR2 (OB)" )
list.Set( "NPCWeapons", "ob_357", "357 (OB)" )
