

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/ob_357.vmt" )
	resource.AddFile( "materials/VGUI/entities/ob_357.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "#HL2_357Handgun"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "."

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:DrawWeaponSelection( x, y, wide, tall, alpha )

		surface.SetDrawColor( color_transparent )
		surface.SetTextColor( 255, 220, 0, alpha )
		surface.SetFont( self.WepSelectFont )
		local w, h = surface.GetTextSize( self.WepSelectLetter )

		surface.SetTextPos( x + ( wide / 2 ) - ( w / 2 ),
							y + ( tall / 2 ) - ( h / 2 ) )
		surface.DrawText( self.WepSelectLetter )

		local bWide			= surface.SScale( 16 )
		local bTall			= bWide

		draw.RoundedBox( 4, x + wide - ( bWide - bWide / 4 ),
							y + tall - ( bTall - bTall / 4 ),
							bWide,
							bTall,
							Color( 255, 127, 0, alpha ) )

	end

end


SWEP.Base				= "swep_357"
SWEP.Category			= "The Orange Box"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ParticleTracer	= 0
SWEP.Primary.DefaultTracer	= 4
SWEP.Primary.Tracer			= 0
SWEP.Primary.TracerName		= "357_tracer"
SWEP.Primary.Muzzle			= "357_muzzle"
SWEP.Primary.MuzzleLong		= "357_muzzlelong"

function SWEP:Precache()

	PrecacheParticleSystem( self.Primary.TracerName );
	PrecacheParticleSystem( self.Primary.Muzzle );
	PrecacheParticleSystem( self.Primary.MuzzleLong );

end

function SWEP:PrimaryAttack()

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	if ( self.Weapon:Clip1() <= 0 && self.Primary.ClipSize > -1 ) then
		if ( self:Ammo1() > 0 ) then
			self.Weapon:EmitSound( self.Primary.Empty );
			self:Reload();
		else
			self.Weapon:EmitSound( self.Primary.Empty );
			self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay );
		end

		return;
	end

	if ( self.m_bIsUnderwater && !self.m_bFiresUnderwater ) then
		self.Weapon:EmitSound( self.Primary.Empty );
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 );

		return;
	end

	self.Weapon:EmitSound( self.Primary.Sound );
	if ( !pPlayer:IsNPC() ) then
		pPlayer:GetViewModel():StopParticles();
	end
	self.Weapon:StopParticles();
	if ( CLIENT ) then
		if ( !pPlayer:IsNPC() && GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	else
		if ( !pPlayer:IsNPC() && pPlayer:GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	end
	pPlayer:MuzzleFlash();

	self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK );
	pPlayer:SetAnimation( PLAYER_ATTACK1 );

	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay );
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Primary.Delay );

	self:TakePrimaryAmmo( 1 );

	self:ShootBullet( self.Primary.Damage, self.Primary.NumShots, self.Primary.Cone );

	local Weapon = self.Weapon

	timer.Simple( self.Primary.Delay, function()

		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		if (!pPlayer:IsNPC() && (!pPlayer:KeyDown( IN_ATTACK ) || Weapon:Clip1() >= 0)) then
			if ( CLIENT ) then
				if ( GetViewEntity():IsPlayer() ) then
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
				else
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
				end
			else
				if ( pPlayer:GetViewEntity():IsPlayer() ) then
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
				else
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
				end
			end
		end

	end )

	local angles = pPlayer:EyeAngles();

	angles.pitch = angles.pitch + math.random( -1, 1 );
	angles.yaw   = angles.yaw   + math.random( -1, 1 );
	angles.roll  = 0;

	if ( pPlayer:IsNPC() ) then return end

if ( !CLIENT ) then
	pPlayer:SnapEyeAngles( angles );
end

	pPlayer:ViewPunch( Angle( -8, math.Rand( -2, 2 ), 0 ) );

end

function SWEP:Holster( wep )

	local pPlayer = self.Owner;
	if (!pPlayer) then
		return;
	end

	local Weapon = self.Weapon

	timer.Simple( 0.0, function()

		if (!pPlayer) then return end
		if (pPlayer:IsNPC()) then return end
		if (!pPlayer:GetViewModel()) then return end
		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		if ( CLIENT ) then
			if ( pPlayer == LocalPlayer() ) then
				pPlayer:GetViewModel():StopParticles();
			end
		end
		Weapon:StopParticles();

	end )

	return true

end

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	local vecSrc		= pPlayer:GetShootPos();
	local vecAiming		= pPlayer:GetAimVector();

	local info = { Num = num_bullets, Src = vecSrc, Dir = vecAiming, Spread = aimcone, Tracer = self.Primary.Tracer, Damage = damage };
	info.Attacker = pPlayer;

	info.Owner = self.Owner
	info.Weapon = self.Weapon

	info.ShootCallback = self.ShootCallback;

	info.Callback = function( attacker, trace, dmginfo )
		self.Primary.ParticleTracer = self.Primary.ParticleTracer + 1
		if ( self.Primary.ParticleTracer >= self.Primary.DefaultTracer ) then
			self.Primary.ParticleTracer = 0;
			util.ParticleTracerEx( self.Primary.TracerName, trace.StartPos, trace.HitPos, true, info.Weapon:EntIndex(), info.Weapon:LookupAttachment( "muzzle" ) );
		end
		return info:ShootCallback( attacker, trace, dmginfo );
	end

	pPlayer:FireBullets( info );

end
