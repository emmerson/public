

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/ob_frag.vmt" )
	resource.AddFile( "materials/VGUI/entities/ob_frag.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "#HL2_Grenade"
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "4"

	killicon.AddFont( "sent_grenade_ob_frag", "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:DrawWeaponSelection( x, y, wide, tall, alpha )

		surface.SetDrawColor( color_transparent )
		surface.SetTextColor( 255, 220, 0, alpha )
		surface.SetFont( self.WepSelectFont )
		local w, h = surface.GetTextSize( self.WepSelectLetter )

		surface.SetTextPos( x + ( wide / 2 ) - ( w / 2 ),
							y + ( tall / 2 ) - ( h / 2 ) )
		surface.DrawText( self.WepSelectLetter )

		local bWide			= surface.SScale( 16 )
		local bTall			= bWide

		draw.RoundedBox( 4, x + wide - ( bWide - bWide / 4 ),
							y + tall - ( bTall - bTall / 4 ),
							bWide,
							bTall,
							Color( 255, 127, 0, alpha ) )

	end

end


SWEP.Base				= "swep_grenade"
SWEP.Category			= "The Orange Box"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.AmmoType		= "sent_grenade_ob_frag"
