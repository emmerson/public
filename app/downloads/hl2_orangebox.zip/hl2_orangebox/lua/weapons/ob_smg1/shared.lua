

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/ob_smg1.vmt" )
	resource.AddFile( "materials/VGUI/entities/ob_smg1.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "#HL2_SMG1"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "/"

	killicon.AddFont( SWEP.ClassName,			"HL2MPTypeDeath", SWEP.IconLetter,	Color( 255, 80, 0, 255 ) )
	killicon.AddFont( "sent_grenade_ob_ar2",	"HL2MPTypeDeath", "7",				Color( 255, 80, 0, 255 ) )

	function SWEP:DrawWeaponSelection( x, y, wide, tall, alpha )

		surface.SetDrawColor( color_transparent )
		surface.SetTextColor( 255, 220, 0, alpha )
		surface.SetFont( self.WepSelectFont )
		local w, h = surface.GetTextSize( self.WepSelectLetter )

		surface.SetTextPos( x + ( wide / 2 ) - ( w / 2 ),
							y + ( tall / 2 ) - ( h / 2 ) )
		surface.DrawText( self.WepSelectLetter )

		local bWide			= surface.SScale( 16 )
		local bTall			= bWide

		draw.RoundedBox( 4, x + wide - ( bWide - bWide / 4 ),
							y + tall - ( bTall - bTall / 4 ),
							bWide,
							bTall,
							Color( 255, 127, 0, alpha ) )

	end

end


SWEP.Base				= "swep_smg1"
SWEP.Category			= "The Orange Box"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ParticleTracer	= 0
SWEP.Primary.DefaultTracer	= 2
SWEP.Primary.Tracer			= 0
SWEP.Primary.TracerName		= "smg_tracer"
SWEP.Primary.Muzzle			= "smg_muzzle"
SWEP.Primary.MuzzleLong		= "smg_muzzlelong"

SWEP.Secondary.AmmoType		= "sent_grenade_ob_ar2"

function SWEP:Precache()

	PrecacheParticleSystem( self.Primary.TracerName );
	PrecacheParticleSystem( self.Primary.Muzzle );
	PrecacheParticleSystem( self.Primary.MuzzleLong );

end

function SWEP:Equip( NewOwner )

	if ( !NewOwner:IsNPC() ) then

		NewOwner:GiveAmmo( 1, "smg1_grenade");

	end

end

function SWEP:EquipAmmo( NewOwner )

	if ( !NewOwner:IsNPC() ) then

		NewOwner:GiveAmmo( 1, "smg1_grenade");

	end

end

function SWEP:PrimaryAttack()

	local pPlayer = self.Owner;
	if (!pPlayer) then
		return;
	end

	if ( self.Weapon:Clip1() <= 0 && self.Primary.ClipSize > -1 ) then
		if ( self:Ammo1() > 0 ) then
			self.Weapon:EmitSound( self.Primary.Empty );
			self:Reload();
		else
			self.Weapon:EmitSound( self.Primary.Empty );
			self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay );
		end

		return;
	end

	if ( self.m_bIsUnderwater && !self.m_bFiresUnderwater ) then
		self.Weapon:EmitSound( self.Primary.Empty );
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 );

		return;
	end

	if ( (self.Primary.ClipSize > -1 && self.Weapon:Clip1() == 0) || ( self.Primary.ClipSize <= -1 && !pPlayer:GetAmmoCount(self.Primary.Ammo) ) ) then
		return;
	end

	if ( !pPlayer:IsNPC() ) then
		pPlayer:GetViewModel():StopParticles();
	end
	self.Weapon:StopParticles();
	if ( CLIENT ) then
		if ( !pPlayer:IsNPC() && GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	else
		if ( !pPlayer:IsNPC() && pPlayer:GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	end
	pPlayer:MuzzleFlash();

	local iBulletsToFire = 0;
	local fireRate = self.Primary.Delay;

	self.Weapon:EmitSound(self.Primary.Sound);
	self.Weapon:SetNextPrimaryFire( CurTime() + fireRate );
	iBulletsToFire = iBulletsToFire + self.Primary.NumShots;

	if ( self.Primary.ClipSize > -1 ) then
		if ( iBulletsToFire > self.Weapon:Clip1() ) then
			iBulletsToFire = self.Weapon:Clip1();
		end
		self:TakePrimaryAmmo( self.Primary.NumAmmo );
	end

	self:ShootBullet( self.Primary.Damage, iBulletsToFire, self.Primary.Cone );

	local Weapon = self.Weapon

	timer.Simple( self.Primary.Delay, function()

		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		if (!pPlayer:IsNPC() && (!pPlayer:KeyDown( IN_ATTACK ) || self.Weapon:Clip1() >= 0)) then
			if ( self.m_fFireDuration >= 0.3 ) then
				if ( CLIENT ) then
					if ( GetViewEntity():IsPlayer() ) then
						ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
					else
						ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
					end
				else
					if ( pPlayer:GetViewEntity():IsPlayer() ) then
						ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
					else
						ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
					end
				end
			end
		end

	end )

	if ( !pPlayer:IsNPC() ) then
		self:AddViewKick();
	end

	self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK );
	pPlayer:SetAnimation( PLAYER_ATTACK1 );

end

function SWEP:Holster( wep )

	local pPlayer = self.Owner;
	if (!pPlayer) then
		return;
	end

	local Weapon = self.Weapon

	timer.Simple( 0.0, function()

		if (!pPlayer) then return end
		if (pPlayer:IsNPC()) then return end
		if (!pPlayer:GetViewModel()) then return end
		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		if ( CLIENT ) then
			if ( pPlayer == LocalPlayer() ) then
				pPlayer:GetViewModel():StopParticles();
			end
		end
		Weapon:StopParticles();

	end )

	return true

end

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	local pHL2MPPlayer = pPlayer;

	local info = {};
	info.Num = num_bullets;
	info.Src = pHL2MPPlayer:GetShootPos();
	info.Dir = pPlayer:GetAimVector();
	info.Spread = aimcone;
	info.Damage = damage;
	info.Tracer = self.Primary.Tracer;

	info.Owner = self.Owner
	info.Weapon = self.Weapon

	info.ShootCallback = self.ShootCallback;

	info.Callback = function( attacker, trace, dmginfo )
		self.Primary.ParticleTracer = self.Primary.ParticleTracer + 1
		if ( self.Primary.ParticleTracer >= self.Primary.DefaultTracer ) then
			self.Primary.ParticleTracer = 0;
			util.ParticleTracerEx( self.Primary.TracerName, trace.StartPos, trace.HitPos, true, info.Weapon:EntIndex(), info.Weapon:LookupAttachment( "muzzle" ) );
		end
		return info:ShootCallback( attacker, trace, dmginfo );
	end

	pPlayer:FireBullets( info );

end
