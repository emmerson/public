

if ( SERVER ) then

	resource.AddFile( "materials/VGUI/entities/ob_shotgun.vmt" )
	resource.AddFile( "materials/VGUI/entities/ob_shotgun.vtf" )

	AddCSLuaFile( "shared.lua" )

end

if ( CLIENT ) then

	SWEP.PrintName			= "#HL2_Shotgun"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "0"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

	function SWEP:DrawWeaponSelection( x, y, wide, tall, alpha )

		surface.SetDrawColor( color_transparent )
		surface.SetTextColor( 255, 220, 0, alpha )
		surface.SetFont( self.WepSelectFont )
		local w, h = surface.GetTextSize( self.WepSelectLetter )

		surface.SetTextPos( x + ( wide / 2 ) - ( w / 2 ),
							y + ( tall / 2 ) - ( h / 2 ) )
		surface.DrawText( self.WepSelectLetter )

		local bWide			= surface.SScale( 16 )
		local bTall			= bWide

		draw.RoundedBox( 4, x + wide - ( bWide - bWide / 4 ),
							y + tall - ( bTall - bTall / 4 ),
							bWide,
							bTall,
							Color( 255, 127, 0, alpha ) )

	end

end


SWEP.Base				= "swep_shotgun"
SWEP.Category			= "The Orange Box"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.ParticleTracer	= 0
SWEP.Primary.DefaultTracer	= 4
SWEP.Primary.Tracer			= 0
SWEP.Primary.TracerName		= "buckshot_tracer"
SWEP.Primary.Muzzle			= "shotgun_muzzle"
SWEP.Primary.MuzzleLong		= "shotgun_muzzlelong"

function SWEP:Precache()

	PrecacheParticleSystem( self.Primary.TracerName );
	PrecacheParticleSystem( self.Primary.Muzzle );
	PrecacheParticleSystem( self.Primary.MuzzleLong );

end

function SWEP:PrimaryAttack()

	local pOwner = self.Owner;
	if (!pOwner) then
		return;
	end

	if (self.m_bNeedPump) then
		return;
	end

	self.m_bDelayedFire1 = false;
	if ( (self.Weapon:Clip1() <= 0 && self.Primary.ClipSize > -1) || ( self.Primary.ClipSize <= -1 && pOwner:GetAmmoCount(self.Primary.Ammo) <= 0 ) ) then
		if (pOwner:GetAmmoCount(self.Primary.Ammo) <= 0) then
			self:DryFire();
			return;
		else
			self:StartReload();
			return;
		end
	elseif (pOwner:WaterLevel() == 3 && self.m_bFiresUnderwater == false) then
		self.Weapon:EmitSound(self.Primary.Empty);
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 );
		self.Weapon:SetNextSecondaryFire( CurTime() + 0.2 );
		self.m_flNextPrimaryAttack = CurTime() + 0.2;
		return;
	else
		local pPlayer = self.Owner;
		if ( !pPlayer:IsNPC() ) then
			if ( pPlayer && pPlayer:KeyPressed( IN_ATTACK ) ) then
				 self.Weapon:SetNextPrimaryFire( CurTime() );
				 self.Weapon:SetNextSecondaryFire( CurTime() );
				 self.m_flNextPrimaryAttack = CurTime();
			end
		end
	end

	local pPlayer = self.Owner;

	if (!pPlayer) then
		return;
	end

	if (!pPlayer:IsNPC()) then
		self.Weapon:EmitSound(self.Primary.Sound);
	else
		self.Weapon:EmitSound(self.Primary.SoundNPC);
	end

	if ( !pPlayer:IsNPC() ) then
		pPlayer:GetViewModel():StopParticles();
	end
	self.Weapon:StopParticles();
	if ( CLIENT ) then
		if ( !pPlayer:IsNPC() && GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	else
		if ( !pPlayer:IsNPC() && pPlayer:GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	end
	pPlayer:MuzzleFlash();

	self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK );

	self.Weapon:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration() );
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Weapon:SequenceDuration() );
	self.m_flNextPrimaryAttack = CurTime() + self.Weapon:SequenceDuration();
	self:TakePrimaryAmmo( self.Primary.NumAmmo );

	pPlayer:SetAnimation( PLAYER_ATTACK1 );


	self:ShootBullet( self.Primary.Damage, self.Primary.NumShots, self:GetBulletSpread() );

	local Weapon = self.Weapon

	timer.Simple( self.Primary.Delay, function()

		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		if (!pPlayer:IsNPC() && ((!pPlayer:KeyDown( IN_ATTACK ) && !pPlayer:KeyDown( IN_ATTACK2 )) || self.Weapon:Clip1() >= 0)) then
			if ( CLIENT ) then
				if ( GetViewEntity():IsPlayer() ) then
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
				else
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
				end
			else
				if ( pPlayer:GetViewEntity():IsPlayer() ) then
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
				else
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
				end
			end
		end

	end )

	local punch;
	punch = Angle( math.Rand( -2, -1 ), math.Rand( -2, 2 ), 0 );
	if (!pPlayer:IsNPC()) then
		pPlayer:ViewPunch( punch );
	end

	self.m_bNeedPump = true;

end

function SWEP:SecondaryAttack()

	local pOwner = self.Owner;
	if (!pOwner) then
		return;
	end

	if (self.m_bNeedPump) then
		return;
	end

	self.m_bDelayedFire2 = false;

	if ( (self.Weapon:Clip1() <= 1 && self.Primary.ClipSize > -1)) then
		if ( self.Weapon:Clip1() == 1 ) then
			self:PrimaryAttack();
			return;
		elseif (pOwner:GetAmmoCount(self.Primary.Ammo) <= 0) then
			self:DryFire();
			return;
		else
			self:StartReload();
			return;
		end

	elseif (self.Owner:WaterLevel() == 3 && self.m_bFiresUnderwater == false) then
		self.Weapon:EmitSound(self.Primary.Empty);
		self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 );
		self.Weapon:SetNextSecondaryFire( CurTime() + 0.2 );
		self.m_flNextPrimaryAttack = CurTime() + 0.2;
		return;
	else
		if ( pOwner:KeyPressed( IN_ATTACK ) ) then
			 self.Weapon:SetNextPrimaryFire( CurTime() );
			 self.Weapon:SetNextSecondaryFire( CurTime() );
			 self.m_flNextPrimaryAttack = CurTime();
		end
	end

	local pPlayer = self.Owner;

	if (!pPlayer) then
		return;
	end

	if (!pPlayer:IsNPC()) then
		self.Weapon:EmitSound(self.Secondary.Sound);
	else
		self.Weapon:EmitSound(self.Secondary.SoundNPC);
	end

	if ( !pPlayer:IsNPC() ) then
		pPlayer:GetViewModel():StopParticles();
	end
	self.Weapon:StopParticles();
	if ( CLIENT ) then
		if ( !pPlayer:IsNPC() && GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	else
		if ( !pPlayer:IsNPC() && pPlayer:GetViewEntity():IsPlayer() ) then
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
		else
			ParticleEffectAttach( self.Primary.Muzzle, PATTACH_POINT_FOLLOW, self.Weapon, self.Weapon:LookupAttachment( "muzzle" ) );
		end
	end

	self.Weapon:SendWeaponAnim( ACT_VM_SECONDARYATTACK );

	self.Weapon:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration() );
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Weapon:SequenceDuration() );
	self.m_flNextPrimaryAttack = CurTime() + self.Weapon:SequenceDuration();
	self:TakePrimaryAmmo( self.Secondary.NumAmmo );

	pPlayer:SetAnimation( PLAYER_ATTACK1 );


	self:ShootBullet( self.Secondary.Damage, self.Secondary.NumShots, self:GetBulletSpread() );

	local Weapon = self.Weapon

	timer.Simple( self.Primary.Delay * 2.0, function()

		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		if (!pPlayer:IsNPC() && ((!pPlayer:KeyDown( IN_ATTACK ) && !pPlayer:KeyDown( IN_ATTACK2 )) || self.Weapon:Clip1() >= 0)) then
			if ( CLIENT ) then
				if ( GetViewEntity():IsPlayer() ) then
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
				else
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
				end
			else
				if ( pPlayer:GetViewEntity():IsPlayer() ) then
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, pPlayer:GetViewModel(), pPlayer:GetViewModel():LookupAttachment( "muzzle" ) );
				else
					ParticleEffectAttach( self.Primary.MuzzleLong, PATTACH_POINT_FOLLOW, Weapon, Weapon:LookupAttachment( "muzzle" ) );
				end
			end
		end

	end )
	pPlayer:ViewPunch( Angle(math.Rand( -5, 5 ),0,0) );

	self.m_bNeedPump = true;

end

function SWEP:Holster( wep )

	local pPlayer = self.Owner;
	if (!pPlayer) then
		return;
	end

	local Weapon = self.Weapon

	timer.Simple( 0.0, function()

		if (!pPlayer) then return end
		if (pPlayer:IsNPC()) then return end
		if (!pPlayer:GetViewModel()) then return end
		if (!Weapon) then return end
		if (!Weapon:IsValid()) then return end

		if ( CLIENT ) then
			if ( pPlayer == LocalPlayer() ) then
				pPlayer:GetViewModel():StopParticles();
			end
		end
		Weapon:StopParticles();

	end )

	return true

end

function SWEP:ShootBullet( damage, num_bullets, aimcone )

	local pPlayer = self.Owner;

	if ( !pPlayer ) then
		return;
	end

	local vecSrc		= pPlayer:GetShootPos();
	local vecAiming		= pPlayer:GetAimVector();

	local info = { Num = num_bullets, Src = vecSrc, Dir = vecAiming, Spread = aimcone, Tracer = self.Primary.Tracer, Damage = damage };
	info.Attacker = pPlayer;

	info.Owner = self.Owner
	info.Weapon = self.Weapon

	info.ShootCallback = self.ShootCallback;

	info.Callback = function( attacker, trace, dmginfo )
		self.Primary.ParticleTracer = self.Primary.ParticleTracer + 1
		if ( self.Primary.ParticleTracer >= self.Primary.DefaultTracer ) then
			self.Primary.ParticleTracer = 0;
			util.ParticleTracerEx( self.Primary.TracerName, trace.StartPos, trace.HitPos, true, info.Weapon:EntIndex(), info.Weapon:LookupAttachment( "muzzle" ) );
		end
		return info:ShootCallback( attacker, trace, dmginfo );
	end

	pPlayer:FireBullets( info );

end
