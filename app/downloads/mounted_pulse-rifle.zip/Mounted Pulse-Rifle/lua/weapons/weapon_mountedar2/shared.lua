

gTankSpread =
{
	Vector( 0, 0, 0 ),		// perfect
	Vector( 0.025, 0.025, 0.025 ),	// small cone
	Vector( 0.05, 0.05, 0.05 ),  // medium cone
	Vector( 0.1, 0.1, 0.1 ),	// large cone
	Vector( 0.25, 0.25, 0.25 ),	// extra-large cone
};

if ( SERVER ) then

	resource.AddFile( "materials/models/weapons/v_pulsemg/newstock.vmt" )
	resource.AddFile( "materials/models/weapons/v_pulsemg/newstock.vtf" )
	resource.AddFile( "materials/models/weapons/v_pulsemg/pulse_mg.vmt" )
	resource.AddFile( "materials/models/weapons/v_pulsemg/pulse_mg.vtf" )
	resource.AddFile( "materials/models/weapons/v_pulsemg/pulse_mg_ref.vtf" )
	resource.AddFile( "materials/models/weapons/w_pulsemg/newstock.vmt" )
	resource.AddFile( "materials/models/weapons/w_pulsemg/pulse_mg.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_mountedar2.vmt" )
	resource.AddFile( "materials/VGUI/entities/weapon_mountedar2.vtf" )
	resource.AddFile( "models/weapons/v_pulsemg.mdl" )
	resource.AddFile( "models/weapons/w_pulsemg.mdl" )

	AddCSLuaFile( "shared.lua" )

	SWEP.HoldType			= "ar2"

end

if ( CLIENT ) then

	language.Add( "HL2_Mounted_Pulse_Rifle", "MOUNTED PULSE-RIFLE" )

	SWEP.PrintName			= "#HL2_Mounted_Pulse_Rifle"
	SWEP.ClassName			= string.Strip( GetScriptPath(), "weapons/" )
	SWEP.Author				= "Andrew McWatters"
	SWEP.IconLetter			= "2"

	killicon.AddFont( SWEP.ClassName, "HL2MPTypeDeath", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )

end


SWEP.Base				= "swep_ar2"
SWEP.Category			= "Half-Life 2"
SWEP.m_bLastShot		= false

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.ViewModel			= "models/weapons/v_pulsemg.mdl"
SWEP.WorldModel			= "models/weapons/w_pulsemg.mdl"

SWEP.Primary.Sound			= Sound( "Weapon_functank.Single" )
SWEP.Primary.Damage			= 5
SWEP.Primary.Cone			= gTankSpread[ 2 ]
SWEP.Primary.ClipSize		= 60
SWEP.Primary.Delay			= 0.05
SWEP.Primary.Tracer			= 1

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "None"

function SWEP:DoImpactEffect( tr )
end

function SWEP:Reload()

	local fRet;
	local fCacheTime = self.Secondary.Delay;

	self.m_fFireDuration = 0.0;

	fRet = self.Weapon:DefaultReload( ACT_VM_RELOAD );
	if ( fRet ) then
		self.m_bLastShot = false
		self.Weapon:SetNextSecondaryFire( CurTime() + fCacheTime );

		self.Weapon:EmitSound( self.Primary.Reload );

	end

	return fRet;

end

function SWEP:AddViewKick()

	local	EASY_DAMPEN			= 0.5
	local	MAX_VERTICAL_KICK	= 1.0
	local	SLIDE_LIMIT			= 5.0

	local pPlayer = self.Owner;

	if ( pPlayer == NULL ) then
		return;
	end

	self:DoMachineGunKick( pPlayer, EASY_DAMPEN, MAX_VERTICAL_KICK, self.m_fFireDuration, SLIDE_LIMIT );

end

function SWEP:TakePrimaryAmmo( num )

	if ( !self.m_bLastShot ) then

		self.m_bLastShot = !self.m_bLastShot

	return end

	self.m_bLastShot = !self.m_bLastShot

	if ( self.Weapon:Clip1() <= 0 ) then

		if ( self:Ammo1() <= 0 ) then return end

		self.Owner:RemoveAmmo( num, self.Weapon:GetPrimaryAmmoType() )

	return end

	self.Weapon:SetClip1( self.Weapon:Clip1() - num )

end

function SWEP:CanSecondaryAttack()
	return false
end
